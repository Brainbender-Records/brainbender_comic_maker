# Brainbender Comic Maker - Phase 3

Open and free Linux desktop starter app for comic creation with ComfyUI as the Stable Diffusion backend.

## Phase 3 additions

Phase 3 adds real comic project organization:

- Comic book projects
- Chapters inside each project
- Pages inside chapters
- Page title, script, and notes
- Panels attached to pages
- Add the latest generated image as a panel
- Add an existing image file as a panel
- Persistent JSON autosave-style storage under your user data folder

## Earlier features included

- PySide6 desktop GUI
- ComfyUI detection and auto-start support
- Model detection and local model import
- Text-to-image generation
- Image-to-image / reference image generation
- Character profiles and reference images
- Prompt templates
- Style / LoRA preset notes
- Generation history
- Snap packaging starter files

## Install on Ubuntu

```bash
cd ~/Downloads
unzip brainbender_comic_maker_phase3.zip -d brainbender_comic_maker_phase3
cd brainbender_comic_maker_phase3
./install_ubuntu.sh
./start.sh
```

## ComfyUI connection

Set your ComfyUI folder in **Settings / Models**. The app will try to start ComfyUI if it is not already running.

Default ComfyUI URL:

```text
http://127.0.0.1:8188
```

Put Stable Diffusion checkpoints in:

```text
ComfyUI/models/checkpoints/
```

or use **Import Local Model File** in the app.

## Phase 5 target

The next phase should replace the basic page organization view with a drag-and-drop visual comic page editor.


## Phase 5 - Page Layout Editor

Phase 5 adds a visual comic page layout editor:

- Select a project, chapter, and page from Phase 3.
- Apply preset layouts: splash page, vertical panels, 4-panel grid, 6-panel grid, manga strip, and more.
- Move panels directly on the page canvas.
- Resize panels with the Set Panel Size button.
- Assign generated images or image files to layout panels.
- Save layout metadata into the project JSON.
- Export a page mockup as a PNG file.

This is the first implementation of the visual page builder. The next phase can add speech bubbles, captions, sound effects, and text tools.


## Phase 5 additions

Phase 5 adds comic lettering features inside the Page Layout Editor:

- Add speech bubbles, caption boxes, and sound-effect text
- Move and resize lettering items on the comic page
- Edit lettering text after placement
- Change font size and bubble fill color
- Save/load lettering data inside each page layout
- Export a lettered page as a PNG

Use the Page Layout Editor tab, select a project/chapter/page, then add panels and lettering from the right-side controls.

## Phase 6 additions

Phase 6 adds consistency and continuity tools for comic production:

- Continuity character profiles separate from the general character library
- Location memory for recurring settings
- Prop tracking for important recurring objects
- Pose and camera-angle reference slots
- Scene memory for recurring story moments
- Reference image importing for each continuity item
- Continuity Prompt Builder for assembling reusable prompts

Use the **Continuity Tools** tab to create reusable story assets, then build a continuity prompt and paste it into the Generate tab. This is designed to help keep characters, costumes, locations, props, and camera language consistent across panels.
