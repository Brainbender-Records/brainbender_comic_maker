from __future__ import annotations

from dataclasses import dataclass, asdict
import json
import uuid
from pathlib import Path
from typing import Any

from ..core.paths import APP_DIR
from .panel_director import PanelCell, ComicDirectorStore, DirectedPromptBuilder, CAMERA_PRESETS, MOOD_PRESETS, STYLE_PRESETS

PLANNER_DIR = APP_DIR / "director"
PAGE_PLAN_FILE = PLANNER_DIR / "page_plans.json"

PAGE_TEMPLATES = {
    "3 cells - top wide + two bottom": [
        {"panel_number": 1, "camera": "wide establishing shot", "notes": "Large top panel, set the scene."},
        {"panel_number": 2, "camera": "medium shot", "notes": "Character action or discovery."},
        {"panel_number": 3, "camera": "close-up reaction shot", "notes": "Emotional beat or reveal."},
    ],
    "4 cells - balanced grid": [
        {"panel_number": 1, "camera": "wide establishing shot", "notes": "Opening beat."},
        {"panel_number": 2, "camera": "medium shot", "notes": "Action beat."},
        {"panel_number": 3, "camera": "over-the-shoulder shot", "notes": "Interaction/dialogue beat."},
        {"panel_number": 4, "camera": "close-up reaction shot", "notes": "Ending/reaction beat."},
    ],
    "6 cells - classic comic page": [
        {"panel_number": 1, "camera": "wide establishing shot", "notes": "Establish the location."},
        {"panel_number": 2, "camera": "medium shot", "notes": "Introduce action."},
        {"panel_number": 3, "camera": "close-up reaction shot", "notes": "Reaction."},
        {"panel_number": 4, "camera": "over-the-shoulder shot", "notes": "Dialogue or confrontation."},
        {"panel_number": 5, "camera": "action shot", "notes": "Movement or escalation."},
        {"panel_number": 6, "camera": "quiet emotional close-up", "notes": "Button/end beat."},
    ],
}

@dataclass
class PagePlan:
    id: str
    page_name: str = "Page 1"
    title: str = ""
    summary: str = ""
    default_character_ids: list[str] | None = None
    default_location_id: str = ""
    default_style: str = "semi-realistic graphic novel style"
    default_mood: str = "dramatic"
    template_name: str = "4 cells - balanced grid"
    panel_ids: list[str] | None = None

    def __post_init__(self):
        if self.default_character_ids is None:
            self.default_character_ids = []
        if self.panel_ids is None:
            self.panel_ids = []

class PagePlanStore:
    def __init__(self):
        PLANNER_DIR.mkdir(parents=True, exist_ok=True)
        if not PAGE_PLAN_FILE.exists():
            PAGE_PLAN_FILE.write_text("[]")
        self.panel_store = ComicDirectorStore()

    def _load_raw(self) -> list[dict[str, Any]]:
        try:
            return json.loads(PAGE_PLAN_FILE.read_text())
        except Exception:
            return []

    def _save_raw(self, rows: list[dict[str, Any]]) -> None:
        PAGE_PLAN_FILE.write_text(json.dumps(rows, indent=2))

    def plans(self) -> list[PagePlan]:
        return [PagePlan(**row) for row in self._load_raw()]

    def upsert_plan(self, plan: PagePlan) -> None:
        rows = [asdict(p) for p in self.plans() if p.id != plan.id]
        rows.append(asdict(plan))
        rows.sort(key=lambda p: p.get("page_name", ""))
        self._save_raw(rows)

    def delete_plan(self, plan_id: str) -> None:
        self._save_raw([asdict(p) for p in self.plans() if p.id != plan_id])

    def new_plan(self, page_name: str = "Page 1") -> PagePlan:
        return PagePlan(id=str(uuid.uuid4()), page_name=page_name)

    def apply_template(self, plan: PagePlan) -> PagePlan:
        existing_ids = set(plan.panel_ids or [])
        # Keep existing panels if the page already has panel cells; otherwise create from template.
        if existing_ids:
            return plan
        panel_ids: list[str] = []
        template = PAGE_TEMPLATES.get(plan.template_name, PAGE_TEMPLATES["4 cells - balanced grid"])
        for entry in template:
            panel = PanelCell(
                id=str(uuid.uuid4()),
                page=plan.page_name,
                panel_number=int(entry["panel_number"]),
                user_prompt="",
                character_ids=list(plan.default_character_ids or []),
                location_id=plan.default_location_id,
                camera=str(entry.get("camera", "medium shot")),
                mood=plan.default_mood,
                style=plan.default_style,
                director_notes=str(entry.get("notes", "")),
            )
            self.panel_store.upsert_panel(panel)
            panel_ids.append(panel.id)
        plan.panel_ids = panel_ids
        self.upsert_plan(plan)
        return plan

    def panels_for_plan(self, plan: PagePlan) -> list[PanelCell]:
        by_id = {p.id: p for p in self.panel_store.panels()}
        panels = [by_id[pid] for pid in (plan.panel_ids or []) if pid in by_id]
        panels.sort(key=lambda p: p.panel_number)
        return panels
