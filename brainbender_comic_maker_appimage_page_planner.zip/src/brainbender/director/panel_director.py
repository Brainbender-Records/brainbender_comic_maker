from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

from ..core.paths import APP_DIR
from ..continuity import ContinuityStore

DIRECTOR_DIR = APP_DIR / "director"
PANEL_FILE = DIRECTOR_DIR / "panel_cells.json"

CAMERA_PRESETS = [
    "wide establishing shot",
    "medium shot",
    "close-up reaction shot",
    "over-the-shoulder shot",
    "low-angle dramatic shot",
    "high-angle view",
    "action shot",
    "quiet emotional close-up",
]

MOOD_PRESETS = [
    "neutral",
    "mysterious",
    "hopeful",
    "tense",
    "dramatic",
    "funny",
    "dark and cinematic",
    "bright adventure",
]

STYLE_PRESETS = [
    "semi-realistic graphic novel style",
    "clean modern comic book style",
    "classic newspaper comic style",
    "manga-inspired comic style",
    "cinematic painted comic style",
    "black ink line art with color flats",
]


@dataclass
class PanelCell:
    id: str
    page: str = "Page 1"
    panel_number: int = 1
    user_prompt: str = ""
    character_ids: list[str] | None = None
    location_id: str = ""
    camera: str = "medium shot"
    mood: str = "dramatic"
    style: str = "semi-realistic graphic novel style"
    locked_character_continuity: bool = True
    locked_location_continuity: bool = True
    use_previous_panel_reference: bool = False
    previous_panel_strength: float = 0.45
    dialogue: str = ""
    director_notes: str = ""
    generated_prompt: str = ""
    generated_image: str = ""

    def __post_init__(self):
        if self.character_ids is None:
            self.character_ids = []


class ComicDirectorStore:
    def __init__(self):
        DIRECTOR_DIR.mkdir(parents=True, exist_ok=True)
        if not PANEL_FILE.exists():
            PANEL_FILE.write_text("[]")

    def _load_raw(self) -> list[dict[str, Any]]:
        try:
            return json.loads(PANEL_FILE.read_text())
        except Exception:
            return []

    def _save_raw(self, rows: list[dict[str, Any]]) -> None:
        PANEL_FILE.write_text(json.dumps(rows, indent=2))

    def panels(self) -> list[PanelCell]:
        return [PanelCell(**row) for row in self._load_raw()]

    def upsert_panel(self, panel: PanelCell) -> None:
        rows = [asdict(p) for p in self.panels() if p.id != panel.id]
        rows.append(asdict(panel))
        rows.sort(key=lambda p: (p.get("page", ""), int(p.get("panel_number", 0))))
        self._save_raw(rows)

    def delete_panel(self, panel_id: str) -> None:
        self._save_raw([asdict(p) for p in self.panels() if p.id != panel_id])

    def new_panel(self, page: str = "Page 1") -> PanelCell:
        existing = [p for p in self.panels() if p.page == page]
        next_number = max([p.panel_number for p in existing], default=0) + 1
        return PanelCell(id=str(uuid.uuid4()), page=page, panel_number=next_number)


class DirectedPromptBuilder:
    """Combines artist-written cell prompts with reusable character/location continuity."""

    def __init__(self, continuity_store: ContinuityStore):
        self.continuity_store = continuity_store

    def build(self, panel: PanelCell) -> str:
        characters = {c.id: c for c in self.continuity_store.characters()}
        locations = {l.id: l for l in self.continuity_store.locations()}
        chunks: list[str] = []

        chunks.append("comic book panel, single comic cell, professional page-ready composition")
        if panel.style.strip():
            chunks.append(panel.style.strip())
        if panel.camera.strip():
            chunks.append(panel.camera.strip())
        if panel.mood.strip():
            chunks.append(f"mood: {panel.mood.strip()}")

        # The user's cell prompt remains the core creative instruction.
        if panel.user_prompt.strip():
            chunks.append(f"artist cell prompt: {panel.user_prompt.strip()}")

        if panel.locked_character_continuity:
            for cid in panel.character_ids or []:
                char = characters.get(cid)
                if char:
                    chunks.append(char.prompt_block())
                    # Add reference labels/notes to the text prompt so the user can see what is driving continuity.
                    for slot in char.reference_slots or []:
                        label = slot.get("label", "reference")
                        notes = slot.get("notes", "")
                        if notes:
                            chunks.append(f"character reference sheet {label}: {notes}")
                        else:
                            chunks.append(f"character reference sheet: {label}")

        if panel.locked_location_continuity and panel.location_id:
            loc = locations.get(panel.location_id)
            if loc:
                chunks.append(loc.prompt_block())

        if panel.dialogue.strip():
            chunks.append(f"leave clean space for dialogue: {panel.dialogue.strip()}")
        if panel.director_notes.strip():
            chunks.append(f"director notes: {panel.director_notes.strip()}")
        if panel.use_previous_panel_reference:
            chunks.append(f"use previous panel as continuity reference, strength {panel.previous_panel_strength:.2f}")

        return ",\n".join([c for c in chunks if c.strip()])
