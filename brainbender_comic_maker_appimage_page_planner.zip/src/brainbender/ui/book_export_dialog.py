from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QListWidget, QFileDialog, QMessageBox, QTextEdit
)

from ..core.paths import data_dir
from ..exporter.exporter import Exporter


class BookExportDialog(QDialog):
    """Export finished comic pages as PDF/CBZ/release folder."""

    def __init__(self, generated_images: list[str], parent=None):
        super().__init__(parent)
        self.setWindowTitle("Export Comic Book")
        self.resize(900, 650)
        self.generated_images = generated_images
        self._build_ui()
        self.refresh_candidates()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        self.title_edit = QLineEdit("Brainbender Comic")
        self.author_edit = QLineEdit("")
        self.cover_edit = QLineEdit("")
        self.dest_edit = QLineEdit(str(data_dir() / "book_exports"))
        self.pages = QListWidget(); self.pages.setSelectionMode(QListWidget.ExtendedSelection)
        self.log = QTextEdit(); self.log.setReadOnly(True)

        cover_btn = QPushButton("Choose Cover Image")
        cover_btn.clicked.connect(self.choose_cover)
        dest_btn = QPushButton("Choose Export Folder")
        dest_btn.clicked.connect(self.choose_dest)
        add_btn = QPushButton("Add Page Images")
        add_btn.clicked.connect(self.add_pages)
        remove_btn = QPushButton("Remove Selected")
        remove_btn.clicked.connect(self.remove_selected)
        up_btn = QPushButton("Move Up")
        up_btn.clicked.connect(lambda: self.move_selected(-1))
        down_btn = QPushButton("Move Down")
        down_btn.clicked.connect(lambda: self.move_selected(1))
        refresh_btn = QPushButton("Refresh Auto-Detected Pages")
        refresh_btn.clicked.connect(self.refresh_candidates)
        export_btn = QPushButton("Export PDF + CBZ + PNG Release Folder")
        export_btn.clicked.connect(self.export_book)

        layout.addWidget(QLabel("Book Title")); layout.addWidget(self.title_edit)
        layout.addWidget(QLabel("Author / Publisher")); layout.addWidget(self.author_edit)
        row = QHBoxLayout(); row.addWidget(self.cover_edit); row.addWidget(cover_btn); layout.addLayout(row)
        row = QHBoxLayout(); row.addWidget(self.dest_edit); row.addWidget(dest_btn); layout.addLayout(row)
        layout.addWidget(QLabel("Ordered Pages")); layout.addWidget(self.pages, 1)
        row = QHBoxLayout()
        for b in [add_btn, remove_btn, up_btn, down_btn, refresh_btn]:
            row.addWidget(b)
        layout.addLayout(row)
        layout.addWidget(export_btn)
        layout.addWidget(QLabel("Export Log")); layout.addWidget(self.log)

    def refresh_candidates(self):
        existing = {self.pages.item(i).text() for i in range(self.pages.count())}
        candidates = []
        # Page editor exports here.
        exports = data_dir() / "exports"
        candidates.extend(str(p) for p in sorted(exports.glob("*.png")) if p.is_file())
        candidates.extend(str(Path(p)) for p in self.generated_images if Path(p).exists())
        for path in candidates:
            if path not in existing:
                self.pages.addItem(path)
                existing.add(path)
        self.log.append(f"Found {self.pages.count()} candidate page/panel images.")

    def choose_cover(self):
        f, _ = QFileDialog.getOpenFileName(self, "Choose cover image", "", "Images (*.png *.jpg *.jpeg *.webp)")
        if f:
            self.cover_edit.setText(f)

    def choose_dest(self):
        d = QFileDialog.getExistingDirectory(self, "Choose export folder", self.dest_edit.text())
        if d:
            self.dest_edit.setText(d)

    def add_pages(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Add comic page images", "", "Images (*.png *.jpg *.jpeg *.webp)")
        for f in files:
            self.pages.addItem(f)

    def remove_selected(self):
        for item in self.pages.selectedItems():
            self.pages.takeItem(self.pages.row(item))

    def move_selected(self, delta):
        row = self.pages.currentRow()
        if row < 0:
            return
        new_row = row + delta
        if new_row < 0 or new_row >= self.pages.count():
            return
        item = self.pages.takeItem(row)
        self.pages.insertItem(new_row, item)
        self.pages.setCurrentRow(new_row)

    def export_book(self):
        page_images = [self.pages.item(i).text() for i in range(self.pages.count())]
        try:
            manifest = Exporter().export_book(
                page_images=page_images,
                dest_dir=self.dest_edit.text(),
                title=self.title_edit.text().strip() or "Brainbender Comic",
                author=self.author_edit.text().strip(),
                cover_image=self.cover_edit.text().strip(),
            )
        except Exception as exc:
            QMessageBox.critical(self, "Export failed", str(exc))
            return
        self.log.append("Export complete:")
        self.log.append(f"PDF: {manifest['pdf']}")
        self.log.append(f"CBZ: {manifest['cbz']}")
        self.log.append(f"Pages: {manifest['page_count']}")
        QMessageBox.information(self, "Export complete", f"Created PDF and CBZ in:\n{Path(manifest['pdf']).parent}")
