from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import *

from ..continuity import ContinuityStore
from ..director.panel_director import DirectedPromptBuilder
from ..director.page_planner import PagePlan, PagePlanStore, PAGE_TEMPLATES

class PagePlannerDialog(QDialog):
    """Multi-cell page planner for the AI Comic Director.

    This is built around the workflow the project is moving toward:
    artists write the prompt for each cell, then reuse Characters/Locations to preserve continuity.
    """

    def __init__(self, continuity_store: ContinuityStore, parent=None):
        super().__init__(parent)
        self.setWindowTitle("AI Comic Director — Page Planner")
        self.resize(1280, 780)
        self.continuity_store = continuity_store
        self.store = PagePlanStore()
        self.builder = DirectedPromptBuilder(continuity_store)
        self.current_plan: PagePlan | None = None
        self.current_panel_id: str = ""
        self._build_ui()
        self.refresh_assets()
        self.refresh_page_list()
        self.new_page()

    def _build_ui(self):
        root = QHBoxLayout(self)
        left = QVBoxLayout(); mid = QVBoxLayout(); right = QVBoxLayout()
        root.addLayout(left, 1); root.addLayout(mid, 2); root.addLayout(right, 2)

        left.addWidget(QLabel("Pages"))
        self.page_list = QListWidget(); self.page_list.itemSelectionChanged.connect(self.load_selected_page)
        left.addWidget(self.page_list, 3)
        row = QHBoxLayout()
        new_btn = QPushButton("+ Page")
        del_btn = QPushButton("Delete")
        new_btn.clicked.connect(self.new_page); del_btn.clicked.connect(self.delete_current_page)
        row.addWidget(new_btn); row.addWidget(del_btn)
        left.addLayout(row)
        make_cells = QPushButton("Create Cells From Template")
        make_cells.clicked.connect(self.create_cells_from_template)
        left.addWidget(make_cells)

        left.addWidget(QLabel("Cells on selected page"))
        self.cell_list = QListWidget(); self.cell_list.itemSelectionChanged.connect(self.load_selected_cell)
        left.addWidget(self.cell_list, 4)
        build_all = QPushButton("Build All Page Prompts")
        build_all.clicked.connect(self.build_all_prompts)
        send_selected = QPushButton("Send Selected Cell to Studio")
        send_selected.clicked.connect(self.send_selected_to_studio)
        left.addWidget(build_all); left.addWidget(send_selected)

        form = QFormLayout()
        self.page_name = QLineEdit("Page 1")
        self.page_title = QLineEdit()
        self.page_summary = QPlainTextEdit(); self.page_summary.setMaximumHeight(80)
        self.template_combo = QComboBox(); self.template_combo.addItems(list(PAGE_TEMPLATES.keys()))
        self.default_style = QLineEdit("semi-realistic graphic novel style")
        self.default_mood = QLineEdit("dramatic")
        form.addRow("Page name", self.page_name)
        form.addRow("Page title", self.page_title)
        form.addRow("Template", self.template_combo)
        form.addRow("Default style", self.default_style)
        form.addRow("Default mood", self.default_mood)
        mid.addLayout(form)
        mid.addWidget(QLabel("Page summary / story beat")); mid.addWidget(self.page_summary)

        self.character_box = QGroupBox("Default Characters for this page")
        self.character_layout = QVBoxLayout(self.character_box)
        mid.addWidget(self.character_box)
        self.location_combo = QComboBox()
        mid.addWidget(QLabel("Default Location for this page")); mid.addWidget(self.location_combo)
        save_page = QPushButton("Save Page Settings")
        save_page.clicked.connect(self.save_current_page)
        mid.addWidget(save_page)

        mid.addWidget(QLabel("Selected cell prompt — the user's creative instruction stays central"))
        self.cell_prompt = QPlainTextEdit()
        self.cell_prompt.setPlaceholderText("Example: John pushes open the church door while rain blows in behind him.")
        mid.addWidget(self.cell_prompt, 2)
        self.cell_dialogue = QPlainTextEdit(); self.cell_dialogue.setMaximumHeight(70); self.cell_dialogue.setPlaceholderText("Optional dialogue/caption for this cell")
        self.cell_notes = QPlainTextEdit(); self.cell_notes.setMaximumHeight(70); self.cell_notes.setPlaceholderText("Optional director notes")
        self.cell_camera = QLineEdit("medium shot")
        mid.addWidget(QLabel("Cell camera")); mid.addWidget(self.cell_camera)
        mid.addWidget(QLabel("Dialogue/caption")); mid.addWidget(self.cell_dialogue)
        mid.addWidget(QLabel("Director notes")); mid.addWidget(self.cell_notes)
        cell_row = QHBoxLayout()
        save_cell = QPushButton("Save Cell")
        build_cell = QPushButton("Build Selected Prompt")
        save_cell.clicked.connect(self.save_selected_cell); build_cell.clicked.connect(self.build_selected_prompt)
        cell_row.addWidget(save_cell); cell_row.addWidget(build_cell)
        mid.addLayout(cell_row)

        right.addWidget(QLabel("Final prompt for selected cell"))
        self.final_prompt = QPlainTextEdit()
        right.addWidget(self.final_prompt, 3)
        right.addWidget(QLabel("All prompts for this page"))
        self.all_prompts = QPlainTextEdit(); self.all_prompts.setReadOnly(True)
        right.addWidget(self.all_prompts, 3)
        right.addWidget(QLabel("How this works: create page cells, write a prompt for each cell, choose reusable Characters/Locations, then build prompts. Brainbender adds continuity details automatically."))

    def refresh_assets(self):
        for i in reversed(range(self.character_layout.count())):
            item = self.character_layout.itemAt(i)
            widget = item.widget()
            if widget:
                widget.deleteLater()
        self.char_checks: dict[str, QCheckBox] = {}
        for char in self.continuity_store.characters():
            cb = QCheckBox(char.name)
            cb.setToolTip(char.prompt_block())
            self.char_checks[char.id] = cb
            self.character_layout.addWidget(cb)
        self.character_layout.addStretch(1)

        self.location_combo.clear()
        self.location_combo.addItem("No default location", "")
        for loc in self.continuity_store.locations():
            self.location_combo.addItem(loc.name, loc.id)

    def refresh_page_list(self):
        self.page_list.clear()
        for plan in self.store.plans():
            item = QListWidgetItem(f"{plan.page_name} — {plan.title or plan.summary[:40]}")
            item.setData(Qt.UserRole, plan.id)
            self.page_list.addItem(item)

    def refresh_cell_list(self):
        self.cell_list.clear()
        if not self.current_plan:
            return
        for panel in self.store.panels_for_plan(self.current_plan):
            item = QListWidgetItem(f"Cell {panel.panel_number}: {panel.user_prompt[:55] or '[empty prompt]'}")
            item.setData(Qt.UserRole, panel.id)
            self.cell_list.addItem(item)

    def collect_page(self) -> PagePlan:
        plan = self.current_plan or self.store.new_plan(self.page_name.text().strip() or "Page 1")
        plan.page_name = self.page_name.text().strip() or "Page 1"
        plan.title = self.page_title.text().strip()
        plan.summary = self.page_summary.toPlainText().strip()
        plan.template_name = self.template_combo.currentText()
        plan.default_style = self.default_style.text().strip() or "semi-realistic graphic novel style"
        plan.default_mood = self.default_mood.text().strip() or "dramatic"
        plan.default_character_ids = [cid for cid, cb in self.char_checks.items() if cb.isChecked()]
        plan.default_location_id = self.location_combo.currentData() or ""
        return plan

    def load_page(self, plan: PagePlan):
        self.current_plan = plan
        self.page_name.setText(plan.page_name)
        self.page_title.setText(plan.title)
        self.page_summary.setPlainText(plan.summary)
        self.template_combo.setCurrentText(plan.template_name)
        self.default_style.setText(plan.default_style)
        self.default_mood.setText(plan.default_mood)
        for cid, cb in self.char_checks.items():
            cb.setChecked(cid in (plan.default_character_ids or []))
        idx = self.location_combo.findData(plan.default_location_id)
        self.location_combo.setCurrentIndex(idx if idx >= 0 else 0)
        self.refresh_cell_list()
        self.update_all_prompts_preview()

    def new_page(self):
        next_num = len(self.store.plans()) + 1
        self.current_plan = self.store.new_plan(f"Page {next_num}")
        self.load_page(self.current_plan)

    def save_current_page(self):
        self.current_plan = self.collect_page()
        self.store.upsert_plan(self.current_plan)
        self.refresh_page_list()

    def delete_current_page(self):
        if not self.current_plan:
            return
        self.store.delete_plan(self.current_plan.id)
        self.refresh_page_list()
        self.new_page()

    def load_selected_page(self):
        items = self.page_list.selectedItems()
        if not items:
            return
        plan_id = items[0].data(Qt.UserRole)
        for plan in self.store.plans():
            if plan.id == plan_id:
                self.load_page(plan)
                return

    def create_cells_from_template(self):
        self.save_current_page()
        self.current_plan = self.store.apply_template(self.current_plan)
        self.refresh_cell_list()
        self.refresh_page_list()

    def _panel_by_id(self, panel_id: str):
        for p in self.store.panel_store.panels():
            if p.id == panel_id:
                return p
        return None

    def load_selected_cell(self):
        items = self.cell_list.selectedItems()
        if not items:
            return
        self.current_panel_id = items[0].data(Qt.UserRole)
        panel = self._panel_by_id(self.current_panel_id)
        if not panel:
            return
        self.cell_prompt.setPlainText(panel.user_prompt)
        self.cell_dialogue.setPlainText(panel.dialogue)
        self.cell_notes.setPlainText(panel.director_notes)
        self.cell_camera.setText(panel.camera)
        self.final_prompt.setPlainText(panel.generated_prompt)

    def save_selected_cell(self):
        if not self.current_panel_id:
            return
        panel = self._panel_by_id(self.current_panel_id)
        if not panel:
            return
        page = self.collect_page()
        panel.page = page.page_name
        panel.user_prompt = self.cell_prompt.toPlainText().strip()
        panel.dialogue = self.cell_dialogue.toPlainText().strip()
        panel.director_notes = self.cell_notes.toPlainText().strip()
        panel.camera = self.cell_camera.text().strip() or panel.camera
        panel.style = page.default_style
        panel.mood = page.default_mood
        panel.character_ids = list(page.default_character_ids or [])
        panel.location_id = page.default_location_id
        panel.generated_prompt = self.final_prompt.toPlainText().strip()
        self.store.panel_store.upsert_panel(panel)
        self.store.upsert_plan(page)
        self.current_plan = page
        self.refresh_cell_list()

    def build_selected_prompt(self):
        self.save_selected_cell()
        panel = self._panel_by_id(self.current_panel_id)
        if not panel:
            return
        prompt = self.builder.build(panel)
        panel.generated_prompt = prompt
        self.final_prompt.setPlainText(prompt)
        self.store.panel_store.upsert_panel(panel)
        self.update_all_prompts_preview()

    def build_all_prompts(self):
        self.save_current_page()
        if not self.current_plan:
            return
        for panel in self.store.panels_for_plan(self.current_plan):
            panel.character_ids = list(self.current_plan.default_character_ids or [])
            panel.location_id = self.current_plan.default_location_id
            panel.style = self.current_plan.default_style
            panel.mood = self.current_plan.default_mood
            panel.generated_prompt = self.builder.build(panel)
            self.store.panel_store.upsert_panel(panel)
        self.update_all_prompts_preview()
        self.refresh_cell_list()

    def update_all_prompts_preview(self):
        if not self.current_plan:
            self.all_prompts.clear(); return
        lines = []
        for panel in self.store.panels_for_plan(self.current_plan):
            lines.append(f"=== {panel.page} / Cell {panel.panel_number} ===")
            lines.append(panel.generated_prompt or "[prompt not built yet]")
            lines.append("")
        self.all_prompts.setPlainText("\n".join(lines))

    def send_selected_to_studio(self):
        self.build_selected_prompt()
        parent = self.parent()
        if parent and hasattr(parent, "prompt"):
            parent.prompt.setPlainText(self.final_prompt.toPlainText())
            if hasattr(parent, "log"):
                parent.log("Page Planner selected cell prompt sent to Studio.")
        self.accept()
