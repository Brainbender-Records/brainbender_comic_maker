from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import *

from ..continuity import ContinuityStore
from ..director import PanelCell, ComicDirectorStore, DirectedPromptBuilder
from ..director.panel_director import CAMERA_PRESETS, MOOD_PRESETS, STYLE_PRESETS


class AIDirectorDialog(QDialog):
    """Panel/cell-first AI Comic Director.

    This dialog intentionally keeps the artist's own cell prompt in the center.
    Reusable Characters and Locations are selected around that prompt to keep continuity.
    """

    def __init__(self, continuity_store: ContinuityStore, parent=None):
        super().__init__(parent)
        self.setWindowTitle("AI Comic Director — Cell Prompt + Continuity")
        self.resize(1200, 760)
        self.continuity_store = continuity_store
        self.store = ComicDirectorStore()
        self.builder = DirectedPromptBuilder(continuity_store)
        self.current_panel: PanelCell | None = None
        self._build_ui()
        self.refresh_assets()
        self.refresh_panel_list()
        self.new_panel()

    def _build_ui(self):
        root = QHBoxLayout(self)
        left = QVBoxLayout()
        mid = QVBoxLayout()
        right = QVBoxLayout()
        root.addLayout(left, 1)
        root.addLayout(mid, 2)
        root.addLayout(right, 2)

        left.addWidget(QLabel("Storyboard Cells"))
        self.panel_list = QListWidget()
        self.panel_list.itemSelectionChanged.connect(self.load_selected_panel)
        left.addWidget(self.panel_list)
        row = QHBoxLayout()
        add = QPushButton("+ Cell")
        delete = QPushButton("Delete")
        add.clicked.connect(self.new_panel)
        delete.clicked.connect(self.delete_current_panel)
        row.addWidget(add); row.addWidget(delete)
        left.addLayout(row)
        left.addWidget(QLabel("Each cell stores its own prompt, selected characters, location, and generated final prompt."))

        form = QFormLayout()
        self.page_edit = QLineEdit("Page 1")
        self.panel_spin = QSpinBox(); self.panel_spin.setRange(1, 200); self.panel_spin.setValue(1)
        form.addRow("Page", self.page_edit)
        form.addRow("Cell / Panel #", self.panel_spin)
        mid.addLayout(form)

        mid.addWidget(QLabel("User prompt for this cell"))
        self.user_prompt = QPlainTextEdit()
        self.user_prompt.setPlaceholderText("Example: John enters the old church and sees the priest kneeling near the altar. Wide shot, suspenseful mood.")
        mid.addWidget(self.user_prompt, 2)

        self.character_checks_box = QGroupBox("Reusable Characters in this cell")
        self.character_checks_layout = QVBoxLayout(self.character_checks_box)
        mid.addWidget(self.character_checks_box, 1)

        self.location_combo = QComboBox()
        mid.addWidget(QLabel("Reusable Location for this cell"))
        mid.addWidget(self.location_combo)

        grid = QGridLayout()
        self.camera_combo = QComboBox(); self.camera_combo.addItems(CAMERA_PRESETS); self.camera_combo.setEditable(True)
        self.mood_combo = QComboBox(); self.mood_combo.addItems(MOOD_PRESETS); self.mood_combo.setEditable(True)
        self.style_combo = QComboBox(); self.style_combo.addItems(STYLE_PRESETS); self.style_combo.setEditable(True)
        grid.addWidget(QLabel("Camera"), 0, 0); grid.addWidget(self.camera_combo, 0, 1)
        grid.addWidget(QLabel("Mood"), 1, 0); grid.addWidget(self.mood_combo, 1, 1)
        grid.addWidget(QLabel("Style"), 2, 0); grid.addWidget(self.style_combo, 2, 1)
        mid.addLayout(grid)

        self.dialogue_edit = QPlainTextEdit(); self.dialogue_edit.setPlaceholderText("Optional dialogue/caption for this cell. The prompt will reserve clean space for it.")
        self.dialogue_edit.setMaximumHeight(90)
        self.notes_edit = QPlainTextEdit(); self.notes_edit.setPlaceholderText("Optional director notes: composition, emotion, lighting, what to preserve/change.")
        self.notes_edit.setMaximumHeight(90)
        mid.addWidget(QLabel("Dialogue / caption text")); mid.addWidget(self.dialogue_edit)
        mid.addWidget(QLabel("Director notes")); mid.addWidget(self.notes_edit)

        locks = QGroupBox("Continuity Locks")
        locks_layout = QVBoxLayout(locks)
        self.lock_chars = QCheckBox("Keep selected character design consistent")
        self.lock_locs = QCheckBox("Keep selected location consistent")
        self.prev_ref = QCheckBox("Use previous cell as visual reference")
        self.prev_strength = QDoubleSpinBox(); self.prev_strength.setRange(0.05, 1.0); self.prev_strength.setSingleStep(0.05); self.prev_strength.setValue(0.45)
        self.lock_chars.setChecked(True); self.lock_locs.setChecked(True)
        locks_layout.addWidget(self.lock_chars); locks_layout.addWidget(self.lock_locs); locks_layout.addWidget(self.prev_ref)
        prev_row = QHBoxLayout(); prev_row.addWidget(QLabel("Previous-cell strength")); prev_row.addWidget(self.prev_strength); locks_layout.addLayout(prev_row)
        mid.addWidget(locks)

        btn_row = QHBoxLayout()
        save = QPushButton("Save Cell")
        build = QPushButton("Build Final Prompt")
        send = QPushButton("Send Prompt to Studio")
        save.clicked.connect(self.save_current_panel)
        build.clicked.connect(self.build_prompt)
        send.clicked.connect(self.send_to_studio)
        btn_row.addWidget(save); btn_row.addWidget(build); btn_row.addWidget(send)
        mid.addLayout(btn_row)

        right.addWidget(QLabel("Final generated prompt sent to ComfyUI"))
        self.final_prompt = QPlainTextEdit()
        right.addWidget(self.final_prompt, 3)
        right.addWidget(QLabel("Asset summary"))
        self.asset_summary = QTextEdit(); self.asset_summary.setReadOnly(True)
        right.addWidget(self.asset_summary, 2)
        refresh = QPushButton("Refresh Characters / Locations")
        refresh.clicked.connect(self.refresh_assets)
        right.addWidget(refresh)

    def refresh_assets(self):
        # Characters
        for i in reversed(range(self.character_checks_layout.count())):
            item = self.character_checks_layout.itemAt(i)
            widget = item.widget()
            if widget:
                widget.deleteLater()
        self.char_checks: dict[str, QCheckBox] = {}
        for char in self.continuity_store.characters():
            cb = QCheckBox(char.name)
            cb.setToolTip(char.prompt_block())
            self.char_checks[char.id] = cb
            self.character_checks_layout.addWidget(cb)
        self.character_checks_layout.addStretch(1)

        # Locations
        current = self.location_combo.currentData()
        self.location_combo.clear()
        self.location_combo.addItem("No reusable location", "")
        for loc in self.continuity_store.locations():
            self.location_combo.addItem(loc.name, loc.id)
        if current:
            idx = self.location_combo.findData(current)
            if idx >= 0:
                self.location_combo.setCurrentIndex(idx)
        self.update_asset_summary()

    def update_asset_summary(self):
        chars = self.continuity_store.characters()
        locs = self.continuity_store.locations()
        lines = ["Characters:"]
        for c in chars:
            refs = len(c.reference_slots or [])
            lines.append(f"- {c.name} ({refs} reference slots): {c.description[:120]}")
        lines.append("\nLocations:")
        for l in locs:
            lines.append(f"- {l.name}: {l.description[:140]}")
        self.asset_summary.setPlainText("\n".join(lines))

    def refresh_panel_list(self):
        self.panel_list.clear()
        for panel in self.store.panels():
            item = QListWidgetItem(f"{panel.page} — Cell {panel.panel_number}: {panel.user_prompt[:45]}")
            item.setData(Qt.UserRole, panel.id)
            self.panel_list.addItem(item)

    def new_panel(self):
        page = self.page_edit.text().strip() if hasattr(self, "page_edit") else "Page 1"
        self.current_panel = self.store.new_panel(page)
        self.load_panel_into_form(self.current_panel)

    def delete_current_panel(self):
        if not self.current_panel:
            return
        self.store.delete_panel(self.current_panel.id)
        self.refresh_panel_list()
        self.new_panel()

    def load_selected_panel(self):
        items = self.panel_list.selectedItems()
        if not items:
            return
        panel_id = items[0].data(Qt.UserRole)
        for panel in self.store.panels():
            if panel.id == panel_id:
                self.current_panel = panel
                self.load_panel_into_form(panel)
                break

    def load_panel_into_form(self, panel: PanelCell):
        self.page_edit.setText(panel.page)
        self.panel_spin.setValue(panel.panel_number)
        self.user_prompt.setPlainText(panel.user_prompt)
        for cid, cb in getattr(self, "char_checks", {}).items():
            cb.setChecked(cid in (panel.character_ids or []))
        loc_idx = self.location_combo.findData(panel.location_id)
        self.location_combo.setCurrentIndex(loc_idx if loc_idx >= 0 else 0)
        self.camera_combo.setCurrentText(panel.camera)
        self.mood_combo.setCurrentText(panel.mood)
        self.style_combo.setCurrentText(panel.style)
        self.lock_chars.setChecked(panel.locked_character_continuity)
        self.lock_locs.setChecked(panel.locked_location_continuity)
        self.prev_ref.setChecked(panel.use_previous_panel_reference)
        self.prev_strength.setValue(panel.previous_panel_strength)
        self.dialogue_edit.setPlainText(panel.dialogue)
        self.notes_edit.setPlainText(panel.director_notes)
        self.final_prompt.setPlainText(panel.generated_prompt)

    def collect_panel_from_form(self) -> PanelCell:
        panel = self.current_panel or self.store.new_panel(self.page_edit.text().strip() or "Page 1")
        panel.page = self.page_edit.text().strip() or "Page 1"
        panel.panel_number = self.panel_spin.value()
        panel.user_prompt = self.user_prompt.toPlainText().strip()
        panel.character_ids = [cid for cid, cb in self.char_checks.items() if cb.isChecked()]
        panel.location_id = self.location_combo.currentData() or ""
        panel.camera = self.camera_combo.currentText().strip()
        panel.mood = self.mood_combo.currentText().strip()
        panel.style = self.style_combo.currentText().strip()
        panel.locked_character_continuity = self.lock_chars.isChecked()
        panel.locked_location_continuity = self.lock_locs.isChecked()
        panel.use_previous_panel_reference = self.prev_ref.isChecked()
        panel.previous_panel_strength = self.prev_strength.value()
        panel.dialogue = self.dialogue_edit.toPlainText().strip()
        panel.director_notes = self.notes_edit.toPlainText().strip()
        panel.generated_prompt = self.final_prompt.toPlainText().strip()
        return panel

    def save_current_panel(self):
        panel = self.collect_panel_from_form()
        self.store.upsert_panel(panel)
        self.current_panel = panel
        self.refresh_panel_list()

    def build_prompt(self):
        panel = self.collect_panel_from_form()
        prompt = self.builder.build(panel)
        panel.generated_prompt = prompt
        self.final_prompt.setPlainText(prompt)
        self.store.upsert_panel(panel)
        self.current_panel = panel
        self.refresh_panel_list()

    def send_to_studio(self):
        self.build_prompt()
        parent = self.parent()
        if parent and hasattr(parent, "prompt"):
            parent.prompt.setPlainText(self.final_prompt.toPlainText())
            if hasattr(parent, "log"):
                parent.log("AI Director prompt sent to Studio. Choose generation mode and click Generate Panel with ComfyUI.")
        self.accept()
