from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Optional

from .paths import data_dir


@dataclass
class LetteringData:
    id: str
    kind: str  # speech, caption, sfx
    text: str
    x: float
    y: float
    w: float = 260
    h: float = 120
    font_size: int = 28
    bubble: bool = True
    tail_x: float = 0
    tail_y: float = 0


@dataclass
class PanelData:
    id: str
    x: float
    y: float
    w: float
    h: float
    image_path: str = ""
    caption: str = ""


@dataclass
class PageLayoutData:
    title: str
    width: int
    height: int
    panels: List[PanelData]
    lettering: List[LetteringData]


class PageLayoutStore:
    """JSON-backed page-layout storage for comic pages."""

    def __init__(self):
        self.root = data_dir() / "page_layouts"
        self.root.mkdir(parents=True, exist_ok=True)

    def list_pages(self) -> list[Path]:
        return sorted(self.root.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)

    def default_page(self, title: str = "Untitled Page", width: int = 1200, height: int = 1800) -> PageLayoutData:
        return PageLayoutData(title=title, width=width, height=height, panels=[], lettering=[])

    def save(self, layout: PageLayoutData, filename: Optional[str] = None) -> Path:
        safe = filename or self._safe_name(layout.title)
        if not safe.endswith(".json"):
            safe += ".json"
        path = self.root / safe
        payload = asdict(layout)
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return path

    def load(self, path: str | Path) -> PageLayoutData:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        return PageLayoutData(
            title=payload.get("title", "Untitled Page"),
            width=int(payload.get("width", 1200)),
            height=int(payload.get("height", 1800)),
            panels=[PanelData(**p) for p in payload.get("panels", [])],
            lettering=[LetteringData(**l) for l in payload.get("lettering", [])],
        )

    def make_panel(self, x: float, y: float, w: float, h: float, image_path: str = "") -> PanelData:
        return PanelData(id=str(uuid.uuid4()), x=x, y=y, w=w, h=h, image_path=image_path)

    def make_lettering(self, kind: str, text: str, x: float, y: float, font_size: int = 28) -> LetteringData:
        bubble = kind in ("speech", "caption")
        w = 320 if kind != "sfx" else 420
        h = 130 if kind != "caption" else 90
        return LetteringData(id=str(uuid.uuid4()), kind=kind, text=text, x=x, y=y, w=w, h=h, font_size=font_size, bubble=bubble)

    def template(self, name: str, width: int = 1200, height: int = 1800) -> PageLayoutData:
        layout = self.default_page(name, width, height)
        margin = 70
        gutter = 35
        usable_w = width - margin * 2
        usable_h = height - margin * 2
        if name == "3 Row Page":
            ph = (usable_h - 2 * gutter) / 3
            for i in range(3):
                layout.panels.append(self.make_panel(margin, margin + i * (ph + gutter), usable_w, ph))
        elif name == "6 Panel Grid":
            pw = (usable_w - gutter) / 2
            ph = (usable_h - 2 * gutter) / 3
            for r in range(3):
                for c in range(2):
                    layout.panels.append(self.make_panel(margin + c * (pw + gutter), margin + r * (ph + gutter), pw, ph))
        elif name == "Splash + 2 Bottom":
            top_h = usable_h * 0.62
            layout.panels.append(self.make_panel(margin, margin, usable_w, top_h))
            bottom_h = usable_h - top_h - gutter
            bottom_w = (usable_w - gutter) / 2
            y = margin + top_h + gutter
            layout.panels.append(self.make_panel(margin, y, bottom_w, bottom_h))
            layout.panels.append(self.make_panel(margin + bottom_w + gutter, y, bottom_w, bottom_h))
        else:
            layout.panels.append(self.make_panel(margin, margin, usable_w, usable_h))
        return layout

    def _safe_name(self, title: str) -> str:
        clean = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in title.strip().lower())
        return clean or "untitled_page"
