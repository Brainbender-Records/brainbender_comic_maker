from __future__ import annotations

import json
import shutil
from datetime import datetime
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

from PIL import Image
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter


class Exporter:
    """Export helpers for generated panels and finished comic pages."""

    def export_contact_pdf(self, images, dest):
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        c = canvas.Canvas(str(dest), pagesize=letter)
        w, h = letter
        x, y = 40, h - 240
        for img in images:
            p = Path(img)
            if not p.exists():
                continue
            c.drawImage(str(p), x, y, width=220, height=220, preserveAspectRatio=True, mask="auto")
            c.drawString(x, y - 14, p.name[:35])
            x += 260
            if x > 330:
                x = 40
                y -= 280
            if y < 60:
                c.showPage()
                x, y = 40, h - 240
        c.save()
        return str(dest)

    def export_cbz(self, images, dest):
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        with ZipFile(dest, "w", ZIP_DEFLATED) as z:
            for n, img in enumerate(images, 1):
                p = Path(img)
                if p.exists():
                    z.write(p, f"{n:03d}_{p.name}")
        return str(dest)

    def export_book(self, *, page_images, dest_dir, title="Brainbender Comic", author="", cover_image=""):
        """Export ordered page images as PDF, CBZ, PNG release folder, and manifest.

        page_images should be a list of already-rendered page PNG/JPG files, usually
        created by the Page Layout + Lettering Editor.
        """
        dest_dir = Path(dest_dir).expanduser()
        release_dir = dest_dir / self._safe_name(title)
        pages_dir = release_dir / "pages"
        pages_dir.mkdir(parents=True, exist_ok=True)

        ordered = []
        cover = Path(cover_image).expanduser() if cover_image else None
        if cover and cover.exists():
            ordered.append(cover)
        for img in page_images:
            p = Path(img).expanduser()
            if p.exists():
                ordered.append(p)
        if not ordered:
            raise ValueError("No valid page images were selected for export.")

        copied = []
        for idx, src in enumerate(ordered, 1):
            suffix = src.suffix.lower() if src.suffix else ".png"
            dest = pages_dir / f"{idx:03d}{suffix}"
            shutil.copy2(src, dest)
            copied.append(dest)

        pdf_path = release_dir / f"{self._safe_name(title)}.pdf"
        cbz_path = release_dir / f"{self._safe_name(title)}.cbz"
        manifest_path = release_dir / "export_manifest.json"

        self._write_pdf(copied, pdf_path, title=title, author=author)
        self.export_cbz(copied, cbz_path)

        manifest = {
            "title": title,
            "author": author,
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "page_count": len(copied),
            "pdf": str(pdf_path),
            "cbz": str(cbz_path),
            "pages": [str(p) for p in copied],
        }
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        return manifest

    def _write_pdf(self, page_images, pdf_path, title="Brainbender Comic", author=""):
        pdf_path = Path(pdf_path)
        pdf_path.parent.mkdir(parents=True, exist_ok=True)
        first = True
        c = None
        for img_path in page_images:
            img_path = Path(img_path)
            with Image.open(img_path) as im:
                width, height = im.size
            if c is None:
                c = canvas.Canvas(str(pdf_path), pagesize=(width, height))
                c.setTitle(title)
                if author:
                    c.setAuthor(author)
            if not first:
                c.setPageSize((width, height))
            first = False
            c.drawImage(ImageReader(str(img_path)), 0, 0, width=width, height=height, preserveAspectRatio=True, mask="auto")
            c.showPage()
        if c is None:
            raise ValueError("No images to write into PDF.")
        c.save()
        return str(pdf_path)

    def _safe_name(self, text):
        clean = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in str(text).strip().lower())
        while "__" in clean:
            clean = clean.replace("__", "_")
        return clean.strip("_") or "brainbender_comic"
