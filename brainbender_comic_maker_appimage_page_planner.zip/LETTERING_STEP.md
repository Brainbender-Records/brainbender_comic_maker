# Lettering Step

This update adds comic lettering directly to the page editor.

## Added

- Speech bubble items
- Caption boxes
- Sound effect text
- Font size control
- Bubble/box width and height controls
- Movable lettering objects on the page canvas
- Save/load lettering data inside the page layout JSON
- Export lettered comic pages as PNG

## How to use

1. Open **Page Layout Editor**.
2. Assign images to panels if desired.
3. Choose **speech**, **caption**, or **sfx**.
4. Enter text and click **Add Lettering**.
5. Drag the lettering into position on the page.
6. Use **Save Layout JSON** to preserve editable lettering.
7. Use **Export Lettered Page PNG** for the flattened final page.

## Next recommended step

Add full comic-book export using saved page layouts:

- Load multiple saved page JSON files
- Render each page in order
- Export PDF
- Export CBZ
- Add cover image and comic metadata
