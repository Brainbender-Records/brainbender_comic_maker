# Brainbender Comic Maker

Open and free AI comic-making frontend for Ubuntu, designed to work with ComfyUI.

This AppImage-ready version now includes real ComfyUI API wiring for:

- Text-to-image panel generation
- Image + text reference generation through img2img
- ComfyUI auto-start/check button
- Checkpoint model detection and import
- Prompt, negative prompt, steps, CFG, seed, size, and denoise controls
- Placeholder panel creation for testing without a model
- Character/location continuity notes
- PDF contact sheet and CBZ export starter tools

## Development run on Ubuntu

```bash
unzip brainbender_comic_maker_appimage_next.zip -d brainbender_comic_maker
cd brainbender_comic_maker
./install_ubuntu_dev.sh
./start.sh
```

## ComfyUI setup

Brainbender Comic Maker is the frontend. ComfyUI is the image-generation backend.

1. Install ComfyUI separately.
2. Add at least one checkpoint model to:

```text
ComfyUI/models/checkpoints/
```

3. In Brainbender Comic Maker, open **Settings**.
4. Choose your ComfyUI folder.
5. Click **Start / Check ComfyUI**.
6. Return to **Studio**, refresh models, and generate.

## Build AppImage/AppDir

```bash
./packaging/appimage/build_appimage.sh
```

The script creates an AppDir and will create an AppImage if `appimagetool` is available.

## Notes

ComfyUI workflows are generated in Python in:

```text
src/brainbender/comfy/workflows.py
```

This keeps the app simpler than shipping separate JSON workflows for the first version.

## New: ComfyUI installer helper

Open **Settings → Install / Update ComfyUI** or use the first-run wizard. The helper can clone/update ComfyUI, create its virtual environment, install requirements, and save the path for one-click startup.

After that, import a `.safetensors` or `.ckpt` checkpoint with **Import Checkpoint Model File**.

## Workflow presets

This build includes a Workflow Preset Manager. Open it from the Studio tab or Settings tab. Presets can change image size, steps, CFG, sampler, scheduler, denoise, and prompt prefix/suffix text.

The included ControlNet/IPAdapter presets are intentionally marked as future workflow placeholders until those ComfyUI custom nodes and model paths are installed and validated.

## Latest step: Book Export

This AppImage-ready build now includes a Comic Book Exporter for ordering finished pages, adding an optional cover, and exporting PDF + CBZ + numbered page files with a manifest.

## AI Comic Director workflow

This build includes an **AI Comic Director** tab. It is designed around comic cells/panels. The user writes a prompt for each cell, then selects reusable Characters and Locations to keep continuity between panels. The final prompt can be sent to the Studio tab for ComfyUI generation.

See `AI_COMIC_DIRECTOR_STEP.md` for details.

## Latest addition: AI Comic Director Page Planner

The Page Planner lets creators design a full comic page with multiple cells. Each cell has its own prompt, while selected reusable Characters and Locations provide continuity details behind the scenes.

Open it from:

`AI Comic Director` tab → `Open AI Comic Director — Page Planner`
