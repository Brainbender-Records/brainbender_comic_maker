# AI Comic Director Page Planner Step

This step adds a page-first planning layer to Brainbender Comic Maker.

## What changed

- Added **AI Comic Director — Page Planner**.
- Users can create a page, choose a template, and generate multiple comic cells/panels.
- Every cell has its own user-written prompt.
- A page can have default reusable Characters and a default reusable Location.
- The app can build all final prompts for the page by combining:
  - the user's cell prompt,
  - selected character continuity details,
  - selected location continuity details,
  - camera/style/mood settings,
  - dialogue/caption notes.
- A selected cell prompt can be sent to the Studio tab for ComfyUI generation.

## Design goal

The artist controls each cell. Brainbender manages continuity.

This keeps the workflow creative and understandable while still using reusable character/location reference data to make panels more consistent.

## Next recommended step

Add a **page generation queue**:

1. Build all prompts for a page.
2. Queue each cell for ComfyUI generation.
3. Save the generated image path back onto each cell.
4. Send those images into the visual page editor automatically.
