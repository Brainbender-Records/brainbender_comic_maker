# AI Comic Director + Reusable Characters/Locations Step

This build adds the first version of the AI Comic Director workflow.

## Design goal

The artist writes a prompt for each comic cell/panel. Brainbender Comic Maker then adds reusable continuity information from selected Characters and Locations.

This keeps the user in creative control while improving continuity between cells.

## Added features

- New **AI Comic Director** tab
- One prompt box per comic cell/panel
- Reusable Character selection per cell
- Reusable Location selection per cell
- Camera, mood, and style presets
- Dialogue/caption field per cell
- Director notes per cell
- Continuity locks:
  - Keep selected character design consistent
  - Keep selected location consistent
  - Use previous cell as visual reference
- Final prompt builder
- Send final prompt to Studio for ComfyUI generation
- Saved panel/cell metadata in the app data folder

## Recommended workflow

1. Open **Characters & Continuity**.
2. Create Characters with reference sheets and visual notes.
3. Create Locations with reference images and environment notes.
4. Open **AI Comic Director**.
5. Create a cell/panel.
6. Type what should happen in that cell.
7. Select the Characters and Location used in that cell.
8. Click **Build Final Prompt**.
9. Click **Send Prompt to Studio**.
10. Generate the panel using ComfyUI.

## Next recommended implementation

The next step should connect character/location reference sheet images directly to ComfyUI generation modes:

- Use selected character reference sheet with IPAdapter.
- Use selected location reference image with img2img/IPAdapter.
- Let each panel choose which reference slot to send.
- Save generated panel paths back into the cell record automatically.
