# Book Export / Publishing Step

This update adds a real export workflow for finished comic pages.

## New features

- Comic Book Exporter window
- Ordered page list
- Optional cover image
- Author/publisher metadata field
- Export folder selector
- PDF export with one image per page
- CBZ export for comic readers
- Copied numbered PNG/JPG release pages
- `export_manifest.json` with title, author, page count, and output paths

## Suggested workflow

1. Generate panels in the Studio tab.
2. Open the Page Layout + Lettering Editor.
3. Create a finished comic page and export it as PNG.
4. Open the Export tab.
5. Click **Open Comic Book Exporter**.
6. Order your finished pages.
7. Optional: choose a cover image.
8. Export PDF + CBZ + release folder.

## Notes

The exporter looks for page PNGs created by the page editor in the app data `exports` folder. You can also manually add any PNG/JPG page images.
