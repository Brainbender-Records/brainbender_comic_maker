# Brainbender Comic Maker - Wheel Install

This build artifact was generated from Phase 8.

## Install on Ubuntu

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install brainbender_comic_maker-0.8.0-py3-none-any.whl
brainbender-comic-maker
```

If Qt display packages are missing on your system, run:

```bash
sudo apt update
sudo apt install -y libgl1 libegl1 libxkbcommon0 libxcb-cursor0 libxcb-icccm4 libxcb-image0 libxcb-keysyms1 libxcb-randr0 libxcb-render-util0 libxcb-shape0 libxcb-xinerama0 libxcb-xinput0 libxcb-xfixes0
```
