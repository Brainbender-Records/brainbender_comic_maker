# AI Director Page Assembly Step

This step connects the AI Comic Director page planner to the visual page editor.

## What it adds

- A new **Assemble Generated Cells into Page Layout** button in the AI Comic Director tab.
- Converts planned page cells into a visual comic page layout.
- Places each generated cell image into a matching panel box.
- Converts cell dialogue/captions into editable speech lettering.
- Saves the page as reusable page-layout JSON.
- Opens the assembled page directly in the Page Layout + Lettering Editor.

## Intended workflow

1. Create reusable Characters and Locations.
2. Plan a page in **AI Comic Director — Page Planner**.
3. Write a prompt for each cell.
4. Batch-generate the planned page.
5. Click **Assemble Generated Cells into Page Layout**.
6. Open it in the page editor.
7. Adjust panels, bubbles, captions, and export the finished page PNG.

This keeps the user in control of each comic cell while Brainbender handles continuity and page assembly.
