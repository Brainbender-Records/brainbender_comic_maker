# AI Comic Director Batch Generation Step

This update connects the Page Planner to real multi-cell generation.

## Added

- **Batch Generate Planned Page** button on the AI Comic Director tab.
- A batch generation dialog that lists planned pages and shows how many cells already have images.
- Sequential ComfyUI generation for every cell on a selected page.
- Automatic prompt building for cells that do not yet have a final prompt.
- Saved generated image path back onto each cell.
- Cell list now marks linked/generated cells with an image icon.
- Page Planner can attach the last Studio image to a selected cell.

## Current behavior

Batch generation uses text-to-image mode for each planned cell. Character/location continuity is included through the AI Director prompt builder. Advanced reference workflows such as IPAdapter/ControlNet are still available in Studio, but page-batch reference selection is a future improvement.

## Next recommended step

Add a **Page Assembly Bridge** that takes the generated images linked to planned cells and automatically creates a visual page layout in the Page Editor.
