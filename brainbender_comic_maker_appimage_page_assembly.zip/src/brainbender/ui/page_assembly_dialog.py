from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox, QDialog, QGridLayout, QHBoxLayout, QLabel, QListWidget, QListWidgetItem,
    QMessageBox, QPushButton, QSpinBox, QPlainTextEdit, QVBoxLayout
)

from ..director.page_assembler import PageAssembler, DIRECTOR_TEMPLATE_TO_LAYOUT
from ..director.page_planner import PagePlanStore
from .page_editor_dialog import PageEditorDialog


class PageAssemblyDialog(QDialog):
    """Turn an AI Director page plan into a visual page layout automatically."""

    def __init__(self, generated_images: list[str] | None = None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("AI Comic Director — Assemble Page Layout")
        self.resize(980, 650)
        self.generated_images = generated_images or []
        self.plan_store = PagePlanStore()
        self.assembler = PageAssembler()
        self.last_layout_path: Path | None = None
        self._build_ui()
        self.refresh_pages()

    def _build_ui(self):
        root = QVBoxLayout(self)
        info = QLabel(
            "Choose a planned AI Director page. Brainbender will place each generated cell image "
            "into a comic page template and optionally convert each cell's dialogue into editable lettering."
        )
        info.setWordWrap(True)
        root.addWidget(info)

        body = QHBoxLayout(); root.addLayout(body, 1)
        left = QVBoxLayout(); right = QVBoxLayout(); body.addLayout(left, 1); body.addLayout(right, 2)
        left.addWidget(QLabel("AI Director Pages"))
        self.page_list = QListWidget(); self.page_list.currentItemChanged.connect(self.preview_selected)
        left.addWidget(self.page_list, 1)
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self.refresh_pages)
        left.addWidget(refresh)

        grid = QGridLayout(); right.addLayout(grid)
        self.width = QSpinBox(); self.width.setRange(600, 4000); self.width.setValue(1200); self.width.setSingleStep(100)
        self.height = QSpinBox(); self.height.setRange(800, 6000); self.height.setValue(1800); self.height.setSingleStep(100)
        self.include_dialogue = QCheckBox("Convert cell dialogue/captions into editable page lettering")
        self.include_dialogue.setChecked(True)
        self.include_labels = QCheckBox("Show small cell labels in panels")
        grid.addWidget(QLabel("Page width"), 0, 0); grid.addWidget(self.width, 0, 1)
        grid.addWidget(QLabel("Page height"), 0, 2); grid.addWidget(self.height, 0, 3)
        grid.addWidget(self.include_dialogue, 1, 0, 1, 4)
        grid.addWidget(self.include_labels, 2, 0, 1, 4)

        right.addWidget(QLabel("Selected Page Preview"))
        self.preview = QPlainTextEdit(); self.preview.setReadOnly(True)
        right.addWidget(self.preview, 1)

        buttons = QHBoxLayout(); root.addLayout(buttons)
        assemble = QPushButton("Assemble Page Layout JSON")
        open_editor = QPushButton("Open Assembled Page in Editor")
        close = QPushButton("Close")
        assemble.clicked.connect(self.assemble_selected)
        open_editor.clicked.connect(self.open_editor)
        close.clicked.connect(self.accept)
        buttons.addWidget(assemble); buttons.addWidget(open_editor); buttons.addStretch(1); buttons.addWidget(close)

    def refresh_pages(self):
        self.page_list.clear()
        for plan in self.plan_store.plans():
            panels = self.plan_store.panels_for_plan(plan)
            generated = sum(1 for p in panels if p.generated_image)
            template = DIRECTOR_TEMPLATE_TO_LAYOUT.get(plan.template_name, "6 Panel Grid")
            item = QListWidgetItem(f"{plan.page_name} — {len(panels)} cells, {generated} generated → {template}")
            item.setData(Qt.UserRole, plan.id)
            self.page_list.addItem(item)

    def selected_plan_id(self) -> str:
        item = self.page_list.currentItem()
        return item.data(Qt.UserRole) if item else ""

    def preview_selected(self):
        plan_id = self.selected_plan_id()
        plans = {p.id: p for p in self.plan_store.plans()}
        plan = plans.get(plan_id)
        if not plan:
            self.preview.clear(); return
        lines = [
            f"Page: {plan.page_name}",
            f"Title: {plan.title}",
            f"Template: {plan.template_name}",
            f"Visual layout: {DIRECTOR_TEMPLATE_TO_LAYOUT.get(plan.template_name, '6 Panel Grid')}",
            f"Summary: {plan.summary}",
            "",
        ]
        for cell in self.plan_store.panels_for_plan(plan):
            lines.append(f"Cell {cell.panel_number}")
            lines.append(f"Prompt: {cell.user_prompt or '[empty]'}")
            if cell.dialogue:
                lines.append(f"Dialogue: {cell.dialogue}")
            lines.append(f"Image: {cell.generated_image or '[not generated]'}")
            lines.append("")
        self.preview.setPlainText("\n".join(lines))

    def assemble_selected(self):
        plan_id = self.selected_plan_id()
        if not plan_id:
            QMessageBox.warning(self, "No page selected", "Select an AI Director page first.")
            return
        try:
            self.last_layout_path = self.assembler.save_layout_from_plan(
                plan_id,
                width=self.width.value(),
                height=self.height.value(),
                include_dialogue=self.include_dialogue.isChecked(),
                include_cell_labels=self.include_labels.isChecked(),
            )
            QMessageBox.information(self, "Page assembled", f"Saved page layout JSON:\n{self.last_layout_path}")
        except Exception as exc:
            QMessageBox.critical(self, "Assembly failed", str(exc))

    def open_editor(self):
        if self.last_layout_path is None:
            self.assemble_selected()
        if self.last_layout_path is None:
            return
        dlg = PageEditorDialog(self.generated_images, self)
        try:
            dlg.layout_data = dlg.store.load(self.last_layout_path)
            dlg.title_edit.setText(dlg.layout_data.title)
            dlg.page_width.setValue(dlg.layout_data.width)
            dlg.page_height.setValue(dlg.layout_data.height)
            dlg.render_layout()
        except Exception as exc:
            QMessageBox.critical(self, "Open editor failed", str(exc))
            return
        dlg.exec()
