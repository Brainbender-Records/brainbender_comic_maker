from __future__ import annotations

from pathlib import Path

from ..core.page_layout import LetteringData, PageLayoutData, PageLayoutStore, PanelData
from .page_planner import PagePlan, PagePlanStore


DIRECTOR_TEMPLATE_TO_LAYOUT = {
    "3 cells - top wide + two bottom": "Splash + 2 Bottom",
    "4 cells - balanced grid": "4 Panel Grid",
    "6 cells - classic comic page": "6 Panel Grid",
}


class PageAssembler:
    """Converts AI Comic Director page plans into visual page-layout JSON files.

    The Director is where users write per-cell prompts and attach reusable character/location
    continuity. The page editor is where panels become printable comic pages. This class bridges
    those two parts by taking the generated cell images/dialogue and placing them into a page
    template automatically.
    """

    def __init__(self):
        self.plan_store = PagePlanStore()
        self.layout_store = PageLayoutStore()

    def build_layout_from_plan(
        self,
        plan: PagePlan,
        *,
        width: int = 1200,
        height: int = 1800,
        include_dialogue: bool = True,
        include_cell_labels: bool = False,
    ) -> PageLayoutData:
        layout_name = DIRECTOR_TEMPLATE_TO_LAYOUT.get(plan.template_name, "6 Panel Grid")
        layout = self.layout_store.template(layout_name, width, height)
        layout.title = plan.page_name or plan.title or "AI Director Page"
        panels = self.plan_store.panels_for_plan(plan)

        # Make sure the visual page has enough panel boxes for all planned cells.
        while len(layout.panels) < len(panels):
            index = len(layout.panels)
            col = index % 2
            row = index // 2
            margin = 70
            gutter = 35
            usable_w = width - margin * 2
            pw = (usable_w - gutter) / 2
            ph = 430
            x = margin + col * (pw + gutter)
            y = margin + row * (ph + gutter)
            layout.panels.append(self.layout_store.make_panel(x, y, pw, ph))

        for index, cell in enumerate(panels):
            box = layout.panels[index]
            box.caption = f"Cell {cell.panel_number}" if include_cell_labels else ""
            if cell.generated_image and Path(cell.generated_image).exists():
                box.image_path = cell.generated_image
            elif cell.generated_image:
                # Keep the path anyway so users can fix moved files later.
                box.image_path = cell.generated_image

            if include_dialogue and cell.dialogue.strip():
                # Place dialogue near the top-left of the corresponding panel.
                lettering = LetteringData(
                    id=f"letter-{cell.id}",
                    kind="speech",
                    text=cell.dialogue.strip(),
                    x=box.x + 24,
                    y=box.y + 24,
                    w=min(360, max(220, box.w * 0.55)),
                    h=110,
                    font_size=24,
                    bubble=True,
                )
                layout.lettering.append(lettering)

        return layout

    def save_layout_from_plan(self, plan_id: str, **kwargs) -> Path:
        plans = {p.id: p for p in self.plan_store.plans()}
        if plan_id not in plans:
            raise ValueError("Selected AI Director page plan was not found.")
        layout = self.build_layout_from_plan(plans[plan_id], **kwargs)
        safe = f"director_{layout.title}".replace(" ", "_").lower()
        return self.layout_store.save(layout, safe)
