# Brainbender Comic Maker - Phase 3

Open and free Linux desktop starter app for comic creation with ComfyUI as the Stable Diffusion backend.

## Phase 3 additions

Phase 3 adds real comic project organization:

- Comic book projects
- Chapters inside each project
- Pages inside chapters
- Page title, script, and notes
- Panels attached to pages
- Add the latest generated image as a panel
- Add an existing image file as a panel
- Persistent JSON autosave-style storage under your user data folder

## Earlier features included

- PySide6 desktop GUI
- ComfyUI detection and auto-start support
- Model detection and local model import
- Text-to-image generation
- Image-to-image / reference image generation
- Character profiles and reference images
- Prompt templates
- Style / LoRA preset notes
- Generation history
- Snap packaging starter files

## Install on Ubuntu

```bash
cd ~/Downloads
unzip brainbender_comic_maker_phase3.zip -d brainbender_comic_maker_phase3
cd brainbender_comic_maker_phase3
./install_ubuntu.sh
./start.sh
```

## ComfyUI connection

Set your ComfyUI folder in **Settings / Models**. The app will try to start ComfyUI if it is not already running.

Default ComfyUI URL:

```text
http://127.0.0.1:8188
```

Put Stable Diffusion checkpoints in:

```text
ComfyUI/models/checkpoints/
```

or use **Import Local Model File** in the app.

## Phase 4 target

The next phase should replace the basic page organization view with a drag-and-drop visual comic page editor.
