#!/usr/bin/env python3
from brainbender_comic_maker.main import main

if __name__ == '__main__':
    main()
