import json, time, uuid, base64
from pathlib import Path
import requests

class ComfyClient:
    def __init__(self, url='http://127.0.0.1:8188'):
        self.url = url.rstrip('/')
        self.client_id = str(uuid.uuid4())

    def _post_prompt(self, workflow):
        r = requests.post(self.url + '/prompt', json={'prompt': workflow, 'client_id': self.client_id}, timeout=20)
        r.raise_for_status()
        return r.json()['prompt_id']

    def _history(self, prompt_id):
        r = requests.get(self.url + f'/history/{prompt_id}', timeout=10)
        r.raise_for_status()
        return r.json()

    def _download_image(self, filename, subfolder='', folder_type='output', dest_dir=None):
        params = {'filename': filename, 'subfolder': subfolder, 'type': folder_type}
        r = requests.get(self.url + '/view', params=params, timeout=60)
        r.raise_for_status()
        dest_dir = Path(dest_dir or Path.home() / '.brainbender-comic-maker' / 'outputs')
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / filename
        dest.write_bytes(r.content)
        return dest

    def _wait_for_image(self, prompt_id, dest_dir=None):
        for _ in range(180):
            h = self._history(prompt_id)
            if prompt_id in h:
                outputs = h[prompt_id].get('outputs', {})
                for node in outputs.values():
                    for img in node.get('images', []):
                        return self._download_image(img['filename'], img.get('subfolder',''), img.get('type','output'), dest_dir)
            time.sleep(1)
        raise TimeoutError('Timed out waiting for ComfyUI image output.')

    def upload_image(self, image_path):
        p = Path(image_path)
        with open(p, 'rb') as f:
            files = {'image': (p.name, f, 'application/octet-stream')}
            data = {'overwrite': 'true'}
            r = requests.post(self.url + '/upload/image', files=files, data=data, timeout=60)
        r.raise_for_status()
        return r.json().get('name', p.name)

    def txt2img(self, prompt, negative='', checkpoint='', width=768, height=768, steps=25, cfg=7.0, seed=None, dest_dir=None):
        seed = int(seed) if seed not in [None, ''] else int(time.time() * 1000) % 999999999
        workflow = basic_txt2img_workflow(prompt, negative, checkpoint, width, height, steps, cfg, seed)
        pid = self._post_prompt(workflow)
        return self._wait_for_image(pid, dest_dir), seed

    def img2img(self, image_path, prompt, negative='', checkpoint='', width=768, height=768, steps=25, cfg=7.0, denoise=0.55, seed=None, dest_dir=None):
        seed = int(seed) if seed not in [None, ''] else int(time.time() * 1000) % 999999999
        uploaded = self.upload_image(image_path)
        workflow = basic_img2img_workflow(uploaded, prompt, negative, checkpoint, width, height, steps, cfg, denoise, seed)
        pid = self._post_prompt(workflow)
        return self._wait_for_image(pid, dest_dir), seed


def basic_txt2img_workflow(prompt, negative, checkpoint, width, height, steps, cfg, seed):
    ckpt = checkpoint or 'v1-5-pruned-emaonly.ckpt'
    return {
        '1': {'class_type': 'CheckpointLoaderSimple', 'inputs': {'ckpt_name': ckpt}},
        '2': {'class_type': 'CLIPTextEncode', 'inputs': {'text': prompt, 'clip': ['1', 1]}},
        '3': {'class_type': 'CLIPTextEncode', 'inputs': {'text': negative, 'clip': ['1', 1]}},
        '4': {'class_type': 'EmptyLatentImage', 'inputs': {'width': int(width), 'height': int(height), 'batch_size': 1}},
        '5': {'class_type': 'KSampler', 'inputs': {'seed': int(seed), 'steps': int(steps), 'cfg': float(cfg), 'sampler_name': 'euler', 'scheduler': 'normal', 'denoise': 1.0, 'model': ['1', 0], 'positive': ['2', 0], 'negative': ['3', 0], 'latent_image': ['4', 0]}},
        '6': {'class_type': 'VAEDecode', 'inputs': {'samples': ['5', 0], 'vae': ['1', 2]}},
        '7': {'class_type': 'SaveImage', 'inputs': {'filename_prefix': 'Brainbender Comic Maker', 'images': ['6', 0]}},
    }

def basic_img2img_workflow(image_name, prompt, negative, checkpoint, width, height, steps, cfg, denoise, seed):
    ckpt = checkpoint or 'v1-5-pruned-emaonly.ckpt'
    return {
        '1': {'class_type': 'CheckpointLoaderSimple', 'inputs': {'ckpt_name': ckpt}},
        '2': {'class_type': 'CLIPTextEncode', 'inputs': {'text': prompt, 'clip': ['1', 1]}},
        '3': {'class_type': 'CLIPTextEncode', 'inputs': {'text': negative, 'clip': ['1', 1]}},
        '4': {'class_type': 'LoadImage', 'inputs': {'image': image_name}},
        '5': {'class_type': 'VAEEncode', 'inputs': {'pixels': ['4', 0], 'vae': ['1', 2]}},
        '6': {'class_type': 'KSampler', 'inputs': {'seed': int(seed), 'steps': int(steps), 'cfg': float(cfg), 'sampler_name': 'euler', 'scheduler': 'normal', 'denoise': float(denoise), 'model': ['1', 0], 'positive': ['2', 0], 'negative': ['3', 0], 'latent_image': ['5', 0]}},
        '7': {'class_type': 'VAEDecode', 'inputs': {'samples': ['6', 0], 'vae': ['1', 2]}},
        '8': {'class_type': 'SaveImage', 'inputs': {'filename_prefix': 'Brainbender Comic Maker', 'images': ['7', 0]}},
    }
