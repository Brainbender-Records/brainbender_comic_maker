from pathlib import Path
from datetime import datetime
import json, shutil, uuid
from .paths import HISTORY_DIR, OUTPUT_DIR, ensure_dirs

class HistoryStore:
    def __init__(self):
        ensure_dirs()

    def add(self, image_path, metadata):
        image_path = Path(image_path)
        if not image_path.exists():
            raise FileNotFoundError(image_path)
        item_id = datetime.now().strftime('%Y%m%d_%H%M%S_') + uuid.uuid4().hex[:8]
        dest = OUTPUT_DIR / f'{item_id}{image_path.suffix}'
        shutil.copy2(image_path, dest)
        meta = dict(metadata)
        meta['id'] = item_id
        meta['image'] = str(dest)
        meta['created_at'] = datetime.now().isoformat(timespec='seconds')
        (HISTORY_DIR / f'{item_id}.json').write_text(json.dumps(meta, indent=2))
        return meta

    def list_items(self):
        items = []
        for fp in sorted(HISTORY_DIR.glob('*.json'), reverse=True):
            try:
                items.append(json.loads(fp.read_text()))
            except Exception:
                pass
        return items
