import subprocess, time, socket, requests
from pathlib import Path

class ComfyManager:
    def __init__(self, url='http://127.0.0.1:8188', comfy_path='', python_command='python3'):
        self.url = url.rstrip('/')
        self.comfy_path = Path(comfy_path).expanduser() if comfy_path else None
        self.python_command = python_command
        self.process = None

    def is_running(self):
        try:
            r = requests.get(self.url + '/system_stats', timeout=1.5)
            return r.ok
        except Exception:
            return False

    def start(self):
        if self.is_running():
            return True, 'ComfyUI is already running.'
        if not self.comfy_path or not self.comfy_path.exists():
            return False, 'ComfyUI folder is not set or does not exist.'
        main_py = self.comfy_path / 'main.py'
        if not main_py.exists():
            return False, 'Could not find main.py in the selected ComfyUI folder.'
        self.process = subprocess.Popen(
            [self.python_command, str(main_py)],
            cwd=str(self.comfy_path),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        for _ in range(30):
            if self.is_running():
                return True, 'ComfyUI started successfully.'
            time.sleep(1)
        return False, 'ComfyUI was launched, but did not respond on time.'

    def model_dir(self):
        if not self.comfy_path:
            return None
        return self.comfy_path / 'models' / 'checkpoints'

    def list_checkpoints(self):
        d = self.model_dir()
        if not d or not d.exists():
            return []
        exts = {'.safetensors', '.ckpt', '.pt', '.pth'}
        return sorted([p.name for p in d.iterdir() if p.suffix.lower() in exts])
