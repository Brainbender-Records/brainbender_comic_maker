from __future__ import annotations
from pathlib import Path
import json, shutil, uuid, datetime
from .paths import APP_DIR, ensure_dirs

LIB_DIR = APP_DIR / 'library'
CHAR_DIR = LIB_DIR / 'characters'
PRESET_DIR = LIB_DIR / 'presets'
TEMPLATE_DIR = LIB_DIR / 'templates'
PROJECT_DIR = LIB_DIR / 'projects'
REF_DIR = LIB_DIR / 'references'


def now():
    return datetime.datetime.now().isoformat(timespec='seconds')

class JsonListStore:
    def __init__(self, path: Path):
        ensure_dirs(); path.parent.mkdir(parents=True, exist_ok=True); self.path = path
        if not self.path.exists(): self.path.write_text('[]')
    def list(self):
        try: return json.loads(self.path.read_text())
        except Exception: return []
    def save_all(self, items):
        self.path.write_text(json.dumps(items, indent=2))
    def upsert(self, item):
        items = self.list(); item = dict(item)
        if not item.get('id'): item['id'] = str(uuid.uuid4())
        item['updated_at'] = now(); item.setdefault('created_at', item['updated_at'])
        for i, existing in enumerate(items):
            if existing.get('id') == item['id']:
                items[i] = item; self.save_all(items); return item
        items.append(item); self.save_all(items); return item
    def delete(self, item_id):
        self.save_all([x for x in self.list() if x.get('id') != item_id])

class CharacterStore(JsonListStore):
    def __init__(self): super().__init__(CHAR_DIR / 'characters.json')
    def add_reference(self, character_id: str, image_path: str):
        items = self.list(); REF_DIR.mkdir(parents=True, exist_ok=True)
        src = Path(image_path)
        dest = REF_DIR / f"{character_id}_{uuid.uuid4().hex[:8]}{src.suffix.lower()}"
        shutil.copy2(src, dest)
        for item in items:
            if item.get('id') == character_id:
                refs = item.setdefault('reference_images', [])
                refs.append(str(dest)); item['updated_at'] = now(); self.save_all(items); return str(dest)
        raise ValueError('Character not found')

class PresetStore(JsonListStore):
    def __init__(self): super().__init__(PRESET_DIR / 'presets.json')

class TemplateStore(JsonListStore):
    def __init__(self):
        super().__init__(TEMPLATE_DIR / 'templates.json')
        if not self.list(): self.save_all(DEFAULT_TEMPLATES)

class ProjectStore(JsonListStore):
    def __init__(self): super().__init__(PROJECT_DIR / 'projects.json')

    def normalize_project(self, project):
        project = dict(project)
        project.setdefault('chapters', [])
        for ci, chapter in enumerate(project['chapters'], start=1):
            chapter.setdefault('id', str(uuid.uuid4()))
            chapter.setdefault('title', f'Chapter {ci}')
            chapter.setdefault('summary', '')
            chapter.setdefault('pages', [])
            for pi, page in enumerate(chapter['pages'], start=1):
                page.setdefault('id', str(uuid.uuid4()))
                page.setdefault('title', f'Page {pi}')
                page.setdefault('script', '')
                page.setdefault('notes', '')
                page.setdefault('panels', [])
        return project

    def upsert(self, item):
        return super().upsert(self.normalize_project(item))

    def get(self, project_id):
        return next((self.normalize_project(x) for x in self.list() if x.get('id') == project_id), None)

    def update_project(self, project):
        return self.upsert(self.normalize_project(project))

    def add_chapter(self, project_id, title=None):
        project = self.get(project_id)
        if not project: raise ValueError('Project not found')
        chapter = {'id': str(uuid.uuid4()), 'title': title or f"Chapter {len(project['chapters'])+1}", 'summary': '', 'pages': [], 'created_at': now(), 'updated_at': now()}
        project['chapters'].append(chapter)
        self.update_project(project)
        return chapter

    def add_page(self, project_id, chapter_id, title=None):
        project = self.get(project_id)
        if not project: raise ValueError('Project not found')
        chapter = next((c for c in project['chapters'] if c.get('id') == chapter_id), None)
        if not chapter: raise ValueError('Chapter not found')
        page = {'id': str(uuid.uuid4()), 'title': title or f"Page {len(chapter['pages'])+1}", 'script': '', 'notes': '', 'panels': [], 'created_at': now(), 'updated_at': now()}
        chapter['pages'].append(page)
        self.update_project(project)
        return page

    def add_panel(self, project_id, chapter_id, page_id, panel):
        project = self.get(project_id)
        if not project: raise ValueError('Project not found')
        chapter = next((c for c in project['chapters'] if c.get('id') == chapter_id), None)
        if not chapter: raise ValueError('Chapter not found')
        page = next((p for p in chapter['pages'] if p.get('id') == page_id), None)
        if not page: raise ValueError('Page not found')
        panel = dict(panel)
        panel.setdefault('id', str(uuid.uuid4()))
        panel.setdefault('title', f"Panel {len(page['panels'])+1}")
        panel.setdefault('dialogue', '')
        panel.setdefault('caption', '')
        panel.setdefault('notes', '')
        panel.setdefault('created_at', now())
        panel['updated_at'] = now()
        page['panels'].append(panel)
        page['updated_at'] = now()
        self.update_project(project)
        return panel

    def update_page(self, project_id, chapter_id, page_id, **updates):
        project = self.get(project_id)
        chapter = next((c for c in project['chapters'] if c.get('id') == chapter_id), None)
        page = next((p for p in chapter['pages'] if p.get('id') == page_id), None)
        page.update(updates); page['updated_at'] = now()
        self.update_project(project)
        return page


DEFAULT_TEMPLATES = [
    {'id':'establishing','name':'Wide establishing shot','category':'Panel','template':'Wide establishing shot of {scene}. {character} appears small in the frame. Mood: {mood}. Style: {style}.', 'created_at': now(), 'updated_at': now()},
    {'id':'closeup','name':'Close-up reaction','category':'Panel','template':'Close-up reaction shot of {character}. Expression: {expression}. Background: {scene}. Style: {style}.', 'created_at': now(), 'updated_at': now()},
    {'id':'action','name':'Action panel','category':'Panel','template':'Dynamic action panel: {character} {action} in {scene}. Strong motion lines, dramatic composition. Style: {style}.', 'created_at': now(), 'updated_at': now()},
    {'id':'dialogue','name':'Dialogue panel','category':'Panel','template':'Dialogue panel with {character} in {scene}. Leave clean empty space for speech bubbles. Style: {style}.', 'created_at': now(), 'updated_at': now()},
    {'id':'character_sheet','name':'Character sheet','category':'Character','template':'Full character reference sheet for {character}. Front view, side view, expressions, outfit details, consistent design. Style: {style}.', 'created_at': now(), 'updated_at': now()},
]
