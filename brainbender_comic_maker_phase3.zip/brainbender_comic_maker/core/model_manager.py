from pathlib import Path
import shutil, requests

class ModelManager:
    def __init__(self, checkpoints_dir):
        self.checkpoints_dir = Path(checkpoints_dir).expanduser() if checkpoints_dir else None

    def ready(self):
        return self.checkpoints_dir is not None and self.checkpoints_dir.exists()

    def import_model(self, source_file):
        if not self.ready():
            raise RuntimeError('Checkpoint directory does not exist.')
        src = Path(source_file)
        if src.suffix.lower() not in ['.safetensors', '.ckpt', '.pt', '.pth']:
            raise ValueError('Unsupported model type. Use .safetensors, .ckpt, .pt, or .pth')
        dest = self.checkpoints_dir / src.name
        shutil.copy2(src, dest)
        return dest

    def download_model(self, url, filename=None, progress_callback=None):
        if not self.ready():
            raise RuntimeError('Checkpoint directory does not exist.')
        name = filename or url.split('/')[-1].split('?')[0] or 'model.safetensors'
        dest = self.checkpoints_dir / name
        with requests.get(url, stream=True, timeout=20) as r:
            r.raise_for_status()
            total = int(r.headers.get('content-length', 0))
            done = 0
            with open(dest, 'wb') as f:
                for chunk in r.iter_content(chunk_size=1024*1024):
                    if chunk:
                        f.write(chunk)
                        done += len(chunk)
                        if progress_callback and total:
                            progress_callback(int(done * 100 / total))
        return dest
