import sys
from PySide6.QtWidgets import QApplication
from .ui.main_window import MainWindow
from .core.paths import ensure_dirs

def main():
    ensure_dirs()
    app = QApplication(sys.argv)
    app.setApplicationName('Brainbender Comic Maker')
    w = MainWindow()
    w.resize(1180, 760)
    w.show()
    sys.exit(app.exec())
