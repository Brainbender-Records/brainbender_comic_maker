from PySide6.QtCore import QObject, Signal, Slot

class GenerateWorker(QObject):
    finished = Signal(str, dict)
    error = Signal(str)
    status = Signal(str)

    def __init__(self, client, mode, args, metadata, history):
        super().__init__()
        self.client = client
        self.mode = mode
        self.args = args
        self.metadata = metadata
        self.history = history

    @Slot()
    def run(self):
        try:
            self.status.emit('Sending workflow to ComfyUI...')
            if self.mode == 'txt2img':
                img, seed = self.client.txt2img(**self.args)
            else:
                img, seed = self.client.img2img(**self.args)
            meta = dict(self.metadata)
            meta['seed'] = seed
            saved = self.history.add(img, meta)
            self.finished.emit(saved['image'], saved)
        except Exception as e:
            self.error.emit(str(e))
