from pathlib import Path
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QTextEdit,
    QPushButton, QFileDialog, QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox,
    QListWidget, QListWidgetItem, QMessageBox, QTabWidget, QGroupBox, QCheckBox,
    QFormLayout, QInputDialog
)
from PySide6.QtCore import Qt, QThread
from PySide6.QtGui import QPixmap

from ..core.paths import load_settings, save_settings, OUTPUT_DIR
from ..core.comfy_manager import ComfyManager
from ..core.comfy_client import ComfyClient
from ..core.model_manager import ModelManager
from ..core.history import HistoryStore
from ..core.library import CharacterStore, PresetStore, TemplateStore, ProjectStore
from .worker import GenerateWorker

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Brainbender Comic Maker - ComfyUI Comic Frontend')
        self.settings = load_settings()
        self.ref_image = ''
        self.history = HistoryStore()
        self.characters = CharacterStore()
        self.presets = PresetStore()
        self.templates = TemplateStore()
        self.projects = ProjectStore()
        self.current_character = None
        self.current_preset = None
        self.current_template = None
        self.current_project = None
        self.current_structure_project = None
        self.current_chapter_id = ''
        self.current_page_id = ''
        self.thread = None
        self.worker = None
        self._build_ui()
        self.refresh_models()
        self.refresh_library_controls()
        self.refresh_history()
        self.check_comfy_startup()

    def _build_ui(self):
        tabs = QTabWidget()
        tabs.addTab(self._generation_tab(), 'Generate')
        tabs.addTab(self._characters_tab(), 'Characters')
        tabs.addTab(self._templates_tab(), 'Prompt Templates')
        tabs.addTab(self._presets_tab(), 'Style / LoRA Presets')
        tabs.addTab(self._projects_tab(), 'Projects')
        tabs.addTab(self._comic_structure_tab(), 'Book / Pages')
        tabs.addTab(self._settings_tab(), 'Settings / Models')
        tabs.addTab(self._history_tab(), 'History')
        self.setCentralWidget(tabs)
        self.statusBar().showMessage('Ready')

    def _generation_tab(self):
        root = QWidget(); layout = QHBoxLayout(root)
        left = QVBoxLayout(); right = QVBoxLayout()
        layout.addLayout(left, 2); layout.addLayout(right, 1)

        comic_box = QGroupBox('Comic Panel Context')
        cg = QGridLayout(comic_box)
        self.character_select = QComboBox(); self.character_select.addItem('Manual / none', ''); self.character_select.currentIndexChanged.connect(self.apply_selected_character)
        self.character = QLineEdit(); self.character.setPlaceholderText('Example: Detective Jonah, black suit, tired eyes')
        self.scene = QLineEdit(); self.scene.setPlaceholderText('Example: rainy alley outside a neon diner')
        self.panel_type = QComboBox(); self.panel_type.addItems(['Establishing shot','Close-up reaction','Action panel','Dialogue panel','Splash panel','Object insert'])
        self.style = QLineEdit(); self.style.setPlaceholderText('Example: graphic novel, clean ink lines, cinematic lighting')
        cg.addWidget(QLabel('Saved Character'),0,0); cg.addWidget(self.character_select,0,1)
        cg.addWidget(QLabel('Character'),1,0); cg.addWidget(self.character,1,1)
        cg.addWidget(QLabel('Scene'),2,0); cg.addWidget(self.scene,2,1)
        cg.addWidget(QLabel('Panel Type'),3,0); cg.addWidget(self.panel_type,3,1)
        self.template_select = QComboBox(); self.template_select.addItem('No template', '')
        self.template_select.currentIndexChanged.connect(self.apply_selected_template)
        cg.addWidget(QLabel('Template'),4,0); cg.addWidget(self.template_select,4,1)
        self.preset_select = QComboBox(); self.preset_select.addItem('No preset', '')
        self.preset_select.currentIndexChanged.connect(self.apply_selected_preset)
        cg.addWidget(QLabel('Style Preset'),5,0); cg.addWidget(self.preset_select,5,1)
        cg.addWidget(QLabel('Style'),6,0); cg.addWidget(self.style,6,1)
        left.addWidget(comic_box)

        self.prompt = QTextEdit(); self.prompt.setPlaceholderText('Describe the comic panel you want...')
        self.negative = QTextEdit(); self.negative.setPlaceholderText('Negative prompt: blurry, bad hands, text artifacts, watermark...')
        self.negative.setMaximumHeight(80)
        left.addWidget(QLabel('Prompt'))
        left.addWidget(self.prompt)
        left.addWidget(QLabel('Negative Prompt'))
        left.addWidget(self.negative)

        opts = QGridLayout()
        self.mode_img2img = QCheckBox('Use reference image / img2img')
        self.ref_label = QLabel('No reference image selected')
        choose_ref = QPushButton('Choose Reference Image')
        choose_ref.clicked.connect(self.choose_reference)
        self.width = QSpinBox(); self.width.setRange(256, 2048); self.width.setSingleStep(64); self.width.setValue(768)
        self.height = QSpinBox(); self.height.setRange(256, 2048); self.height.setSingleStep(64); self.height.setValue(768)
        self.steps = QSpinBox(); self.steps.setRange(1, 150); self.steps.setValue(25)
        self.cfg = QDoubleSpinBox(); self.cfg.setRange(1, 30); self.cfg.setValue(7.0); self.cfg.setSingleStep(.5)
        self.denoise = QDoubleSpinBox(); self.denoise.setRange(0.05, 1.0); self.denoise.setValue(.55); self.denoise.setSingleStep(.05)
        self.seed = QLineEdit(); self.seed.setPlaceholderText('blank = random')
        self.checkpoint = QComboBox()
        opts.addWidget(self.mode_img2img,0,0,1,2); opts.addWidget(choose_ref,1,0); opts.addWidget(self.ref_label,1,1)
        opts.addWidget(QLabel('Checkpoint'),2,0); opts.addWidget(self.checkpoint,2,1)
        opts.addWidget(QLabel('Width'),3,0); opts.addWidget(self.width,3,1)
        opts.addWidget(QLabel('Height'),4,0); opts.addWidget(self.height,4,1)
        opts.addWidget(QLabel('Steps'),5,0); opts.addWidget(self.steps,5,1)
        opts.addWidget(QLabel('CFG'),6,0); opts.addWidget(self.cfg,6,1)
        opts.addWidget(QLabel('Img2Img Strength'),7,0); opts.addWidget(self.denoise,7,1)
        opts.addWidget(QLabel('Seed'),8,0); opts.addWidget(self.seed,8,1)
        left.addLayout(opts)

        self.generate_btn = QPushButton('Generate Comic Panel')
        self.generate_btn.clicked.connect(self.generate)
        left.addWidget(self.generate_btn)

        self.preview = QLabel('Generated image preview')
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setMinimumSize(420, 420)
        self.preview.setStyleSheet('border: 1px solid #777; background: #202020; color: #ddd;')
        right.addWidget(self.preview)
        self.last_meta = QLabel('No generation yet')
        self.last_meta.setWordWrap(True)
        right.addWidget(self.last_meta)
        return root

    def _settings_tab(self):
        root = QWidget(); layout = QVBoxLayout(root)
        self.comfy_url = QLineEdit(self.settings.get('comfy_url','http://127.0.0.1:8188'))
        self.comfy_path = QLineEdit(self.settings.get('comfy_path',''))
        self.python_cmd = QLineEdit(self.settings.get('python_command','python3'))
        browse = QPushButton('Choose ComfyUI Folder')
        browse.clicked.connect(self.choose_comfy_folder)
        save = QPushButton('Save Settings')
        save.clicked.connect(self.save_settings_clicked)
        start = QPushButton('Start / Check ComfyUI')
        start.clicked.connect(self.start_comfy_clicked)
        import_model = QPushButton('Import Local Model File')
        import_model.clicked.connect(self.import_model_clicked)
        refresh = QPushButton('Refresh Models')
        refresh.clicked.connect(self.refresh_models)
        layout.addWidget(QLabel('ComfyUI URL')); layout.addWidget(self.comfy_url)
        layout.addWidget(QLabel('ComfyUI Folder')); layout.addWidget(self.comfy_path); layout.addWidget(browse)
        layout.addWidget(QLabel('Python Command')); layout.addWidget(self.python_cmd)
        layout.addWidget(save); layout.addWidget(start); layout.addWidget(import_model); layout.addWidget(refresh)
        self.models_label = QLabel('Models:')
        layout.addWidget(self.models_label)
        layout.addStretch(1)
        return root

    def _history_tab(self):
        root = QWidget(); layout = QHBoxLayout(root)
        self.history_list = QListWidget(); self.history_list.currentItemChanged.connect(self.show_history_item)
        self.history_preview = QLabel('Select a history item')
        self.history_preview.setAlignment(Qt.AlignCenter); self.history_preview.setMinimumSize(500,500)
        self.history_preview.setStyleSheet('border: 1px solid #777;')
        layout.addWidget(self.history_list,1); layout.addWidget(self.history_preview,2)
        return root


    def _characters_tab(self):
        root = QWidget(); layout = QHBoxLayout(root)
        left = QVBoxLayout(); right = QVBoxLayout(); layout.addLayout(left,1); layout.addLayout(right,2)
        self.character_list = QListWidget(); self.character_list.currentItemChanged.connect(self.load_character_item)
        left.addWidget(QLabel('Saved Characters')); left.addWidget(self.character_list)
        new_btn = QPushButton('New Character'); new_btn.clicked.connect(self.new_character)
        del_btn = QPushButton('Delete Character'); del_btn.clicked.connect(self.delete_character)
        ref_btn = QPushButton('Add Reference Image'); ref_btn.clicked.connect(self.add_character_reference)
        left.addWidget(new_btn); left.addWidget(ref_btn); left.addWidget(del_btn)
        form = QFormLayout()
        self.char_name = QLineEdit(); self.char_role = QLineEdit(); self.char_appearance = QTextEdit(); self.char_appearance.setMaximumHeight(90)
        self.char_outfit = QTextEdit(); self.char_outfit.setMaximumHeight(70)
        self.char_personality = QTextEdit(); self.char_personality.setMaximumHeight(70)
        self.char_prompt = QTextEdit(); self.char_prompt.setMaximumHeight(90)
        self.char_refs = QListWidget()
        form.addRow('Name', self.char_name); form.addRow('Role', self.char_role)
        form.addRow('Appearance', self.char_appearance); form.addRow('Outfit / costume', self.char_outfit)
        form.addRow('Personality / acting notes', self.char_personality); form.addRow('Prompt phrase', self.char_prompt)
        save_btn = QPushButton('Save Character'); save_btn.clicked.connect(self.save_character)
        right.addLayout(form); right.addWidget(QLabel('Reference Images')); right.addWidget(self.char_refs); right.addWidget(save_btn)
        self.refresh_characters()
        return root

    def _templates_tab(self):
        root = QWidget(); layout = QHBoxLayout(root)
        left = QVBoxLayout(); right = QVBoxLayout(); layout.addLayout(left,1); layout.addLayout(right,2)
        self.template_list = QListWidget(); self.template_list.currentItemChanged.connect(self.load_template_item)
        left.addWidget(QLabel('Prompt Templates')); left.addWidget(self.template_list)
        add = QPushButton('New Template'); add.clicked.connect(self.new_template)
        delete = QPushButton('Delete Template'); delete.clicked.connect(self.delete_template)
        left.addWidget(add); left.addWidget(delete)
        form = QFormLayout()
        self.tpl_name = QLineEdit(); self.tpl_category = QLineEdit(); self.tpl_text = QTextEdit()
        self.tpl_text.setPlaceholderText('Use placeholders like {character}, {scene}, {style}, {mood}, {action}, {expression}')
        form.addRow('Name', self.tpl_name); form.addRow('Category', self.tpl_category); form.addRow('Template', self.tpl_text)
        save = QPushButton('Save Template'); save.clicked.connect(self.save_template)
        use = QPushButton('Send Template to Prompt Box'); use.clicked.connect(self.use_template_now)
        right.addLayout(form); right.addWidget(save); right.addWidget(use)
        self.refresh_templates(); return root

    def _presets_tab(self):
        root = QWidget(); layout = QHBoxLayout(root)
        left = QVBoxLayout(); right = QVBoxLayout(); layout.addLayout(left,1); layout.addLayout(right,2)
        self.preset_list = QListWidget(); self.preset_list.currentItemChanged.connect(self.load_preset_item)
        left.addWidget(QLabel('Style / LoRA Presets')); left.addWidget(self.preset_list)
        add = QPushButton('New Preset'); add.clicked.connect(self.new_preset)
        delete = QPushButton('Delete Preset'); delete.clicked.connect(self.delete_preset)
        left.addWidget(add); left.addWidget(delete)
        form = QFormLayout()
        self.preset_name = QLineEdit(); self.preset_style = QTextEdit(); self.preset_style.setMaximumHeight(100)
        self.preset_negative = QTextEdit(); self.preset_negative.setMaximumHeight(90)
        self.preset_loras = QTextEdit(); self.preset_loras.setPlaceholderText('Optional notes: LoRA names, weights, model recommendations')
        form.addRow('Name', self.preset_name); form.addRow('Style prompt add-on', self.preset_style)
        form.addRow('Negative prompt add-on', self.preset_negative); form.addRow('LoRA / model notes', self.preset_loras)
        save = QPushButton('Save Preset'); save.clicked.connect(self.save_preset)
        right.addLayout(form); right.addWidget(save)
        self.refresh_presets(); return root

    def _projects_tab(self):
        root = QWidget(); layout = QHBoxLayout(root)
        left = QVBoxLayout(); right = QVBoxLayout(); layout.addLayout(left,1); layout.addLayout(right,2)
        self.project_list = QListWidget(); self.project_list.currentItemChanged.connect(self.load_project_item)
        left.addWidget(QLabel('Comic Projects')); left.addWidget(self.project_list)
        add = QPushButton('New Project'); add.clicked.connect(self.new_project)
        delete = QPushButton('Delete Project'); delete.clicked.connect(self.delete_project)
        left.addWidget(add); left.addWidget(delete)
        form = QFormLayout()
        self.project_title = QLineEdit(); self.project_genre = QLineEdit(); self.project_style = QTextEdit(); self.project_style.setMaximumHeight(80)
        self.project_synopsis = QTextEdit(); self.project_synopsis.setMaximumHeight(120)
        self.project_notes = QTextEdit()
        form.addRow('Title', self.project_title); form.addRow('Genre', self.project_genre)
        form.addRow('Visual style bible', self.project_style); form.addRow('Synopsis', self.project_synopsis); form.addRow('Notes', self.project_notes)
        save = QPushButton('Save Project'); save.clicked.connect(self.save_project)
        right.addLayout(form); right.addWidget(save)
        self.refresh_projects(); return root

    def refresh_library_controls(self):
        if hasattr(self, 'character_select'):
            self.character_select.blockSignals(True); self.character_select.clear(); self.character_select.addItem('Manual / none','')
            for c in self.characters.list(): self.character_select.addItem(c.get('name','Unnamed'), c.get('id',''))
            self.character_select.blockSignals(False)
        if hasattr(self, 'template_select'):
            self.template_select.blockSignals(True); self.template_select.clear(); self.template_select.addItem('No template','')
            for t in self.templates.list(): self.template_select.addItem(t.get('name','Unnamed'), t.get('id',''))
            self.template_select.blockSignals(False)
        if hasattr(self, 'preset_select'):
            self.preset_select.blockSignals(True); self.preset_select.clear(); self.preset_select.addItem('No preset','')
            for pr in self.presets.list(): self.preset_select.addItem(pr.get('name','Unnamed'), pr.get('id',''))
            self.preset_select.blockSignals(False)

    def refresh_characters(self):
        if not hasattr(self,'character_list'): return
        self.character_list.clear()
        for c in self.characters.list():
            it=QListWidgetItem(c.get('name','Unnamed')); it.setData(Qt.UserRole,c); self.character_list.addItem(it)
        self.refresh_library_controls()
    def new_character(self):
        self.current_character=None; self.char_name.clear(); self.char_role.clear(); self.char_appearance.clear(); self.char_outfit.clear(); self.char_personality.clear(); self.char_prompt.clear(); self.char_refs.clear()
    def load_character_item(self,current,previous):
        if not current: return
        c=current.data(Qt.UserRole); self.current_character=c
        self.char_name.setText(c.get('name','')); self.char_role.setText(c.get('role','')); self.char_appearance.setPlainText(c.get('appearance',''))
        self.char_outfit.setPlainText(c.get('outfit','')); self.char_personality.setPlainText(c.get('personality','')); self.char_prompt.setPlainText(c.get('prompt_phrase',''))
        self.char_refs.clear(); [self.char_refs.addItem(x) for x in c.get('reference_images',[])]
    def save_character(self):
        item=dict(self.current_character or {})
        item.update(name=self.char_name.text().strip() or 'Unnamed Character', role=self.char_role.text().strip(), appearance=self.char_appearance.toPlainText().strip(), outfit=self.char_outfit.toPlainText().strip(), personality=self.char_personality.toPlainText().strip(), prompt_phrase=self.char_prompt.toPlainText().strip(), reference_images=[self.char_refs.item(i).text() for i in range(self.char_refs.count())])
        self.current_character=self.characters.upsert(item); self.refresh_characters(); QMessageBox.information(self,'Saved','Character saved.')
    def delete_character(self):
        if self.current_character: self.characters.delete(self.current_character.get('id')); self.new_character(); self.refresh_characters()
    def add_character_reference(self):
        if not self.current_character: self.save_character()
        fp,_=QFileDialog.getOpenFileName(self,'Choose reference image',str(Path.home()),'Images (*.png *.jpg *.jpeg *.webp)')
        if fp:
            dest=self.characters.add_reference(self.current_character['id'], fp); self.char_refs.addItem(dest); self.refresh_characters()
    def apply_selected_character(self):
        cid=self.character_select.currentData()
        c=next((x for x in self.characters.list() if x.get('id')==cid), None)
        if not c: return
        phrase=c.get('prompt_phrase') or ', '.join([c.get('name',''), c.get('appearance',''), c.get('outfit','')])
        self.character.setText(phrase)
        refs=c.get('reference_images',[])
        if refs and not self.ref_image:
            self.ref_image=refs[0]; self.ref_label.setText(Path(refs[0]).name)

    def refresh_templates(self):
        if not hasattr(self,'template_list'): return
        self.template_list.clear()
        for t in self.templates.list():
            it=QListWidgetItem(f"{t.get('name','Unnamed')} [{t.get('category','')}]"); it.setData(Qt.UserRole,t); self.template_list.addItem(it)
        self.refresh_library_controls()
    def new_template(self): self.current_template=None; self.tpl_name.clear(); self.tpl_category.clear(); self.tpl_text.clear()
    def load_template_item(self,current,previous):
        if not current: return
        t=current.data(Qt.UserRole); self.current_template=t; self.tpl_name.setText(t.get('name','')); self.tpl_category.setText(t.get('category','')); self.tpl_text.setPlainText(t.get('template',''))
    def save_template(self):
        item=dict(self.current_template or {}); item.update(name=self.tpl_name.text().strip() or 'Unnamed Template', category=self.tpl_category.text().strip(), template=self.tpl_text.toPlainText().strip())
        self.current_template=self.templates.upsert(item); self.refresh_templates(); QMessageBox.information(self,'Saved','Template saved.')
    def delete_template(self):
        if self.current_template: self.templates.delete(self.current_template.get('id')); self.new_template(); self.refresh_templates()
    def _filled_template(self, template):
        return template.format(character=self.character.text().strip(), scene=self.scene.text().strip(), style=self.style.text().strip(), mood='dramatic', action='acts', expression='focused')
    def use_template_now(self):
        if self.current_template: self.prompt.setPlainText(self._filled_template(self.current_template.get('template','')))
    def apply_selected_template(self):
        tid=self.template_select.currentData(); t=next((x for x in self.templates.list() if x.get('id')==tid), None)
        if t and not self.prompt.toPlainText().strip(): self.prompt.setPlainText(self._filled_template(t.get('template','')))

    def refresh_presets(self):
        if not hasattr(self,'preset_list'): return
        self.preset_list.clear()
        for pr in self.presets.list():
            it=QListWidgetItem(pr.get('name','Unnamed')); it.setData(Qt.UserRole,pr); self.preset_list.addItem(it)
        self.refresh_library_controls()
    def new_preset(self): self.current_preset=None; self.preset_name.clear(); self.preset_style.clear(); self.preset_negative.clear(); self.preset_loras.clear()
    def load_preset_item(self,current,previous):
        if not current: return
        pr=current.data(Qt.UserRole); self.current_preset=pr; self.preset_name.setText(pr.get('name','')); self.preset_style.setPlainText(pr.get('style_addon','')); self.preset_negative.setPlainText(pr.get('negative_addon','')); self.preset_loras.setPlainText(pr.get('lora_notes',''))
    def save_preset(self):
        item=dict(self.current_preset or {}); item.update(name=self.preset_name.text().strip() or 'Unnamed Preset', style_addon=self.preset_style.toPlainText().strip(), negative_addon=self.preset_negative.toPlainText().strip(), lora_notes=self.preset_loras.toPlainText().strip())
        self.current_preset=self.presets.upsert(item); self.refresh_presets(); QMessageBox.information(self,'Saved','Preset saved.')
    def delete_preset(self):
        if self.current_preset: self.presets.delete(self.current_preset.get('id')); self.new_preset(); self.refresh_presets()
    def apply_selected_preset(self):
        pid=self.preset_select.currentData(); pr=next((x for x in self.presets.list() if x.get('id')==pid), None)
        if not pr: return
        if pr.get('style_addon'): self.style.setText(pr.get('style_addon'))
        if pr.get('negative_addon') and not self.negative.toPlainText().strip(): self.negative.setPlainText(pr.get('negative_addon'))

    def refresh_projects(self):
        if not hasattr(self,'project_list'): return
        self.project_list.clear()
        for prj in self.projects.list():
            it=QListWidgetItem(prj.get('title','Untitled Project')); it.setData(Qt.UserRole,prj); self.project_list.addItem(it)
    def new_project(self): self.current_project=None; self.project_title.clear(); self.project_genre.clear(); self.project_style.clear(); self.project_synopsis.clear(); self.project_notes.clear()
    def load_project_item(self,current,previous):
        if not current: return
        prj=current.data(Qt.UserRole); self.current_project=prj; self.project_title.setText(prj.get('title','')); self.project_genre.setText(prj.get('genre','')); self.project_style.setPlainText(prj.get('style_bible','')); self.project_synopsis.setPlainText(prj.get('synopsis','')); self.project_notes.setPlainText(prj.get('notes',''))
    def save_project(self):
        item=dict(getattr(self,'current_project',{}) or {}); item.update(title=self.project_title.text().strip() or 'Untitled Project', genre=self.project_genre.text().strip(), style_bible=self.project_style.toPlainText().strip(), synopsis=self.project_synopsis.toPlainText().strip(), notes=self.project_notes.toPlainText().strip())
        self.current_project=self.projects.upsert(item); self.refresh_projects(); self.refresh_structure_projects(); QMessageBox.information(self,'Saved','Project saved.')
    def delete_project(self):
        if getattr(self,'current_project',None): self.projects.delete(self.current_project.get('id')); self.new_project(); self.refresh_projects(); self.refresh_structure_projects()


    def _comic_structure_tab(self):
        root = QWidget(); layout = QHBoxLayout(root)
        left = QVBoxLayout(); mid = QVBoxLayout(); right = QVBoxLayout()
        layout.addLayout(left,1); layout.addLayout(mid,1); layout.addLayout(right,2)

        self.structure_project_combo = QComboBox()
        self.structure_project_combo.currentIndexChanged.connect(self.structure_project_changed)
        left.addWidget(QLabel('Comic Book Project'))
        left.addWidget(self.structure_project_combo)
        refresh = QPushButton('Refresh Projects')
        refresh.clicked.connect(self.refresh_structure_projects)
        left.addWidget(refresh)

        self.chapter_list = QListWidget()
        self.chapter_list.currentItemChanged.connect(self.structure_chapter_changed)
        left.addWidget(QLabel('Chapters'))
        left.addWidget(self.chapter_list)
        add_chapter = QPushButton('Add Chapter')
        add_chapter.clicked.connect(self.add_structure_chapter)
        left.addWidget(add_chapter)

        self.page_list = QListWidget()
        self.page_list.currentItemChanged.connect(self.structure_page_changed)
        mid.addWidget(QLabel('Pages in selected chapter'))
        mid.addWidget(self.page_list)
        add_page = QPushButton('Add Page')
        add_page.clicked.connect(self.add_structure_page)
        mid.addWidget(add_page)

        self.page_title = QLineEdit()
        self.page_script = QTextEdit(); self.page_script.setPlaceholderText('Page script, beats, or panel-by-panel notes...')
        self.page_notes = QTextEdit(); self.page_notes.setMaximumHeight(90)
        right.addWidget(QLabel('Page Title')); right.addWidget(self.page_title)
        right.addWidget(QLabel('Page Script')); right.addWidget(self.page_script)
        right.addWidget(QLabel('Page Notes')); right.addWidget(self.page_notes)
        save_page = QPushButton('Save Page Notes')
        save_page.clicked.connect(self.save_structure_page)
        right.addWidget(save_page)

        self.panel_list = QListWidget()
        right.addWidget(QLabel('Panels on this page'))
        right.addWidget(self.panel_list)
        add_last = QPushButton('Add Latest Generated Image as Panel')
        add_last.clicked.connect(self.add_latest_history_as_panel)
        add_file = QPushButton('Add Image File as Panel')
        add_file.clicked.connect(self.add_file_as_panel)
        right.addWidget(add_last); right.addWidget(add_file)
        self.refresh_structure_projects()
        return root

    def refresh_structure_projects(self):
        if not hasattr(self, 'structure_project_combo'): return
        current = self.structure_project_combo.currentData()
        self.structure_project_combo.blockSignals(True)
        self.structure_project_combo.clear()
        for prj in self.projects.list():
            self.structure_project_combo.addItem(prj.get('title','Untitled Project'), prj.get('id',''))
        self.structure_project_combo.blockSignals(False)
        if current:
            idx = self.structure_project_combo.findData(current)
            if idx >= 0: self.structure_project_combo.setCurrentIndex(idx)
        self.structure_project_changed()

    def structure_project_changed(self):
        if not hasattr(self, 'structure_project_combo'): return
        pid = self.structure_project_combo.currentData()
        self.current_structure_project = self.projects.get(pid) if pid else None
        self.current_chapter_id = ''; self.current_page_id = ''
        self.chapter_list.clear(); self.page_list.clear(); self.panel_list.clear()
        if not self.current_structure_project: return
        for chapter in self.current_structure_project.get('chapters', []):
            it = QListWidgetItem(chapter.get('title','Untitled Chapter')); it.setData(Qt.UserRole, chapter.get('id')); self.chapter_list.addItem(it)

    def structure_chapter_changed(self, current, previous):
        self.page_list.clear(); self.panel_list.clear(); self.current_page_id = ''
        if not current or not self.current_structure_project: return
        self.current_chapter_id = current.data(Qt.UserRole)
        chapter = next((c for c in self.current_structure_project.get('chapters',[]) if c.get('id') == self.current_chapter_id), None)
        if not chapter: return
        for page in chapter.get('pages', []):
            it = QListWidgetItem(page.get('title','Untitled Page')); it.setData(Qt.UserRole, page.get('id')); self.page_list.addItem(it)

    def structure_page_changed(self, current, previous):
        self.panel_list.clear()
        if not current or not self.current_structure_project: return
        self.current_page_id = current.data(Qt.UserRole)
        page = self._current_page()
        if not page: return
        self.page_title.setText(page.get('title',''))
        self.page_script.setPlainText(page.get('script',''))
        self.page_notes.setPlainText(page.get('notes',''))
        for panel in page.get('panels', []):
            label = f"{panel.get('title','Panel')} | {Path(panel.get('image','')).name}"
            it = QListWidgetItem(label); it.setData(Qt.UserRole, panel); self.panel_list.addItem(it)

    def _current_page(self):
        if not self.current_structure_project: return None
        chapter = next((c for c in self.current_structure_project.get('chapters',[]) if c.get('id') == self.current_chapter_id), None)
        if not chapter: return None
        return next((p for p in chapter.get('pages',[]) if p.get('id') == self.current_page_id), None)

    def add_structure_chapter(self):
        pid = self.structure_project_combo.currentData()
        if not pid:
            QMessageBox.warning(self, 'Project required', 'Create or select a project first.'); return
        title, ok = QInputDialog.getText(self, 'New Chapter', 'Chapter title:')
        if ok:
            self.projects.add_chapter(pid, title.strip() or None)
            self.refresh_structure_projects()

    def add_structure_page(self):
        pid = self.structure_project_combo.currentData()
        if not pid or not self.current_chapter_id:
            QMessageBox.warning(self, 'Chapter required', 'Select a project and chapter first.'); return
        title, ok = QInputDialog.getText(self, 'New Page', 'Page title:')
        if ok:
            self.projects.add_page(pid, self.current_chapter_id, title.strip() or None)
            self.structure_project_changed()

    def save_structure_page(self):
        pid = self.structure_project_combo.currentData()
        if not pid or not self.current_chapter_id or not self.current_page_id:
            QMessageBox.warning(self, 'Page required', 'Select a page first.'); return
        self.projects.update_page(pid, self.current_chapter_id, self.current_page_id, title=self.page_title.text().strip() or 'Untitled Page', script=self.page_script.toPlainText().strip(), notes=self.page_notes.toPlainText().strip())
        self.current_structure_project = self.projects.get(pid)
        QMessageBox.information(self, 'Saved', 'Page notes saved.')
        self.structure_project_changed()

    def add_latest_history_as_panel(self):
        items = self.history.list_items()
        if not items:
            QMessageBox.warning(self, 'No history', 'Generate an image first or add an image file.'); return
        self._add_panel_to_current_page(items[0].get('image',''), items[0])

    def add_file_as_panel(self):
        fp, _ = QFileDialog.getOpenFileName(self, 'Choose panel image', str(Path.home()), 'Images (*.png *.jpg *.jpeg *.webp)')
        if fp: self._add_panel_to_current_page(fp, {})

    def _add_panel_to_current_page(self, image_path, metadata):
        pid = self.structure_project_combo.currentData()
        if not pid or not self.current_chapter_id or not self.current_page_id:
            QMessageBox.warning(self, 'Page required', 'Select a page first.'); return
        panel = {'image': image_path, 'prompt': metadata.get('prompt',''), 'seed': metadata.get('seed',''), 'mode': metadata.get('mode','')}
        self.projects.add_panel(pid, self.current_chapter_id, self.current_page_id, panel)
        self.current_structure_project = self.projects.get(pid)
        fake = QListWidgetItem(); fake.setData(Qt.UserRole, self.current_page_id)
        self.structure_page_changed(fake, None)
        QMessageBox.information(self, 'Panel Added', 'Panel added to the selected page.')

    def manager(self):
        self.settings = load_settings()
        return ComfyManager(self.settings['comfy_url'], self.settings['comfy_path'], self.settings['python_command'])

    def check_comfy_startup(self):
        m = self.manager()
        if not m.is_running() and self.settings.get('comfy_path'):
            ok, msg = m.start()
            self.statusBar().showMessage(msg)
        elif m.is_running():
            self.statusBar().showMessage('ComfyUI connected.')
        else:
            self.statusBar().showMessage('Set your ComfyUI folder in Settings to enable auto-start.')

    def choose_reference(self):
        fp, _ = QFileDialog.getOpenFileName(self, 'Choose reference image', str(Path.home()), 'Images (*.png *.jpg *.jpeg *.webp)')
        if fp:
            self.ref_image = fp; self.ref_label.setText(Path(fp).name); self.mode_img2img.setChecked(True)

    def choose_comfy_folder(self):
        d = QFileDialog.getExistingDirectory(self, 'Choose ComfyUI folder', str(Path.home()))
        if d: self.comfy_path.setText(d)

    def save_settings_clicked(self):
        self.settings['comfy_url'] = self.comfy_url.text().strip()
        self.settings['comfy_path'] = self.comfy_path.text().strip()
        self.settings['python_command'] = self.python_cmd.text().strip() or 'python3'
        save_settings(self.settings); self.refresh_models(); QMessageBox.information(self, 'Saved', 'Settings saved.')

    def start_comfy_clicked(self):
        self.save_settings_clicked()
        ok, msg = self.manager().start()
        QMessageBox.information(self, 'ComfyUI', msg) if ok else QMessageBox.warning(self, 'ComfyUI', msg)

    def refresh_models(self):
        m = self.manager()
        models = m.list_checkpoints()
        self.checkpoint.clear(); self.checkpoint.addItems(models)
        self.models_label.setText('Models detected:\n' + ('\n'.join(models) if models else 'No checkpoints found. Put models in ComfyUI/models/checkpoints/'))

    def import_model_clicked(self):
        fp, _ = QFileDialog.getOpenFileName(self, 'Choose model file', str(Path.home()), 'Models (*.safetensors *.ckpt *.pt *.pth)')
        if not fp: return
        try:
            mm = ModelManager(self.manager().model_dir())
            dest = mm.import_model(fp)
            self.refresh_models()
            QMessageBox.information(self, 'Model Imported', f'Imported to {dest}')
        except Exception as e:
            QMessageBox.warning(self, 'Import failed', str(e))

    def build_prompt(self):
        parts = [self.prompt.toPlainText().strip()]
        if self.character.text().strip(): parts.append('Character: ' + self.character.text().strip())
        if self.scene.text().strip(): parts.append('Scene: ' + self.scene.text().strip())
        parts.append('Panel type: ' + self.panel_type.currentText())
        if self.style.text().strip(): parts.append('Style: ' + self.style.text().strip())
        parts.append('comic panel, professional sequential art, clear composition')
        return ', '.join([p for p in parts if p])

    def generate(self):
        if not self.manager().is_running():
            ok, msg = self.manager().start()
            if not ok:
                QMessageBox.warning(self, 'ComfyUI not running', msg); return
        prompt = self.build_prompt()
        if not prompt.strip():
            QMessageBox.warning(self, 'Prompt required', 'Enter a prompt first.'); return
        mode = 'img2img' if self.mode_img2img.isChecked() else 'txt2img'
        if mode == 'img2img' and not self.ref_image:
            QMessageBox.warning(self, 'Reference required', 'Choose a reference image or uncheck img2img.'); return
        common = dict(prompt=prompt, negative=self.negative.toPlainText().strip(), checkpoint=self.checkpoint.currentText(), width=self.width.value(), height=self.height.value(), steps=self.steps.value(), cfg=self.cfg.value(), seed=self.seed.text().strip(), dest_dir=str(OUTPUT_DIR))
        args = dict(common)
        if mode == 'img2img':
            args['image_path'] = self.ref_image; args['denoise'] = self.denoise.value()
        metadata = {k: v for k, v in common.items() if k != 'dest_dir'}
        metadata.update({'mode': mode, 'character': self.character.text(), 'scene': self.scene.text(), 'panel_type': self.panel_type.currentText(), 'style': self.style.text(), 'reference_image': self.ref_image})
        self.generate_btn.setEnabled(False); self.statusBar().showMessage('Generating...')
        self.thread = QThread(); self.worker = GenerateWorker(ComfyClient(self.settings['comfy_url']), mode, args, metadata, self.history)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.generation_done)
        self.worker.error.connect(self.generation_error)
        self.worker.status.connect(self.statusBar().showMessage)
        self.worker.finished.connect(self.thread.quit); self.worker.error.connect(self.thread.quit)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()

    def generation_done(self, image, meta):
        self.generate_btn.setEnabled(True); self.statusBar().showMessage('Generation complete.')
        self.set_preview(self.preview, image)
        self.last_meta.setText(f"Saved: {image}\nSeed: {meta.get('seed')}\nMode: {meta.get('mode')}")
        self.refresh_history()

    def generation_error(self, message):
        self.generate_btn.setEnabled(True); self.statusBar().showMessage('Generation failed.')
        QMessageBox.warning(self, 'Generation failed', message)

    def refresh_history(self):
        if not hasattr(self, 'history_list'): return
        self.history_list.clear()
        for item in self.history.list_items():
            li = QListWidgetItem(f"{item.get('created_at','')} | {item.get('mode','')} | seed {item.get('seed','')}")
            li.setData(Qt.UserRole, item)
            self.history_list.addItem(li)

    def show_history_item(self, current, previous):
        if not current: return
        item = current.data(Qt.UserRole)
        self.set_preview(self.history_preview, item.get('image',''))

    def set_preview(self, label, image_path):
        pix = QPixmap(image_path)
        if pix.isNull():
            label.setText('Could not load image'); return
        label.setPixmap(pix.scaled(label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
