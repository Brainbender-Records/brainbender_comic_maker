#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "Installing Brainbender Comic Maker dependencies..."
sudo apt update
sudo apt install -y python3 python3-venv python3-pip git
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
echo
echo "Done. Start Brainbender Comic Maker with:"
echo "source .venv/bin/activate && python run.py"
