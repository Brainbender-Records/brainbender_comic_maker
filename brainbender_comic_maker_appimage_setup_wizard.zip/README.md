# Brainbender Comic Maker

Open and free AI comic-making frontend for Ubuntu, designed to work with ComfyUI.

This AppImage-ready version now includes real ComfyUI API wiring for:

- Text-to-image panel generation
- Image + text reference generation through img2img
- ComfyUI auto-start/check button
- Checkpoint model detection and import
- Prompt, negative prompt, steps, CFG, seed, size, and denoise controls
- Placeholder panel creation for testing without a model
- Character/location continuity notes
- PDF contact sheet and CBZ export starter tools

## Development run on Ubuntu

```bash
unzip brainbender_comic_maker_appimage_next.zip -d brainbender_comic_maker
cd brainbender_comic_maker
./install_ubuntu_dev.sh
./start.sh
```

## ComfyUI setup

Brainbender Comic Maker is the frontend. ComfyUI is the image-generation backend.

1. Install ComfyUI separately.
2. Add at least one checkpoint model to:

```text
ComfyUI/models/checkpoints/
```

3. In Brainbender Comic Maker, open **Settings**.
4. Choose your ComfyUI folder.
5. Click **Start / Check ComfyUI**.
6. Return to **Studio**, refresh models, and generate.

## Build AppImage/AppDir

```bash
./packaging/appimage/build_appimage.sh
```

The script creates an AppDir and will create an AppImage if `appimagetool` is available.

## Notes

ComfyUI workflows are generated in Python in:

```text
src/brainbender/comfy/workflows.py
```

This keeps the app simpler than shipping separate JSON workflows for the first version.
