from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWizard,
    QWizardPage,
)

from ..comfy.launcher import ComfyLauncher
from ..core.settings import Settings


class WelcomePage(QWizardPage):
    def __init__(self):
        super().__init__()
        self.setTitle('Welcome to Brainbender Comic Maker')
        self.setSubTitle('This wizard connects the app to ComfyUI and checks that at least one Stable Diffusion checkpoint is available.')
        layout = QVBoxLayout(self)
        msg = QLabel(
            'Brainbender Comic Maker is the comic-making frontend. ComfyUI is the image generation engine.\n\n'
            'This wizard will help you:\n'
            '• Find your ComfyUI folder\n'
            '• Save the ComfyUI API address\n'
            '• Check checkpoint models\n'
            '• Start ComfyUI from one button'
        )
        msg.setWordWrap(True)
        layout.addWidget(msg)


class ComfyFolderPage(QWizardPage):
    def __init__(self, settings: Settings):
        super().__init__()
        self.settings = settings
        self.setTitle('ComfyUI folder')
        self.setSubTitle('Choose the folder that contains ComfyUI/main.py.')
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.url = QLineEdit(settings.get('comfy_url'))
        self.path = QLineEdit(settings.get('comfy_path'))
        choose = QPushButton('Browse...')
        choose.clicked.connect(self.choose_folder)
        auto = QPushButton('Auto-detect')
        auto.clicked.connect(self.auto_detect)
        row = QHBoxLayout(); row.addWidget(self.path); row.addWidget(choose); row.addWidget(auto)
        form.addRow('ComfyUI URL', self.url)
        form.addRow('ComfyUI folder', row)
        layout.addLayout(form)
        self.result = QTextEdit(); self.result.setReadOnly(True); self.result.setMaximumHeight(120)
        layout.addWidget(self.result)
        self.registerField('comfy_url*', self.url)
        self.registerField('comfy_path*', self.path)

    def choose_folder(self):
        d = QFileDialog.getExistingDirectory(self, 'Choose ComfyUI folder', str(Path.home()))
        if d:
            self.path.setText(d)
            self.validate_path()

    def auto_detect(self):
        found = ComfyLauncher.candidate_paths()
        if found:
            self.path.setText(found[0])
            self.result.setPlainText('Detected ComfyUI folder:\n' + found[0])
        else:
            self.result.setPlainText('Could not auto-detect ComfyUI. Browse to the folder containing main.py.')
        self.validate_path()

    def validate_path(self):
        ok, msg = ComfyLauncher.validate_path(self.path.text())
        self.result.setPlainText(msg)
        return ok

    def validatePage(self) -> bool:
        ok, msg = ComfyLauncher.validate_path(self.path.text())
        if not ok:
            QMessageBox.warning(self, 'ComfyUI folder needed', msg)
            return False
        self.settings.set('comfy_url', self.url.text().strip())
        self.settings.set('comfy_path', self.path.text().strip())
        return True


class ModelPage(QWizardPage):
    def __init__(self, settings: Settings):
        super().__init__()
        self.settings = settings
        self.setTitle('Model check')
        self.setSubTitle('Brainbender needs at least one checkpoint in ComfyUI/models/checkpoints/.')
        layout = QVBoxLayout(self)
        self.status = QLabel('Model status not checked yet.')
        self.status.setWordWrap(True)
        check = QPushButton('Check model folder')
        check.clicked.connect(self.check_models)
        open_folder = QPushButton('Open / create checkpoints folder')
        open_folder.clicked.connect(self.open_folder)
        import_model = QPushButton('Copy a local model file into ComfyUI')
        import_model.clicked.connect(self.import_model)
        layout.addWidget(self.status)
        layout.addWidget(check)
        layout.addWidget(open_folder)
        layout.addWidget(import_model)
        tip = QLabel('Tip: use .safetensors when possible. Models are large, so this app does not bundle one inside the AppImage.')
        tip.setWordWrap(True); tip.setAlignment(Qt.AlignTop)
        layout.addWidget(tip)

    def checkpoints_dir(self) -> Path:
        p = Path(self.settings.get('comfy_path')).expanduser() / 'models' / 'checkpoints'
        p.mkdir(parents=True, exist_ok=True)
        return p

    def check_models(self):
        count, msg = ComfyLauncher.model_status(self.settings.get('comfy_path'))
        self.status.setText(msg)
        return count > 0

    def open_folder(self):
        folder = self.checkpoints_dir()
        subprocess.Popen(['xdg-open', str(folder)])
        self.status.setText(f'Opened: {folder}')

    def import_model(self):
        f, _ = QFileDialog.getOpenFileName(self, 'Choose checkpoint model', '', 'Models (*.safetensors *.ckpt *.pt)')
        if not f:
            return
        dest = self.checkpoints_dir() / Path(f).name
        if Path(f).resolve() != dest.resolve():
            shutil.copy2(f, dest)
        self.status.setText(f'Copied model to: {dest}')


class FinishPage(QWizardPage):
    def __init__(self, settings: Settings):
        super().__init__()
        self.settings = settings
        self.setTitle('Finish')
        self.setSubTitle('Save setup and optionally start ComfyUI now.')
        layout = QVBoxLayout(self)
        self.start_now = QCheckBox('Start ComfyUI when I finish')
        self.start_now.setChecked(True)
        self.log = QTextEdit(); self.log.setReadOnly(True); self.log.setMaximumHeight(160)
        layout.addWidget(self.start_now); layout.addWidget(self.log)

    def validatePage(self) -> bool:
        if self.start_now.isChecked():
            launcher = ComfyLauncher(self.settings.get('comfy_url'), self.settings.get('comfy_path'))
            ok, msg = launcher.start()
            self.log.setPlainText(msg)
            if not ok:
                QMessageBox.warning(self, 'ComfyUI did not start', msg)
        return True


class SetupWizard(QWizard):
    def __init__(self, settings: Settings, parent=None):
        super().__init__(parent)
        self.settings = settings
        self.setWindowTitle('Brainbender Comic Maker Setup Wizard')
        self.addPage(WelcomePage())
        self.addPage(ComfyFolderPage(settings))
        self.addPage(ModelPage(settings))
        self.addPage(FinishPage(settings))
        self.resize(720, 460)
