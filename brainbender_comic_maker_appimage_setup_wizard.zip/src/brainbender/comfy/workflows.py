from __future__ import annotations

import random
from pathlib import Path
from typing import Any, Dict, Optional


def safe_seed(seed_text: str | None = None) -> int:
    if seed_text and str(seed_text).strip().isdigit():
        return int(str(seed_text).strip())
    return random.randint(1, 2**31 - 1)


def text_to_image_workflow(
    *,
    checkpoint: str,
    prompt: str,
    negative_prompt: str,
    width: int = 768,
    height: int = 768,
    steps: int = 25,
    cfg: float = 7.0,
    sampler: str = "euler",
    scheduler: str = "normal",
    seed: Optional[int] = None,
    prefix: str = "brainbender_panel",
) -> Dict[str, Any]:
    seed = seed if seed is not None else safe_seed()
    return {
        "1": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": checkpoint}},
        "2": {"class_type": "CLIPTextEncode", "inputs": {"text": prompt, "clip": ["1", 1]}},
        "3": {"class_type": "CLIPTextEncode", "inputs": {"text": negative_prompt, "clip": ["1", 1]}},
        "4": {"class_type": "EmptyLatentImage", "inputs": {"width": width, "height": height, "batch_size": 1}},
        "5": {
            "class_type": "KSampler",
            "inputs": {
                "seed": seed,
                "steps": steps,
                "cfg": cfg,
                "sampler_name": sampler,
                "scheduler": scheduler,
                "denoise": 1.0,
                "model": ["1", 0],
                "positive": ["2", 0],
                "negative": ["3", 0],
                "latent_image": ["4", 0],
            },
        },
        "6": {"class_type": "VAEDecode", "inputs": {"samples": ["5", 0], "vae": ["1", 2]}},
        "7": {"class_type": "SaveImage", "inputs": {"filename_prefix": prefix, "images": ["6", 0]}},
    }


def image_to_image_workflow(
    *,
    checkpoint: str,
    prompt: str,
    negative_prompt: str,
    uploaded_image_name: str,
    steps: int = 25,
    cfg: float = 7.0,
    denoise: float = 0.55,
    sampler: str = "euler",
    scheduler: str = "normal",
    seed: Optional[int] = None,
    prefix: str = "brainbender_img2img_panel",
) -> Dict[str, Any]:
    seed = seed if seed is not None else safe_seed()
    return {
        "1": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": checkpoint}},
        "2": {"class_type": "CLIPTextEncode", "inputs": {"text": prompt, "clip": ["1", 1]}},
        "3": {"class_type": "CLIPTextEncode", "inputs": {"text": negative_prompt, "clip": ["1", 1]}},
        "4": {"class_type": "LoadImage", "inputs": {"image": uploaded_image_name}},
        "5": {"class_type": "VAEEncode", "inputs": {"pixels": ["4", 0], "vae": ["1", 2]}},
        "6": {
            "class_type": "KSampler",
            "inputs": {
                "seed": seed,
                "steps": steps,
                "cfg": cfg,
                "sampler_name": sampler,
                "scheduler": scheduler,
                "denoise": denoise,
                "model": ["1", 0],
                "positive": ["2", 0],
                "negative": ["3", 0],
                "latent_image": ["5", 0],
            },
        },
        "7": {"class_type": "VAEDecode", "inputs": {"samples": ["6", 0], "vae": ["1", 2]}},
        "8": {"class_type": "SaveImage", "inputs": {"filename_prefix": prefix, "images": ["7", 0]}},
    }
