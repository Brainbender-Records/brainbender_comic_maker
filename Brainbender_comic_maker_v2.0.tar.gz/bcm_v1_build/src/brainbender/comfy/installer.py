from __future__ import annotations

import io
import os
import shutil
import subprocess
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

import requests


LogFn = Callable[[str], None]
ProgressFn = Callable[[int, int], None]


@dataclass
class InstallResult:
    ok: bool
    path: str
    message: str


class ComfyInstaller:
    """Guided ComfyUI installer/updater.

    Supports both git-based install (for developers) and direct ZIP download
    from GitHub (for non-technical users who may not have git installed).
    """

    REPO_URL = "https://github.com/comfyanonymous/ComfyUI.git"
    API_RELEASES = "https://api.github.com/repos/comfyanonymous/ComfyUI/releases/latest"

    def __init__(
        self,
        install_dir: str | Path | None = None,
        log: Optional[LogFn] = None,
        progress: Optional[ProgressFn] = None,
    ):
        self.install_dir = Path(install_dir or (Path.home() / "ComfyUI")).expanduser()
        self.log = log or (lambda msg: None)
        self.progress = progress or (lambda current, total: None)

    def _run(self, cmd: list[str], cwd: Path | None = None, timeout: int | None = None) -> None:
        self.log("$ " + " ".join(cmd))
        proc = subprocess.Popen(
            cmd,
            cwd=str(cwd) if cwd else None,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            env={**os.environ, "PYTHONUNBUFFERED": "1"},
        )
        assert proc.stdout is not None
        for line in proc.stdout:
            self.log(line.rstrip())
        rc = proc.wait(timeout=timeout)
        if rc != 0:
            raise RuntimeError(f"Command failed with exit code {rc}: {' '.join(cmd)}")

    def check_tools(self) -> tuple[bool, str]:
        missing = []
        for tool in ("git", "python3"):
            if shutil.which(tool) is None:
                missing.append(tool)
        if missing:
            return False, "Missing required tools: " + ", ".join(missing) + ". Install them with: sudo apt install git python3 python3-venv"
        return True, "Required tools found."

    def _fetch_latest_zip_url(self) -> str:
        self.log("Fetching latest ComfyUI release info from GitHub...")
        r = requests.get(self.API_RELEASES, timeout=30)
        if not r.ok:
            raise RuntimeError(f"Failed to fetch latest release: HTTP {r.status_code}")
        data = r.json()
        tag = data.get("tag_name", "")
        zip_url = data.get("zipball_url")
        if not zip_url:
            raise RuntimeError("Could not find ZIP download URL in release data")
        self.log(f"Latest release: {tag}")
        return zip_url

    def _download_and_extract(self, zip_url: str) -> None:
        self.log(f"Downloading ComfyUI from {zip_url} ...")
        r = requests.get(zip_url, stream=True, timeout=120)
        if not r.ok:
            raise RuntimeError(f"Download failed: HTTP {r.status_code}")

        total = int(r.headers.get("content-length", 0))
        self.progress(0, total)
        downloaded = 0
        chunks: list[bytes] = []
        for chunk in r.iter_content(chunk_size=65536):
            if chunk:
                chunks.append(chunk)
                downloaded += len(chunk)
                self.progress(downloaded, total)

        data = b"".join(chunks)
        self.log(f"Downloaded {downloaded / 1024 / 1024:.1f} MB. Extracting...")

        parent = self.install_dir.parent
        parent.mkdir(parents=True, exist_ok=True)

        temp_dir = parent / f".comfy_extract_{os.getpid()}"
        if temp_dir.exists():
            shutil.rmtree(temp_dir)
        temp_dir.mkdir(parents=True)

        try:
            with zipfile.ZipFile(io.BytesIO(data)) as zf:
                members = zf.namelist()
                if not members:
                    raise RuntimeError("ZIP archive is empty")
                top_dir = members[0].rstrip("/").split("/")[0]
                self.log(f"Extracting {len(members)} files...")
                for i, name in enumerate(members):
                    target = temp_dir / "/".join(name.split("/")[1:])
                    if name.endswith("/"):
                        target.mkdir(parents=True, exist_ok=True)
                    else:
                        target.parent.mkdir(parents=True, exist_ok=True)
                        with zf.open(name) as src, open(target, "wb") as dst:
                            shutil.copyfileobj(src, dst)
                    if i % 500 == 0:
                        self.progress(i, len(members))

            extracted = temp_dir / top_dir if (temp_dir / "main.py").exists() else temp_dir
            if not (extracted / "main.py").exists():
                raise RuntimeError("Downloaded archive does not contain ComfyUI (main.py not found)")

            if self.install_dir.exists():
                self.log(f"Removing old install at {self.install_dir}...")
                shutil.rmtree(self.install_dir)

            shutil.copytree(extracted, self.install_dir)
            self.log(f"Extracted ComfyUI to {self.install_dir}")
        finally:
            if temp_dir.exists():
                shutil.rmtree(temp_dir)

    def _setup_venv_and_requirements(self) -> None:
        venv = self.install_dir / "venv"
        if not (venv / "bin" / "python").exists():
            self.log("Creating ComfyUI virtual environment...")
            self._run(["python3", "-m", "venv", str(venv)])

        py = venv / "bin" / "python"
        pip = venv / "bin" / "pip"
        self.log("Upgrading pip...")
        self._run([str(py), "-m", "pip", "install", "--upgrade", "pip"])
        req = self.install_dir / "requirements.txt"
        if req.exists():
            self.log("Installing ComfyUI Python requirements (this can take a while)...")
            self._run([str(pip), "install", "-r", str(req)])

        (self.install_dir / "models" / "checkpoints").mkdir(parents=True, exist_ok=True)

    def install_or_update(self) -> InstallResult:
        try:
            has_git = shutil.which("git") is not None
            has_dir = (self.install_dir / ".git").exists() or (self.install_dir / "main.py").exists()

            if has_git and has_dir:
                self.log(f"Existing ComfyUI found at {self.install_dir}; updating with git...")
                self._run(["git", "pull", "--ff-only"], cwd=self.install_dir)
            elif has_git and not has_dir:
                if self.install_dir.exists() and any(self.install_dir.iterdir()):
                    return InstallResult(False, str(self.install_dir), "Install folder exists but is not empty and does not look like ComfyUI.")
                self.install_dir.parent.mkdir(parents=True, exist_ok=True)
                self.log(f"Cloning ComfyUI into {self.install_dir}...")
                self._run(["git", "clone", self.REPO_URL, str(self.install_dir)])
            elif has_dir:
                self.log(f"Existing ComfyUI found at {self.install_dir}; updating via ZIP...")
                zip_url = self._fetch_latest_zip_url()
                self._download_and_extract(zip_url)
            else:
                if self.install_dir.exists() and any(self.install_dir.iterdir()):
                    return InstallResult(False, str(self.install_dir), "Install folder exists but is not empty and does not look like ComfyUI.")
                self.log("No git found. Downloading ComfyUI as ZIP from GitHub...")
                zip_url = self._fetch_latest_zip_url()
                self._download_and_extract(zip_url)

            self._setup_venv_and_requirements()
            return InstallResult(True, str(self.install_dir), "ComfyUI installed/updated successfully.")
        except Exception as exc:
            return InstallResult(False, str(self.install_dir), str(exc))
