from __future__ import annotations

import json
import shutil
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Callable, List, Optional
from urllib.parse import urlparse

import requests

MODEL_EXTENSIONS = ('.safetensors', '.ckpt', '.pt')

CURATED_MODELS: list[dict] = [
    {
        "name": "Stable Diffusion 1.5",
        "filename": "v1-5-pruned-emaonly.safetensors",
        "url": "https://huggingface.co/runwayml/stable-diffusion-v1-5/resolve/main/v1-5-pruned-emaonly.safetensors",
        "size_gb": 4.0,
        "description": "The classic SD 1.5 base model. Good starting point for comic panels. Works with most LoRAs and ControlNet models.",
        "license": "CreativeML Open RAIL-M",
        "source": "HuggingFace (runwayml)",
    },
    {
        "name": "Stable Diffusion XL 1.0 Base",
        "filename": "sd_xl_base_1.0.safetensors",
        "url": "https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0/resolve/main/sd_xl_base_1.0.safetensors",
        "size_gb": 6.9,
        "description": "SDXL base model — higher quality, better composition, 1024x1024 native. Requires more VRAM (8 GB+).",
        "license": "CreativeML Open RAIL-M",
        "source": "HuggingFace (stabilityai)",
    },
    {
        "name": "Stable Diffusion XL 1.0 Refiner",
        "filename": "sd_xl_refiner_1.0.safetensors",
        "url": "https://huggingface.co/stabilityai/stable-diffusion-xl-refiner-1.0/resolve/main/sd_xl_refiner_1.0.safetensors",
        "size_gb": 6.0,
        "description": "SDXL refiner — used after the base model to add fine details. Optional but recommended for highest quality.",
        "license": "CreativeML Open RAIL-M",
        "source": "HuggingFace (stabilityai)",
    },
    {
        "name": "DreamShaper 8",
        "filename": "dreamshaper_8.safetensors",
        "url": "https://huggingface.co/Lykon/dreamshaper-8/resolve/main/dreamshaper_8.safetensors",
        "size_gb": 4.0,
        "description": "Popular fine-tuned model with a vibrant, artistic style. Great for fantasy, sci-fi, and stylized comics.",
        "license": "CreativeML Open RAIL-M",
        "source": "HuggingFace (Lykon)",
    },
    {
        "name": "Realistic Vision V6.0",
        "filename": "realisticVisionV60B1_v60B1VAE.safetensors",
        "url": "https://huggingface.co/SG161222/Realistic_Vision_V6.0_B1_noVAE/resolve/main/realisticVisionV60B1_v60B1VAE.safetensors",
        "size_gb": 4.0,
        "description": "High-quality photorealistic model. Ideal for realistic comic art and character renders.",
        "license": "CreativeML Open RAIL-M",
        "source": "HuggingFace (SG161222)",
    },
    {
        "name": "LCM LoRA (SD 1.5)",
        "filename": "lcm-lora-sdv1-5.safetensors",
        "url": "https://huggingface.co/latent-consistency/lcm-lora-sdv1-5/resolve/main/lcm-lora-sdv1-5.safetensors",
        "size_gb": 0.089,
        "description": "LoRA that enables 2-4 step inference with SD 1.5. Place in ComfyUI/models/loras/. Drastically speeds up generation.",
        "license": "Apache 2.0",
        "source": "HuggingFace (latent-consistency)",
    },
    {
        "name": "LCM LoRA (SDXL)",
        "filename": "lcm-lora-sdxl.safetensors",
        "url": "https://huggingface.co/latent-consistency/lcm-lora-sdxl/resolve/main/lcm-lora-sdxl.safetensors",
        "size_gb": 0.195,
        "description": "LoRA that enables 2-4 step inference with SDXL. Place in ComfyUI/models/loras/. Drastically speeds up SDXL generation.",
        "license": "Apache 2.0",
        "source": "HuggingFace (latent-consistency)",
    },
]


@dataclass
class ModelEntry:
    name: str
    path: str
    size_bytes: int
    modified: float


class ModelManager:
    def __init__(self, comfy_path: str | Path):
        self.comfy_path = Path(comfy_path).expanduser() if comfy_path else Path()
        self.checkpoint_dir = self.comfy_path / 'models' / 'checkpoints'
        self.downloads_file = self.comfy_path / 'models' / 'brainbender_model_downloads.json'

    def is_configured(self) -> bool:
        return bool(str(self.comfy_path)) and (self.comfy_path / 'main.py').exists()

    def ensure_checkpoint_dir(self) -> Path:
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        return self.checkpoint_dir

    def scan_checkpoints(self) -> List[ModelEntry]:
        if not self.checkpoint_dir.exists():
            return []
        entries: List[ModelEntry] = []
        for p in sorted(self.checkpoint_dir.iterdir()):
            if p.is_file() and p.suffix.lower() in MODEL_EXTENSIONS:
                st = p.stat()
                entries.append(ModelEntry(p.name, str(p), st.st_size, st.st_mtime))
        return entries

    def scan_loras(self) -> list[str]:
        lora_dir = self.comfy_path / 'models' / 'loras'
        if not lora_dir.exists():
            return []
        return sorted(
            x.name
            for x in lora_dir.iterdir()
            if x.is_file() and x.suffix.lower() in MODEL_EXTENSIONS
        )

    def curated_list(self) -> list[dict]:
        return list(CURATED_MODELS)

    def import_model(self, source: str | Path) -> Path:
        src = Path(source).expanduser()
        if not src.exists():
            raise FileNotFoundError(f'Model file not found: {src}')
        if src.suffix.lower() not in MODEL_EXTENSIONS:
            raise ValueError('Model must be .safetensors, .ckpt, or .pt')
        self.ensure_checkpoint_dir()
        dest = self.checkpoint_dir / src.name
        if src.resolve() != dest.resolve():
            shutil.copy2(src, dest)
        return dest

    def load_download_presets(self) -> list[dict]:
        if self.downloads_file.exists():
            try:
                return json.loads(self.downloads_file.read_text())
            except Exception:
                return []
        return []

    def save_download_presets(self, presets: list[dict]) -> None:
        self.downloads_file.parent.mkdir(parents=True, exist_ok=True)
        self.downloads_file.write_text(json.dumps(presets, indent=2))

    def add_download_preset(self, name: str, url: str, notes: str = '') -> None:
        presets = self.load_download_presets()
        presets.append({'name': name.strip() or self._filename_from_url(url), 'url': url.strip(), 'notes': notes.strip()})
        self.save_download_presets(presets)

    def _filename_from_url(self, url: str) -> str:
        parsed = urlparse(url)
        name = Path(parsed.path).name
        return name or f'model_{int(time.time())}.safetensors'

    def _target_dir(self, filename: str) -> Path:
        lora_dir = self.comfy_path / 'models' / 'loras'
        if 'lora' in filename.lower() or 'lycoris' in filename.lower():
            lora_dir.mkdir(parents=True, exist_ok=True)
            return lora_dir
        return self.checkpoint_dir

    def download_model(self, url: str, filename: Optional[str] = None, progress: Optional[Callable[[int, int], None]] = None) -> Path:
        if not url.startswith(('http://', 'https://')):
            raise ValueError('Download URL must start with http:// or https://')
        self.ensure_checkpoint_dir()
        filename = filename or self._filename_from_url(url)
        if not filename.endswith(MODEL_EXTENSIONS):
            raise ValueError('The download filename must end in .safetensors, .ckpt, or .pt')
        target = self._target_dir(filename)
        dest = target / filename
        tmp = dest.with_suffix(dest.suffix + '.part')
        with requests.get(url, stream=True, timeout=30) as r:
            r.raise_for_status()
            total = int(r.headers.get('content-length') or 0)
            done = 0
            with tmp.open('wb') as fh:
                for chunk in r.iter_content(chunk_size=1024 * 1024):
                    if chunk:
                        fh.write(chunk)
                        done += len(chunk)
                        if progress:
                            progress(done, total)
        tmp.rename(dest)
        return dest


def human_size(size: int) -> str:
    value = float(size)
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if value < 1024 or unit == 'TB':
            return f'{value:.1f} {unit}' if unit != 'B' else f'{int(value)} B'
        value /= 1024
