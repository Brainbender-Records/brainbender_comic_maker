from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, QSize, QUrl
from PySide6.QtGui import QDrag, QPixmap
from PySide6.QtWidgets import *

from ..core.image_history import ImageHistoryManager
from ..comfy.model_manager import human_size


class DraggablePreview(QLabel):
    def __init__(self, image_path: str, parent=None):
        super().__init__(parent)
        self._drag_path = image_path
        self.setAlignment(Qt.AlignCenter)
        self.setStyleSheet("border: none;")

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton:
            drag = QDrag(self)
            mime = drag.mimeData()
            mime.setUrls([QUrl.fromLocalFile(self._drag_path)])
            pix = self.pixmap()
            if pix and not pix.isNull():
                drag.setPixmap(pix.scaled(96, 96, Qt.KeepAspectRatio, Qt.SmoothTransformation))
            drag.setMimeData(mime)
            drag.exec(Qt.CopyAction)


class ImageHistoryDialog(QDialog):
    def __init__(self, history: ImageHistoryManager, parent=None):
        super().__init__(parent)
        self.history = history
        self.setWindowTitle("Image History Browser")
        self.resize(900, 650)

        layout = QVBoxLayout(self)

        top = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search prompts...")
        self.search.textChanged.connect(self.refresh)
        top.addWidget(QLabel("Filter:"))
        top.addWidget(self.search, 1)
        self.clear_all_btn = QPushButton("Clear All")
        self.clear_all_btn.clicked.connect(self._clear_all)
        top.addWidget(self.clear_all_btn)
        layout.addLayout(top)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.grid_container = QWidget()
        self.grid_layout = QVBoxLayout(self.grid_container)
        self.scroll.setWidget(self.grid_container)
        layout.addWidget(self.scroll, 1)

        self.refresh()

    def refresh(self):
        for i in reversed(range(self.grid_layout.count())):
            item = self.grid_layout.itemAt(i)
            if item:
                w = item.widget()
                if w:
                    self.grid_layout.removeWidget(w)
                    w.deleteLater()

        query = self.search.text().strip().lower()
        entries = self.history.all_entries()
        if query:
            entries = [e for e in entries if query in e.get("prompt", "").lower()]

        if not entries:
            lbl = QLabel("No history entries yet. Generate some panels first!")
            lbl.setAlignment(Qt.AlignCenter)
            lbl.setStyleSheet("color: #888; font-size: 14px; padding: 40px;")
            self.grid_layout.addWidget(lbl)
            return

        cols = max(1, self.width() // 280)
        row_widget = None
        row_layout = None

        for i, entry in enumerate(entries):
            if i % cols == 0:
                row_widget = QWidget()
                row_layout = QHBoxLayout(row_widget)
                row_layout.setContentsMargins(0, 0, 0, 0)
                self.grid_layout.addWidget(row_widget)

            card = self._build_card(entry)
            if row_layout is not None:
                row_layout.addWidget(card)

    def _build_card(self, entry: dict) -> QWidget:
        card = QFrame()
        card.setFrameShape(QFrame.StyledPanel)
        card.setStyleSheet("QFrame { border: 1px solid #555; border-radius: 4px; margin: 4px; }")

        layout = QVBoxLayout(card)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(4)

        thumb_path = entry.get("thumbnail", "")
        image_path = entry.get("path", "")
        preview = DraggablePreview(image_path)
        preview.setFixedSize(240, 240)
        pixmap = QPixmap(thumb_path) if thumb_path and Path(thumb_path).exists() else QPixmap()
        if not pixmap.isNull():
            preview.setPixmap(pixmap.scaled(240, 240, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        else:
            preview.setText("No preview")
        layout.addWidget(preview)

        prompt = entry.get("prompt", "")[:80]
        prompt_label = QLabel(prompt if prompt else "(no prompt)")
        prompt_label.setWordWrap(True)
        prompt_label.setMaximumHeight(40)
        layout.addWidget(prompt_label)

        meta = f"{entry.get('checkpoint', '?')}  |  {entry.get('mode', '?')}"
        meta_label = QLabel(meta)
        meta_label.setStyleSheet("color: #888; font-size: 10px;")
        layout.addWidget(meta_label)

        import time
        ts = entry.get("timestamp", 0)
        date_label = QLabel(time.strftime("%Y-%m-%d %H:%M", time.localtime(ts)))
        date_label.setStyleSheet("color: #888; font-size: 10px;")
        layout.addWidget(date_label)

        btn_row = QHBoxLayout()
        view_btn = QPushButton("View")
        view_btn.clicked.connect(lambda checked, e=entry: self._view_full(e))
        use_btn = QPushButton("Use")
        use_btn.clicked.connect(lambda checked, e=entry: self._use_image(e))
        delete_btn = QPushButton("Del")
        delete_btn.clicked.connect(lambda checked, eid=entry.get("id", ""): self._delete(eid))
        btn_row.addWidget(view_btn)
        btn_row.addWidget(use_btn)
        btn_row.addWidget(delete_btn)
        layout.addLayout(btn_row)

        return card

    def _view_full(self, entry: dict):
        path = entry.get("path", "")
        if not path or not Path(path).exists():
            QMessageBox.warning(self, "File not found", f"Image not found:\n{path}")
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("Image Preview")
        dlg.resize(800, 800)
        layout = QVBoxLayout(dlg)
        pixmap = QPixmap(path)
        label = QLabel()
        label.setPixmap(pixmap.scaled(780, 680, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        label.setAlignment(Qt.AlignCenter)
        layout.addWidget(label)
        info = QLabel(
            f"Prompt: {entry.get('prompt', '')[:200]}\n"
            f"Model: {entry.get('checkpoint', '')}  |  Mode: {entry.get('mode', '')}\n"
            f"Path: {path}"
        )
        info.setWordWrap(True)
        layout.addWidget(info)
        close = QPushButton("Close")
        close.clicked.connect(dlg.accept)
        layout.addWidget(close)
        dlg.exec()

    def _use_image(self, entry: dict):
        path = entry.get("path", "")
        if path and Path(path).exists():
            parent = self.parent()
            if hasattr(parent, "generated"):
                parent.generated.append(path)
                QMessageBox.information(self, "Added", f"Added to current session:\n{path}")
                return
        QMessageBox.information(self, "Info", f"Path: {path}")

    def _delete(self, entry_id: str):
        if QMessageBox.question(self, "Delete?", "Remove this entry from history?") == QMessageBox.Yes:
            self.history.delete_entry(entry_id)
            self.refresh()

    def _clear_all(self):
        if QMessageBox.question(self, "Clear all?", "Delete all history entries and images?") == QMessageBox.Yes:
            self.history.clear_all()
            self.refresh()
