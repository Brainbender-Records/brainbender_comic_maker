from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, QRectF, QUrl
from PySide6.QtGui import (
    QBrush,
    QColor,
    QFont,
    QImage,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
)
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QGraphicsItem,
    QGraphicsPathItem,
    QGraphicsPixmapItem,
    QGraphicsRectItem,
    QGraphicsScene,
    QGraphicsTextItem,
    QGraphicsView,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QTextEdit,
    QVBoxLayout,
    QListWidgetItem,
)


class DropView(QGraphicsView):
    def __init__(self, scene, editor):
        super().__init__(scene)
        self._editor = editor
        self.setAcceptDrops(True)
        self.setRenderHints(QPainter.Antialiasing | QPainter.SmoothPixmapTransform | QPainter.TextAntialiasing)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            super().dragMoveEvent(event)

    def dropEvent(self, event):
        if event.mimeData().hasUrls():
            for url in event.mimeData().urls():
                path = url.toLocalFile()
                if path and Path(path).suffix.lower() in (".png", ".jpg", ".jpeg", ".webp"):
                    scene_pos = self.mapToScene(event.position().toPoint())
                    panel = self._editor.panel_at(scene_pos.x(), scene_pos.y())
                    if panel:
                        panel.set_image(path)
                        event.acceptProposedAction()
                        return
            event.acceptProposedAction()
        else:
            super().dropEvent(event)


from ..core.page_layout import LetteringData, PageLayoutStore, PanelData
from ..core.paths import data_dir


class PanelItem(QGraphicsRectItem):
    def __init__(self, panel: PanelData):
        super().__init__(0, 0, panel.w, panel.h)
        self.panel = panel
        self.setPos(panel.x, panel.y)
        self.setFlags(QGraphicsItem.ItemIsMovable | QGraphicsItem.ItemIsSelectable | QGraphicsItem.ItemSendsGeometryChanges)
        self.setAcceptDrops(True)
        self.setPen(QPen(Qt.black, 6))
        self.setBrush(QBrush(Qt.white))
        self.image_item = None
        self.caption_item = QGraphicsTextItem(panel.caption or "Panel")
        self.caption_item.setDefaultTextColor(Qt.black)
        self.caption_item.setParentItem(self)
        self.caption_item.setPos(12, 10)
        self._load_image()

    def _load_image(self):
        if self.image_item:
            self.image_item.setParentItem(None)
            self.image_item = None
        if self.panel.image_path and Path(self.panel.image_path).exists():
            pix = QPixmap(self.panel.image_path)
            if not pix.isNull():
                scaled = pix.scaled(int(self.panel.w), int(self.panel.h), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
                self.image_item = QGraphicsPixmapItem(scaled, self)
                self.image_item.setOffset((self.panel.w - scaled.width()) / 2, (self.panel.h - scaled.height()) / 2)
                self.image_item.setZValue(-1)

    def set_image(self, path: str):
        self.panel.image_path = path
        self._load_image()

    def sync(self):
        self.panel.x = float(self.pos().x())
        self.panel.y = float(self.pos().y())
        self.panel.w = float(self.rect().width())
        self.panel.h = float(self.rect().height())
        self.panel.caption = self.caption_item.toPlainText()


class LetteringItem(QGraphicsPathItem):
    def __init__(self, lettering: LetteringData):
        super().__init__()
        self.lettering = lettering
        self.text_item = QGraphicsTextItem(lettering.text, self)
        self.text_item.setTextWidth(max(40, lettering.w - 28))
        self.setFlags(QGraphicsItem.ItemIsMovable | QGraphicsItem.ItemIsSelectable | QGraphicsItem.ItemSendsGeometryChanges)
        self.setPos(lettering.x, lettering.y)
        self.setZValue(10)
        self.apply_style()

    def apply_style(self):
        l = self.lettering
        font = QFont("DejaVu Sans", l.font_size)
        if l.kind == "sfx":
            font.setBold(True)
            font.setItalic(True)
        self.text_item.setFont(font)
        self.text_item.setPlainText(l.text)
        self.text_item.setDefaultTextColor(Qt.black)
        self.text_item.setPos(14, 10)
        self.text_item.setTextWidth(max(40, l.w - 28))

        path = QPainterPath()
        if l.kind == "sfx" or not l.bubble:
            path.addRoundedRect(0, 0, max(l.w, 120), max(l.h, 50), 6, 6)
            self.setBrush(QBrush(QColor(255, 255, 255, 0)))
            self.setPen(QPen(Qt.NoPen))
        elif l.kind == "caption":
            path.addRoundedRect(0, 0, l.w, l.h, 10, 10)
            self.setBrush(QBrush(QColor(255, 255, 235)))
            self.setPen(QPen(Qt.black, 3))
        else:
            path.addRoundedRect(0, 0, l.w, l.h, 42, 42)
            if l.tail_x or l.tail_y:
                path.moveTo(l.w * 0.55, l.h)
                path.lineTo(l.w * 0.65, l.h)
                path.lineTo(l.tail_x, l.tail_y)
                path.closeSubpath()
            self.setBrush(QBrush(Qt.white))
            self.setPen(QPen(Qt.black, 4))
        self.setPath(path)

    def sync(self):
        self.lettering.x = float(self.pos().x())
        self.lettering.y = float(self.pos().y())
        self.lettering.text = self.text_item.toPlainText()


class ThumbnailListWidget(QListWidget):
    image_dropped = None

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setViewMode(QListWidget.IconMode)
        self.setIconSize(QRectF(0, 0, 128, 128).size().toSize())
        self.setGridSize(QRectF(0, 0, 150, 180).size().toSize())
        self.setWordWrap(True)
        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setDropIndicatorShown(True)
        self.setDefaultDropAction(Qt.CopyAction)
        self._parent = parent

    def add_image(self, path: str):
        p = Path(path)
        if not p.exists():
            return
        pix = QPixmap(str(p))
        item = QListWidgetItem(p.name)
        if not pix.isNull():
            item.setIcon(pix.scaled(128, 128, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        item.setData(32, str(p))
        item.setToolTip(str(p))
        self.addItem(item)

    def mimeData(self, items):
        from PySide6.QtCore import QMimeData
        mime = QMimeData()
        urls = []
        for item in items:
            path = item.data(32) or ""
            if path:
                urls.append(QUrl.fromLocalFile(str(path)))
        if urls:
            mime.setUrls(urls)
        return mime

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            super().dragMoveEvent(event)

    def dropEvent(self, event):
        if event.mimeData().hasUrls():
            for url in event.mimeData().urls():
                path = url.toLocalFile()
                if path and Path(path).suffix.lower() in (".png", ".jpg", ".jpeg", ".webp"):
                    self.add_image(path)
            event.acceptProposedAction()
        else:
            super().dropEvent(event)


class PageEditorDialog(QDialog):
    """Visual page layout editor with panels, images, lettering, JSON save/load, and PNG export."""

    def __init__(self, generated_images: list[str], parent=None):
        super().__init__(parent)
        self.setWindowTitle("Brainbender Page Layout + Lettering Editor")
        self.resize(1320, 880)
        self.store = PageLayoutStore()
        self.generated_images = generated_images
        self.layout_data = self.store.template("6 Panel Grid")
        self.scene = QGraphicsScene(self)
        self.view = DropView(self.scene, self)
        self.panel_items: list[PanelItem] = []
        self.lettering_items: list[LetteringItem] = []
        self._build_ui()
        self.render_layout()

    def _build_ui(self):
        root = QHBoxLayout(self)
        side = QVBoxLayout()
        root.addWidget(self.view, 1)
        root.addLayout(side)

        self.title_edit = QLineEdit(self.layout_data.title)
        self.template_combo = QComboBox()
        self.template_combo.addItems(["Single Splash", "3 Row Page", "4 Panel Grid", "6 Panel Grid", "Splash + 2 Bottom"])
        self.template_combo.setCurrentText("6 Panel Grid")
        self.page_width = QSpinBox()
        self.page_width.setRange(600, 4000)
        self.page_width.setValue(self.layout_data.width)
        self.page_width.setSingleStep(100)
        self.page_height = QSpinBox()
        self.page_height.setRange(600, 6000)
        self.page_height.setValue(self.layout_data.height)
        self.page_height.setSingleStep(100)

        self.image_list = ThumbnailListWidget(self)
        self.image_list.itemDoubleClicked.connect(self._assign_selected_image)
        for img in self.generated_images:
            self.image_list.add_image(img)

        self.letter_kind = QComboBox()
        self.letter_kind.addItems(["speech", "caption", "sfx"])
        self.letter_text = QTextEdit()
        self.letter_text.setPlaceholderText("Dialogue, caption, or sound effect text...")
        self.letter_text.setMaximumHeight(85)
        self.letter_size = QSpinBox()
        self.letter_size.setRange(8, 96)
        self.letter_size.setValue(28)
        self.letter_bubble = QCheckBox("Draw bubble/box")
        self.letter_bubble.setChecked(True)
        self.letter_width = QSpinBox()
        self.letter_width.setRange(80, 900)
        self.letter_width.setValue(320)
        self.letter_height = QSpinBox()
        self.letter_height.setRange(40, 500)
        self.letter_height.setValue(130)

        buttons = [
            ("Apply Template", self.apply_template),
            ("Add Blank Panel", self.add_panel),
            ("Delete Selected Panel", self.delete_selected),
            ("Assign Image to Selected Panel", self.assign_image),
            ("Add Lettering", self.add_lettering),
            ("Update Selected Lettering", self.update_selected_lettering),
            ("Delete Selected Lettering", self.delete_selected_lettering),
            ("Save Layout JSON", self.save_layout),
            ("Load Layout JSON", self.load_layout),
            ("Export Lettered Page PNG", self.export_png),
        ]

        side.addWidget(QLabel("Page Title"))
        side.addWidget(self.title_edit)
        side.addWidget(QLabel("Template"))
        side.addWidget(self.template_combo)
        side.addWidget(QLabel("Width"))
        side.addWidget(self.page_width)
        side.addWidget(QLabel("Height"))
        side.addWidget(self.page_height)
        for label, slot in buttons[:4]:
            b = QPushButton(label)
            b.clicked.connect(slot)
            side.addWidget(b)
        side.addWidget(QLabel("Images (drag from here to panels, or drop files in)"))
        side.addWidget(self.image_list, 1)
        side.addWidget(QLabel("Lettering Type"))
        side.addWidget(self.letter_kind)
        side.addWidget(QLabel("Lettering Text"))
        side.addWidget(self.letter_text)
        side.addWidget(QLabel("Font Size"))
        side.addWidget(self.letter_size)
        side.addWidget(QLabel("Box/Bubble Width"))
        side.addWidget(self.letter_width)
        side.addWidget(QLabel("Box/Bubble Height"))
        side.addWidget(self.letter_height)
        side.addWidget(self.letter_bubble)
        for label, slot in buttons[4:]:
            b = QPushButton(label)
            b.clicked.connect(slot)
            side.addWidget(b)

    def render_layout(self):
        self.scene.clear()
        self.panel_items = []
        self.lettering_items = []
        self.scene.setSceneRect(0, 0, self.layout_data.width, self.layout_data.height)
        page = self.scene.addRect(0, 0, self.layout_data.width, self.layout_data.height, QPen(Qt.black, 2), QBrush(Qt.white))
        page.setZValue(-10)
        for panel in self.layout_data.panels:
            item = PanelItem(panel)
            self.scene.addItem(item)
            self.panel_items.append(item)
        for lettering in self.layout_data.lettering:
            item = LetteringItem(lettering)
            self.scene.addItem(item)
            self.lettering_items.append(item)
        self.view.fitInView(self.scene.sceneRect(), Qt.KeepAspectRatio)

    def panel_at(self, x: float, y: float) -> PanelItem | None:
        for item in self.panel_items:
            r = item.rect()
            if item.x() <= x <= item.x() + r.width() and item.y() <= y <= item.y() + r.height():
                return item
        return None

    def current_panel(self) -> PanelItem | None:
        for item in self.scene.selectedItems():
            if isinstance(item, PanelItem):
                return item
        return None

    def current_lettering(self) -> LetteringItem | None:
        for item in self.scene.selectedItems():
            if isinstance(item, LetteringItem):
                return item
        return None

    def sync_items(self):
        self.layout_data.title = self.title_edit.text().strip() or "Untitled Page"
        self.layout_data.width = self.page_width.value()
        self.layout_data.height = self.page_height.value()
        for item in self.panel_items:
            item.sync()
        for item in self.lettering_items:
            item.sync()

    def apply_template(self):
        self.sync_items()
        old_letters = list(self.layout_data.lettering)
        self.layout_data = self.store.template(self.template_combo.currentText(), self.page_width.value(), self.page_height.value())
        self.layout_data.lettering = old_letters
        self.title_edit.setText(self.layout_data.title)
        self.render_layout()

    def add_panel(self):
        self.sync_items()
        self.layout_data.panels.append(self.store.make_panel(100, 100, 420, 320))
        self.render_layout()

    def delete_selected(self):
        item = self.current_panel()
        if not item:
            return
        self.sync_items()
        self.layout_data.panels = [p for p in self.layout_data.panels if p.id != item.panel.id]
        self.render_layout()

    def _assign_selected_image(self, item):
        panel = self.current_panel()
        if not panel:
            QMessageBox.information(self, "Select panel", "Click a panel on the page first.")
            return
        path = item.data(32) or ""
        if path:
            panel.set_image(path)

    def assign_image(self):
        item = self.current_panel()
        if not item:
            QMessageBox.information(self, "Select panel", "Click a panel first.")
            return
        list_item = self.image_list.currentItem()
        path = list_item.data(32) if list_item else ""
        if not path:
            path, _ = QFileDialog.getOpenFileName(self, "Choose panel image", "", "Images (*.png *.jpg *.jpeg *.webp)")
        if path:
            item.set_image(path)

    def add_lettering(self):
        self.sync_items()
        text = self.letter_text.toPlainText().strip() or "New text"
        lettering = self.store.make_lettering(self.letter_kind.currentText(), text, 120, 120, self.letter_size.value())
        lettering.w = self.letter_width.value()
        lettering.h = self.letter_height.value()
        lettering.bubble = self.letter_bubble.isChecked()
        self.layout_data.lettering.append(lettering)
        self.render_layout()

    def update_selected_lettering(self):
        item = self.current_lettering()
        if not item:
            QMessageBox.information(self, "Select lettering", "Click a speech bubble, caption, or SFX text first.")
            return
        item.lettering.kind = self.letter_kind.currentText()
        item.lettering.text = self.letter_text.toPlainText().strip() or item.lettering.text
        item.lettering.font_size = self.letter_size.value()
        item.lettering.w = self.letter_width.value()
        item.lettering.h = self.letter_height.value()
        item.lettering.bubble = self.letter_bubble.isChecked()
        item.apply_style()

    def delete_selected_lettering(self):
        item = self.current_lettering()
        if not item:
            return
        self.sync_items()
        self.layout_data.lettering = [l for l in self.layout_data.lettering if l.id != item.lettering.id]
        self.render_layout()

    def save_layout(self):
        self.sync_items()
        path = self.store.save(self.layout_data)
        QMessageBox.information(self, "Saved", f"Saved layout and lettering:\n{path}")

    def load_layout(self):
        path, _ = QFileDialog.getOpenFileName(self, "Load page layout", str(self.store.root), "Page Layout (*.json)")
        if path:
            self.layout_data = self.store.load(path)
            self.title_edit.setText(self.layout_data.title)
            self.page_width.setValue(self.layout_data.width)
            self.page_height.setValue(self.layout_data.height)
            self.render_layout()

    def export_png(self):
        self.sync_items()
        out_dir = data_dir() / "exports"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in self.layout_data.title.lower()) or "page"
        path = out_dir / f"{safe}_lettered.png"
        image = QImage(self.layout_data.width, self.layout_data.height, QImage.Format_ARGB32)
        image.fill(Qt.white)
        painter = QPainter(image)
        self.scene.clearSelection()
        self.scene.render(painter, QRectF(0, 0, self.layout_data.width, self.layout_data.height), QRectF(0, 0, self.layout_data.width, self.layout_data.height))
        painter.end()
        image.save(str(path))
        QMessageBox.information(self, "Exported", f"Exported lettered page PNG:\n{path}")
