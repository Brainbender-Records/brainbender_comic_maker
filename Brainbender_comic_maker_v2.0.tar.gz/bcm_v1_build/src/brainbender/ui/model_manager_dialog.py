from __future__ import annotations

import traceback
from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import *

from ..comfy.model_manager import ModelManager, human_size


class DownloadWorker(QThread):
    progress = Signal(int, int)
    finished_ok = Signal(str)
    failed = Signal(str)

    def __init__(self, manager: ModelManager, url: str, filename: str):
        super().__init__()
        self.manager = manager
        self.url = url
        self.filename = filename

    def run(self):
        try:
            path = self.manager.download_model(self.url, self.filename or None, self.progress.emit)
            self.finished_ok.emit(str(path))
        except Exception as exc:
            self.failed.emit(f'{exc}\n\n{traceback.format_exc(limit=2)}')


class ModelManagerDialog(QDialog):
    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Brainbender Model Manager')
        self.resize(850, 620)
        self.settings = settings
        self.manager = ModelManager(settings.get('comfy_path'))
        self.worker = None
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        tabs = QTabWidget()
        layout.addWidget(tabs)

        tabs.addTab(self._installed_tab(), 'Installed Models')
        tabs.addTab(self._curated_tab(), 'Curated Models')
        tabs.addTab(self._custom_download_tab(), 'Custom Download')

        info = QLabel(
            'Models are not bundled with the app. Only import or download '
            'models you have rights to use. Some model sites require login, '
            'license acceptance, or tokens.'
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        close = QPushButton('Close')
        close.clicked.connect(self.accept)
        layout.addWidget(close)

    def _installed_tab(self):
        w = QWidget()
        layout = QVBoxLayout(w)

        self.status = QLabel('')
        layout.addWidget(self.status)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(['Model', 'Size', 'Modified', 'Path'])
        self.table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.table)

        row = QHBoxLayout()
        refresh = QPushButton('Refresh')
        import_btn = QPushButton('Import Local Model')
        open_folder = QPushButton('Open Checkpoints Folder')
        refresh.clicked.connect(self.refresh)
        import_btn.clicked.connect(self.import_local)
        open_folder.clicked.connect(self.open_folder)
        row.addWidget(refresh)
        row.addWidget(import_btn)
        row.addWidget(open_folder)
        layout.addLayout(row)

        return w

    def _curated_tab(self):
        w = QWidget()
        layout = QVBoxLayout(w)

        layout.addWidget(QLabel('Select a curated open-license model to download:'))

        self.curated_combo = QComboBox()
        self.curated_combo.currentIndexChanged.connect(self._on_curated_selected)
        layout.addWidget(self.curated_combo)

        self.curated_desc = QTextEdit()
        self.curated_desc.setReadOnly(True)
        self.curated_desc.setMaximumHeight(120)
        layout.addWidget(self.curated_desc)

        details_layout = QFormLayout()
        self.curated_filename = QLineEdit()
        self.curated_filename.setReadOnly(True)
        self.curated_size = QLabel('')
        self.curated_license = QLabel('')
        self.curated_source = QLabel('')
        details_layout.addRow('Filename:', self.curated_filename)
        details_layout.addRow('Size:', self.curated_size)
        details_layout.addRow('License:', self.curated_license)
        details_layout.addRow('Source:', self.curated_source)
        layout.addLayout(details_layout)

        self.curated_progress = QProgressBar()
        layout.addWidget(self.curated_progress)

        btn_row = QHBoxLayout()
        self.curated_dl_btn = QPushButton('Download Selected Model')
        self.curated_dl_btn.clicked.connect(self._download_curated)
        self.curated_dl_btn.setEnabled(False)
        btn_row.addWidget(self.curated_dl_btn)
        layout.addLayout(btn_row)

        layout.addStretch()

        return w

    def _custom_download_tab(self):
        w = QWidget()
        layout = QVBoxLayout(w)

        group = QGroupBox('Download from URL')
        form = QFormLayout(group)
        self.download_name = QLineEdit()
        self.download_url = QLineEdit()
        self.download_notes = QTextEdit()
        self.download_notes.setMaximumHeight(65)
        self.custom_progress = QProgressBar()
        save_preset = QPushButton('Save Download Entry')
        download = QPushButton('Download Model From URL')
        save_preset.clicked.connect(self.save_download_entry)
        download.clicked.connect(self.download_from_url)
        form.addRow('Filename', self.download_name)
        form.addRow('Model URL', self.download_url)
        form.addRow('Notes / license reminder', self.download_notes)
        form.addRow('', save_preset)
        form.addRow('', download)
        form.addRow('Progress', self.custom_progress)
        layout.addWidget(group)

        self.preset_list = QListWidget()
        self.preset_list.itemDoubleClicked.connect(self.load_preset)
        layout.addWidget(QLabel('Saved download entries. Double-click to load one.'))
        layout.addWidget(self.preset_list)

        return w

    def refresh(self):
        if not self.manager.is_configured():
            self.status.setText('ComfyUI is not configured. Set the ComfyUI folder in Settings first.')
            return
        self.manager.ensure_checkpoint_dir()
        models = self.manager.scan_checkpoints()
        self.status.setText(f'Checkpoint folder: {self.manager.checkpoint_dir} — {len(models)} model(s) found')
        self.table.setRowCount(len(models))
        for r, m in enumerate(models):
            self.table.setItem(r, 0, QTableWidgetItem(m.name))
            self.table.setItem(r, 1, QTableWidgetItem(human_size(m.size_bytes)))
            self.table.setItem(r, 2, QTableWidgetItem(str(Path(m.path).stat().st_mtime)))
            self.table.setItem(r, 3, QTableWidgetItem(m.path))

        self.preset_list.clear()
        for p in self.manager.load_download_presets():
            item = QListWidgetItem(p.get('name') or p.get('url'))
            item.setData(32, p)
            self.preset_list.addItem(item)

        self._populate_curated()

    def _populate_curated(self):
        current = self.curated_combo.currentText()
        self.curated_combo.blockSignals(True)
        self.curated_combo.clear()
        for m in self.manager.curated_list():
            self.curated_combo.addItem(m['name'], m)
        if current:
            self.curated_combo.setCurrentText(current)
        self.curated_combo.blockSignals(False)
        self._on_curated_selected(0)
        self.curated_dl_btn.setEnabled(len(self.manager.curated_list()) > 0)

    def _on_curated_selected(self, index):
        data = self.curated_combo.itemData(index)
        if not data:
            self.curated_desc.clear()
            self.curated_filename.clear()
            self.curated_size.setText('')
            self.curated_license.setText('')
            self.curated_source.setText('')
            return
        self.curated_desc.setPlainText(data.get('description', ''))
        self.curated_filename.setText(data.get('filename', ''))
        size_gb = data.get('size_gb', 0)
        self.curated_size.setText(f'{size_gb:.1f} GB')
        self.curated_license.setText(data.get('license', ''))
        self.curated_source.setText(data.get('source', ''))

    def _download_curated(self):
        data = self.curated_combo.currentData()
        if not data:
            return

        size_gb = data.get('size_gb', 0)
        filename = data.get('filename', '')
        name = data.get('name', '')

        reply = QMessageBox.question(
            self,
            'Download model?',
            f'Download {name} ({size_gb:.1f} GB)?\n\n'
            f'Filename: {filename}\n'
            f'License: {data.get("license", "")}\n\n'
            'Make sure you have enough free disk space and a stable internet connection.',
            QMessageBox.Yes | QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return

        self.curated_progress.setValue(0)
        self.curated_dl_btn.setEnabled(False)
        self.worker = DownloadWorker(self.manager, data['url'], filename)
        self.worker.progress.connect(self._curated_progress)
        self.worker.finished_ok.connect(self._curated_done)
        self.worker.failed.connect(self._curated_failed)
        self.worker.start()

    def _curated_progress(self, done: int, total: int):
        if total:
            pct = int(done * 100 / total)
            self.curated_progress.setValue(pct)
            self.curated_progress.setFormat(f'{done // 1024**2} MB / {total // 1024**2} MB ({pct}%)')
        else:
            self.curated_progress.setMaximum(0)
            self.curated_progress.setFormat(f'{done // 1024**2} MB / ?')

    def _curated_done(self, path: str):
        self.curated_progress.setMaximum(100)
        self.curated_progress.setValue(100)
        self.curated_progress.setFormat('Complete')
        self.curated_dl_btn.setEnabled(True)
        QMessageBox.information(self, 'Download complete', f'Model saved to:\n{path}')
        self.refresh()

    def _curated_failed(self, error: str):
        self.curated_progress.setMaximum(100)
        self.curated_progress.setValue(0)
        self.curated_progress.setFormat('Failed')
        self.curated_dl_btn.setEnabled(True)
        QMessageBox.critical(self, 'Download failed', error.split('\n\n')[0])

    def import_local(self):
        f, _ = QFileDialog.getOpenFileName(self, 'Import model', '', 'Models (*.safetensors *.ckpt *.pt)')
        if not f:
            return
        try:
            path = self.manager.import_model(f)
            QMessageBox.information(self, 'Imported', f'Imported model:\n{path}')
            self.refresh()
        except Exception as exc:
            QMessageBox.critical(self, 'Import failed', str(exc))

    def open_folder(self):
        self.manager.ensure_checkpoint_dir()
        QMessageBox.information(self, 'Checkpoint folder', str(self.manager.checkpoint_dir))

    def save_download_entry(self):
        try:
            self.manager.add_download_preset(self.download_name.text(), self.download_url.text(), self.download_notes.toPlainText())
            self.refresh()
        except Exception as exc:
            QMessageBox.critical(self, 'Could not save entry', str(exc))

    def load_preset(self, item):
        p = item.data(32) or {}
        self.download_name.setText(p.get('name', ''))
        self.download_url.setText(p.get('url', ''))
        self.download_notes.setPlainText(p.get('notes', ''))

    def download_from_url(self):
        url = self.download_url.text().strip()
        filename = self.download_name.text().strip()
        if not url:
            QMessageBox.warning(self, 'URL needed', 'Paste a direct model download URL first.')
            return
        self.custom_progress.setValue(0)
        self.worker = DownloadWorker(self.manager, url, filename)
        self.worker.progress.connect(self._custom_progress)
        self.worker.finished_ok.connect(self._custom_done)
        self.worker.failed.connect(self._custom_failed)
        self.worker.start()

    def _custom_progress(self, done: int, total: int):
        if total:
            self.custom_progress.setValue(int(done * 100 / total))
        else:
            self.custom_progress.setMaximum(0)

    def _custom_done(self, path: str):
        self.custom_progress.setMaximum(100)
        self.custom_progress.setValue(100)
        QMessageBox.information(self, 'Download complete', path)
        self.refresh()

    def _custom_failed(self, error: str):
        self.custom_progress.setMaximum(100)
        self.custom_progress.setValue(0)
        QMessageBox.critical(self, 'Download failed', error.split('\n\n')[0])
