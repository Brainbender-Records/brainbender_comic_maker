from __future__ import annotations

import traceback
from pathlib import Path

from PySide6.QtCore import QThread, Signal, Qt
from PySide6.QtWidgets import *

from ..comfy.client import ComfyClient, ComfyError
from ..continuity import ContinuityStore
from ..director.page_planner import PagePlanStore
from ..director.panel_director import DirectedPromptBuilder


class PageBatchWorker(QThread):
    progress = Signal(str)
    cell_done = Signal(str, str)
    finished_ok = Signal()
    failed = Signal(str)

    def __init__(self, *, page_id: str, comfy_url: str, checkpoint: str, output_dir: str,
                 negative_prompt: str, width: int, height: int, steps: int, cfg: float,
                 sampler: str, scheduler: str, loras: list[tuple[str, float]] | None = None):
        super().__init__()
        self.page_id = page_id
        self.client = ComfyClient(comfy_url)
        self.checkpoint = checkpoint
        self.output_dir = output_dir
        self.negative_prompt = negative_prompt
        self.width = width
        self.height = height
        self.steps = steps
        self.cfg = cfg
        self.sampler = sampler
        self.scheduler = scheduler
        self.loras = loras
        self._cancel = False

    def cancel(self):
        self._cancel = True

    def run(self):
        try:
            if not self.client.ping():
                raise ComfyError("ComfyUI is not running. Start ComfyUI first or use the Setup Wizard.")
            store = PagePlanStore()
            continuity = ContinuityStore()
            builder = DirectedPromptBuilder(continuity)
            plans = {p.id: p for p in store.plans()}
            plan = plans.get(self.page_id)
            if not plan:
                raise ComfyError("Selected AI Director page plan was not found.")
            panels = store.panels_for_plan(plan)
            if not panels:
                raise ComfyError("This page has no cells yet. Create cells from a template first.")
            total = len(panels)
            for index, panel in enumerate(panels, start=1):
                if self._cancel:
                    self.progress.emit("Batch generation cancelled.")
                    break
                if not panel.generated_prompt.strip():
                    panel.generated_prompt = builder.build(panel)
                    store.panel_store.upsert_panel(panel)
                prompt = panel.generated_prompt.strip() or panel.user_prompt.strip() or "comic book panel"
                self.progress.emit(f"Generating {plan.page_name} / Cell {panel.panel_number} ({index}/{total})...")
                kwargs = dict(
                    checkpoint=self.checkpoint,
                    prompt=prompt,
                    negative_prompt=self.negative_prompt,
                    out_dir=self.output_dir,
                    width=self.width,
                    height=self.height,
                    steps=self.steps,
                    cfg=self.cfg,
                    sampler=self.sampler,
                    scheduler=self.scheduler,
                )
                if self.loras:
                    kwargs["loras"] = self.loras
                image_path = self.client.generate_text_to_image(**kwargs)
                panel.generated_image = str(image_path)
                store.panel_store.upsert_panel(panel)
                self.cell_done.emit(panel.id, str(image_path))
            self.finished_ok.emit()
        except Exception as exc:
            self.failed.emit(f"{exc}\n\n{traceback.format_exc(limit=2)}")


class PageBatchDialog(QDialog):
    """Generate all cells in an AI Comic Director page plan and link outputs to each cell."""

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.setWindowTitle("AI Comic Director — Batch Generate Page")
        self.resize(900, 620)
        self.settings = settings
        self.store = PagePlanStore()
        self.worker: PageBatchWorker | None = None
        self._build_ui()
        self.refresh_pages()

    def _build_ui(self):
        root = QVBoxLayout(self)
        info = QLabel(
            "Generate every cell on a planned page. Brainbender builds/uses each cell prompt, "
            "sends the cells to ComfyUI one at a time, and saves each output path back into the page plan."
        )
        info.setWordWrap(True)
        root.addWidget(info)

        split = QHBoxLayout(); root.addLayout(split, 1)
        left = QVBoxLayout(); right = QVBoxLayout(); split.addLayout(left, 1); split.addLayout(right, 2)
        left.addWidget(QLabel("Planned Pages"))
        self.page_list = QListWidget(); self.page_list.currentItemChanged.connect(self.preview_page)
        left.addWidget(self.page_list, 1)
        refresh = QPushButton("Refresh Pages")
        refresh.clicked.connect(self.refresh_pages)
        left.addWidget(refresh)

        grid = QGridLayout(); right.addLayout(grid)
        self.checkpoint = QLineEdit()
        self.output_dir = QLineEdit(str(Path.home() / "BrainbenderComicOutput"))
        self.negative = QLineEdit("blurry, low quality, bad hands, watermark, unreadable text")
        self.width = QSpinBox(); self.width.setRange(256, 2048); self.width.setSingleStep(64); self.width.setValue(768)
        self.height = QSpinBox(); self.height.setRange(256, 2048); self.height.setSingleStep(64); self.height.setValue(768)
        self.steps = QSpinBox(); self.steps.setRange(1, 150); self.steps.setValue(25)
        self.cfg = QDoubleSpinBox(); self.cfg.setRange(1.0, 30.0); self.cfg.setSingleStep(0.5); self.cfg.setValue(7.0)
        self.sampler = QComboBox(); self.sampler.addItems(["euler", "euler_ancestral", "heun", "dpm_2", "dpmpp_2m", "dpmpp_sde", "ddim"])
        self.scheduler = QComboBox(); self.scheduler.addItems(["normal", "karras", "exponential", "sgm_uniform", "simple", "ddim_uniform"])
        grid.addWidget(QLabel("Checkpoint filename"), 0, 0); grid.addWidget(self.checkpoint, 0, 1, 1, 3)
        grid.addWidget(QLabel("Output folder"), 1, 0); grid.addWidget(self.output_dir, 1, 1, 1, 3)
        grid.addWidget(QLabel("Negative prompt"), 2, 0); grid.addWidget(self.negative, 2, 1, 1, 3)
        grid.addWidget(QLabel("Width"), 3, 0); grid.addWidget(self.width, 3, 1)
        grid.addWidget(QLabel("Height"), 3, 2); grid.addWidget(self.height, 3, 3)
        grid.addWidget(QLabel("Steps"), 4, 0); grid.addWidget(self.steps, 4, 1)
        grid.addWidget(QLabel("CFG"), 4, 2); grid.addWidget(self.cfg, 4, 3)
        grid.addWidget(QLabel("Sampler"), 5, 0); grid.addWidget(self.sampler, 5, 1)
        grid.addWidget(QLabel("Scheduler"), 5, 2); grid.addWidget(self.scheduler, 5, 3)
        self.batch_loras = QLineEdit()
        self.batch_loras.setPlaceholderText("lora1.safetensors:0.75,lora2.safetensors:0.5")
        grid.addWidget(QLabel("LoRAs (name:weight,)"), 6, 0); grid.addWidget(self.batch_loras, 6, 1, 1, 3)

        right.addWidget(QLabel("Cells in selected page"))
        self.preview = QPlainTextEdit(); self.preview.setReadOnly(True)
        right.addWidget(self.preview, 1)

        buttons = QHBoxLayout(); root.addLayout(buttons)
        self.generate_btn = QPushButton("Generate Selected Page")
        self.cancel_btn = QPushButton("Cancel")
        self.close_btn = QPushButton("Close")
        self.generate_btn.clicked.connect(self.generate_selected_page)
        self.cancel_btn.clicked.connect(self.cancel_generation)
        self.close_btn.clicked.connect(self.accept)
        buttons.addWidget(self.generate_btn); buttons.addWidget(self.cancel_btn); buttons.addStretch(1); buttons.addWidget(self.close_btn)

        root.addWidget(QLabel("Progress"))
        self.log_box = QPlainTextEdit(); self.log_box.setReadOnly(True); self.log_box.setMaximumHeight(160)
        root.addWidget(self.log_box)

    def refresh_pages(self):
        self.page_list.clear()
        for plan in self.store.plans():
            panels = self.store.panels_for_plan(plan)
            done = sum(1 for p in panels if p.generated_image)
            item = QListWidgetItem(f"{plan.page_name} — {len(panels)} cells, {done} generated")
            item.setData(Qt.UserRole, plan.id)
            self.page_list.addItem(item)
        parent = self.parent()
        if parent and hasattr(parent, "model_combo"):
            text = parent.model_combo.currentText().strip()
            if text and not text.startswith("No checkpoint"):
                self.checkpoint.setText(text)
        if self.settings.get("output_dir"):
            self.output_dir.setText(self.settings.get("output_dir"))

    def selected_page_id(self) -> str:
        item = self.page_list.currentItem()
        return item.data(Qt.UserRole) if item else ""

    def preview_page(self):
        page_id = self.selected_page_id()
        plans = {p.id: p for p in self.store.plans()}
        plan = plans.get(page_id)
        if not plan:
            self.preview.clear(); return
        lines = [f"{plan.page_name}: {plan.title}", f"Summary: {plan.summary}", ""]
        for p in self.store.panels_for_plan(plan):
            lines.append(f"Cell {p.panel_number}")
            lines.append(f"User prompt: {p.user_prompt or '[empty]'}")
            lines.append(f"Generated image: {p.generated_image or '[not generated]'}")
            lines.append("")
        self.preview.setPlainText("\n".join(lines))

    def log(self, text: str):
        self.log_box.appendPlainText(text)
        parent = self.parent()
        if parent and hasattr(parent, "log"):
            parent.log(text)

    def generate_selected_page(self):
        page_id = self.selected_page_id()
        if not page_id:
            QMessageBox.warning(self, "No page selected", "Select a planned page first.")
            return
        ckpt = self.checkpoint.text().strip()
        if not ckpt:
            QMessageBox.warning(self, "Checkpoint needed", "Enter/select the ComfyUI checkpoint filename to use.")
            return
        self.generate_btn.setEnabled(False)
        loras = []
        for part in self.batch_loras.text().strip().split(","):
            part = part.strip()
            if ":" in part:
                name, weight = part.rsplit(":", 1)
                try:
                    loras.append((name.strip(), float(weight.strip())))
                except ValueError:
                    pass
            elif part:
                loras.append((part, 0.75))
        self.worker = PageBatchWorker(
            page_id=page_id,
            comfy_url=self.settings.get("comfy_url"),
            checkpoint=ckpt,
            output_dir=self.output_dir.text().strip(),
            negative_prompt=self.negative.text().strip(),
            width=self.width.value(),
            height=self.height.value(),
            steps=self.steps.value(),
            cfg=self.cfg.value(),
            sampler=self.sampler.currentText(),
            scheduler=self.scheduler.currentText(),
            loras=loras or None,
        )
        self.worker.progress.connect(self.log)
        self.worker.cell_done.connect(lambda _panel_id, path: self.log(f"Saved generated cell image: {path}"))
        self.worker.finished_ok.connect(self.batch_finished)
        self.worker.failed.connect(self.batch_failed)
        self.log("Starting page batch generation...")
        self.worker.start()

    def cancel_generation(self):
        if self.worker and self.worker.isRunning():
            self.worker.cancel()
            self.log("Cancel requested. The current ComfyUI job may finish before stopping.")

    def batch_finished(self):
        self.generate_btn.setEnabled(True)
        self.store = PagePlanStore()
        self.refresh_pages()
        self.preview_page()
        self.log("Page batch generation finished.")

    def batch_failed(self, error: str):
        self.generate_btn.setEnabled(True)
        self.log("Batch generation failed:\n" + error)
        QMessageBox.critical(self, "Batch generation failed", error.split("\n\n")[0])
