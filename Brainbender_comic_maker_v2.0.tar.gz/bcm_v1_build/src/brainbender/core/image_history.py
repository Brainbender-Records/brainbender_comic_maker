from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

from PIL import Image

from .paths import HISTORY_DIR


class ImageHistoryManager:
    def __init__(self):
        self.index_file = HISTORY_DIR / "history_index.json"
        self.thumb_dir = HISTORY_DIR / ".thumbnails"
        self.thumb_dir.mkdir(parents=True, exist_ok=True)
        self._entries: list[dict] = []
        self._load()

    def _load(self):
        if self.index_file.exists():
            try:
                self._entries = json.loads(self.index_file.read_text())
            except Exception:
                self._entries = []

    def _save(self):
        self.index_file.write_text(json.dumps(self._entries, indent=2))

    def add_entry(
        self,
        image_path: str | Path,
        prompt: str = "",
        negative_prompt: str = "",
        checkpoint: str = "",
        mode: str = "txt2img",
        params: Optional[Dict[str, Any]] = None,
    ) -> dict:
        src = Path(image_path)
        entry_id = str(uuid.uuid4())
        dest = HISTORY_DIR / f"{entry_id}{src.suffix}"
        if src.resolve() != dest.resolve():
            dest.parent.mkdir(parents=True, exist_ok=True)
            import shutil
            shutil.copy2(str(src), str(dest))

        thumb_path = self._make_thumbnail(dest)

        entry = {
            "id": entry_id,
            "path": str(dest),
            "thumbnail": str(thumb_path) if thumb_path else "",
            "prompt": prompt,
            "negative_prompt": negative_prompt,
            "checkpoint": checkpoint,
            "mode": mode,
            "params": params or {},
            "timestamp": time.time(),
        }
        self._entries.insert(0, entry)
        self._save()
        return entry

    def _make_thumbnail(self, image_path: Path) -> Optional[Path]:
        try:
            img = Image.open(image_path)
            resample = getattr(Image.Resampling, "LANCZOS", getattr(Image, "LANCZOS", Image.BICUBIC))
            img.thumbnail((256, 256), resample)
            thumb_path = self.thumb_dir / f"{image_path.stem}_thumb{image_path.suffix}"
            img.save(thumb_path)
            return thumb_path
        except Exception:
            return None

    def all_entries(self) -> List[dict]:
        return list(self._entries)

    def get_entry(self, entry_id: str) -> Optional[dict]:
        for e in self._entries:
            if e.get("id") == entry_id:
                return e
        return None

    def delete_entry(self, entry_id: str) -> bool:
        for i, e in enumerate(self._entries):
            if e.get("id") == entry_id:
                path = Path(e.get("path", ""))
                thumb = Path(e.get("thumbnail", ""))
                try:
                    if path.exists():
                        path.unlink()
                    if thumb.exists():
                        thumb.unlink()
                except Exception:
                    pass
                self._entries.pop(i)
                self._save()
                return True
        return False

    def clear_all(self):
        for e in self._entries:
            try:
                Path(e.get("path", "")).unlink(missing_ok=True)
                Path(e.get("thumbnail", "")).unlink(missing_ok=True)
            except Exception:
                pass
        self._entries.clear()
        self._save()
