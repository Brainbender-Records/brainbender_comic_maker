from pathlib import Path
APP_DIR = Path.home()/'.local/share/brainbender-comic-maker'
PROJECTS_DIR = APP_DIR/'projects'
HISTORY_DIR = APP_DIR/'history'
SETTINGS_FILE = APP_DIR/'settings.json'
for p in (APP_DIR, PROJECTS_DIR, HISTORY_DIR):
    p.mkdir(parents=True, exist_ok=True)


def data_dir() -> Path:
    d = APP_DIR / 'data'
    d.mkdir(parents=True, exist_ok=True)
    return d
