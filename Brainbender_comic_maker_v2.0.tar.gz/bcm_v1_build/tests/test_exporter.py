from __future__ import annotations

import json
from pathlib import Path
from zipfile import ZipFile

from brainbender.exporter.exporter import Exporter


class TestExporter:
    def test_safe_name(self):
        x = Exporter()
        assert x._safe_name("My Comic!") == "my_comic"
        assert x._safe_name("Hello World") == "hello_world"
        assert x._safe_name("") == "brainbender_comic"

    def test_safe_name_no_double_underscore(self):
        x = Exporter()
        result = x._safe_name("Test  --  Name!!")
        assert "__" not in result

    def test_export_cbz(self, tmp_path: Path, tmp_img: Path):
        dest = tmp_path / "output.cbz"
        x = Exporter()
        result = x.export_cbz([str(tmp_img)], str(dest))
        assert Path(result).exists()
        with ZipFile(result) as z:
            names = z.namelist()
            assert len(names) == 1
            assert names[0].endswith("test.png")

    def test_export_cbz_skips_missing(self, tmp_path: Path, tmp_img: Path):
        dest = tmp_path / "partial.cbz"
        x = Exporter()
        result = x.export_cbz([str(tmp_img), "/nonexistent.png"], str(dest))
        with ZipFile(result) as z:
            assert len(z.namelist()) == 1

    def test_export_contact_pdf(self, tmp_path: Path, tmp_img: Path):
        dest = tmp_path / "contact.pdf"
        x = Exporter()
        result = x.export_contact_pdf([str(tmp_img)], str(dest))
        assert Path(result).exists()
        assert Path(result).stat().st_size > 0

    def test_export_contact_pdf_skips_missing(self, tmp_path: Path, tmp_img: Path):
        dest = tmp_path / "partial.pdf"
        x = Exporter()
        result = x.export_contact_pdf([str(tmp_img), "/nonexistent.png"], str(dest))
        assert Path(result).exists()

    def test_write_pdf(self, tmp_path: Path, tmp_img: Path):
        dest = tmp_path / "output.pdf"
        x = Exporter()
        result = x._write_pdf([tmp_img], dest, title="Test Comic", author="Tester")
        assert Path(result).exists()
        assert Path(result).stat().st_size > 0

    def test_write_pdf_no_images(self, tmp_path: Path):
        x = Exporter()
        import pytest
        with pytest.raises(ValueError, match="No images"):
            x._write_pdf([], tmp_path / "empty.pdf")

    def test_export_book(self, tmp_path: Path, tmp_img: Path):
        dest_dir = tmp_path / "release"
        x = Exporter()
        result = x.export_book(
            page_images=[str(tmp_img), str(tmp_img)],
            dest_dir=str(dest_dir),
            title="Test Book",
            author="Author",
            cover_image=str(tmp_img),
        )
        assert "pdf" in result
        assert "cbz" in result
        assert "title" in result
        assert "page_count" in result
        assert Path(result["pdf"]).exists()
        assert Path(result["cbz"]).exists()
        manifest_path = result.get("pages", []) and Path(result["pages"][0]).parent / "export_manifest.json"
        if manifest_path and manifest_path.exists():
            manifest = json.loads(manifest_path.read_text())
        else:
            manifest = result
        assert manifest["title"] == "Test Book"
        assert manifest["author"] == "Author"
        assert manifest["page_count"] == 3  # cover + 2 pages

    def test_export_book_no_valid_images(self, tmp_path: Path):
        x = Exporter()
        import pytest
        with pytest.raises(ValueError, match="No valid page images"):
            x.export_book(page_images=[], dest_dir=str(tmp_path / "empty"), title="Empty")
