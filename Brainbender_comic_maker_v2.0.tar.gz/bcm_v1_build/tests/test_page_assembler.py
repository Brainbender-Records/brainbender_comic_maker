from __future__ import annotations

from pathlib import Path

from brainbender.director.page_assembler import PageAssembler, DIRECTOR_TEMPLATE_TO_LAYOUT
from brainbender.director.page_planner import PagePlanStore


class TestPageAssembler:
    def test_build_layout_from_plan_4panel(self, tmp_home: Path):
        store = PagePlanStore()
        plan = store.new_plan("Page 1")
        plan.template_name = "4 cells - balanced grid"
        store.apply_template(plan)

        assembler = PageAssembler()
        layout = assembler.build_layout_from_plan(plan, width=1200, height=1800)
        assert layout.title == "Page 1"
        assert len(layout.panels) == 4
        assert layout.width == 1200
        assert layout.height == 1800

    def test_build_layout_from_plan_3cell(self, tmp_home: Path):
        store = PagePlanStore()
        plan = store.new_plan("Page 2")
        plan.template_name = "3 cells - top wide + two bottom"
        store.apply_template(plan)

        assembler = PageAssembler()
        layout = assembler.build_layout_from_plan(plan)
        assert len(layout.panels) == 3

    def test_build_layout_from_plan_6cell(self, tmp_home: Path):
        store = PagePlanStore()
        plan = store.new_plan("Page 3")
        plan.template_name = "6 cells - classic comic page"
        store.apply_template(plan)

        assembler = PageAssembler()
        layout = assembler.build_layout_from_plan(plan)
        assert len(layout.panels) == 6

    def test_build_layout_from_plan_adds_panels_if_needed(self, tmp_home: Path):
        store = PagePlanStore()
        plan = store.new_plan("Overflow Page")
        # Use a template that creates more panels than the layout template expects
        # "6 cells" maps to "6 Panel Grid" which has 6 panels
        plan.template_name = "6 cells - classic comic page"
        store.apply_template(plan)

        assembler = PageAssembler()
        layout = assembler.build_layout_from_plan(plan)
        assert len(layout.panels) >= 6

    def test_build_layout_with_dialogue(self, tmp_home: Path):
        store = PagePlanStore()
        plan = store.new_plan("Dialogue Page")
        plan.template_name = "4 cells - balanced grid"
        store.apply_template(plan)

        # Set dialogue on a panel
        panels = store.panels_for_plan(plan)
        if panels:
            panels[0].dialogue = "Hello there!"
            store.panel_store.upsert_panel(panels[0])

        assembler = PageAssembler()
        layout = assembler.build_layout_from_plan(plan, include_dialogue=True)
        assert len(layout.lettering) >= 1
        assert layout.lettering[0].text == "Hello there!"

    def test_build_layout_without_dialogue(self, tmp_home: Path):
        store = PagePlanStore()
        plan = store.new_plan("No Dialogue")
        plan.template_name = "4 cells - balanced grid"
        store.apply_template(plan)

        panels = store.panels_for_plan(plan)
        if panels:
            panels[0].dialogue = "Should not appear"
            store.panel_store.upsert_panel(panels[0])

        assembler = PageAssembler()
        layout = assembler.build_layout_from_plan(plan, include_dialogue=False)
        assert len(layout.lettering) == 0

    def test_save_layout_from_plan_missing_plan(self, tmp_home: Path):
        assembler = PageAssembler()
        import pytest
        with pytest.raises(ValueError, match="not found"):
            assembler.save_layout_from_plan("nonexistent-id")

    def test_save_layout_from_plan(self, tmp_home: Path):
        store = PagePlanStore()
        plan = store.new_plan("Save Test")
        plan.template_name = "4 cells - balanced grid"
        store.apply_template(plan)

        assembler = PageAssembler()
        path = assembler.save_layout_from_plan(plan.id)
        assert path.exists()
        assert path.suffix == ".json"

    def test_director_template_to_layout_map(self):
        assert DIRECTOR_TEMPLATE_TO_LAYOUT["3 cells - top wide + two bottom"] == "Splash + 2 Bottom"
        assert DIRECTOR_TEMPLATE_TO_LAYOUT["4 cells - balanced grid"] == "4 Panel Grid"
        assert DIRECTOR_TEMPLATE_TO_LAYOUT["6 cells - classic comic page"] == "6 Panel Grid"
