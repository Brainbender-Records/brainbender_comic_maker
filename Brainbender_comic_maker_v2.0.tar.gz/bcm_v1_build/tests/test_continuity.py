from __future__ import annotations

from dataclasses import asdict
from pathlib import Path

from brainbender.continuity import CharacterProfile, LocationProfile, ContinuityStore


class TestCharacterProfile:
    def test_defaults(self):
        c = CharacterProfile(id="abc", name="Hero")
        assert c.id == "abc"
        assert c.name == "Hero"
        assert c.description == ""
        assert c.reference_slots == []

    def test_prompt_block(self):
        c = CharacterProfile(id="x", name="Alice", description="Brave adventurer", outfit="Leather armor")
        block = c.prompt_block()
        assert "Alice" in block
        assert "Brave adventurer" in block
        assert "Leather armor" in block

    def test_prompt_block_empty_skips(self):
        c = CharacterProfile(id="y", name="Bob")
        block = c.prompt_block()
        assert "Bob" in block
        assert "Outfit:" not in block

    def test_asdict_roundtrip(self):
        c = CharacterProfile(id="z", name="Charlie", description="Test", reference_slots=[{"id": "r1", "label": "ref"}])
        d = asdict(c)
        c2 = CharacterProfile(**d)
        assert c2.name == "Charlie"
        assert c2.reference_slots == [{"id": "r1", "label": "ref"}]


class TestLocationProfile:
    def test_prompt_block_all_fields(self):
        loc = LocationProfile(id="l1", name="Gotham", description="Dark city", mood="eerie", lighting="neon", palette="dark blues")
        block = loc.prompt_block()
        assert "Gotham" in block
        assert "Dark city" in block
        assert "eerie" in block
        assert "neon" in block
        assert "dark blues" in block

    def test_prompt_block_empty_fields(self):
        loc = LocationProfile(id="l2", name="Void")
        block = loc.prompt_block()
        assert "Void" in block
        assert "Mood:" not in block
        assert "Lighting:" not in block

    def test_asdict_roundtrip(self):
        loc = LocationProfile(id="l3", name="Beach", mood="sunny", lighting="bright", palette="warm")
        d = asdict(loc)
        loc2 = LocationProfile(**d)
        assert loc2.mood == "sunny"
        assert loc2.lighting == "bright"
        assert loc2.palette == "warm"


class TestContinuityStore:
    def test_new_character(self, continuity_store: ContinuityStore, sample_character: CharacterProfile):
        assert sample_character.name == "Test Hero"
        assert sample_character.id is not None

    def test_upsert_and_list_characters(self, continuity_store: ContinuityStore, sample_character: CharacterProfile):
        continuity_store.upsert_character(sample_character)
        chars = continuity_store.characters()
        assert len(chars) == 1
        assert chars[0].name == "Test Hero"

    def test_upsert_replaces_existing(self, continuity_store: ContinuityStore, sample_character: CharacterProfile):
        continuity_store.upsert_character(sample_character)
        sample_character.name = "Updated Hero"
        continuity_store.upsert_character(sample_character)
        chars = continuity_store.characters()
        assert len(chars) == 1
        assert chars[0].name == "Updated Hero"

    def test_new_location(self, continuity_store: ContinuityStore):
        loc = continuity_store.new_location("Test City")
        assert loc.name == "Test City"
        assert loc.mood == ""
        assert loc.lighting == ""
        assert loc.palette == ""

    def test_upsert_location(self, continuity_store: ContinuityStore, sample_location: LocationProfile):
        sample_location.mood = "rainy"
        sample_location.lighting = "overcast"
        sample_location.palette = "gray tones"
        continuity_store.upsert_location(sample_location)
        locs = continuity_store.locations()
        assert len(locs) == 1
        assert locs[0].mood == "rainy"
        assert locs[0].palette == "gray tones"

    def test_import_reference(self, continuity_store: ContinuityStore, tmp_img):
        slot = continuity_store.import_reference(str(tmp_img), "hero pose", "pose")
        assert slot.label == "hero pose"
        assert slot.kind == "pose"
        assert Path(slot.path).exists()
        assert slot.path != str(tmp_img)  # should be a copy

    def test_import_reference_missing_file(self, continuity_store: ContinuityStore):
        import pytest
        with pytest.raises(FileNotFoundError):
            continuity_store.import_reference("/nonexistent/file.png", "test")

    def test_build_prompt(self, continuity_store: ContinuityStore, sample_character: CharacterProfile, sample_location: LocationProfile):
        continuity_store.upsert_character(sample_character)
        continuity_store.upsert_location(sample_location)
        prompt = continuity_store.build_prompt(
            character_ids=[sample_character.id],
            location_id=sample_location.id,
            shot="close-up",
            pose="standing",
            style="manga",
            scene_notes="nighttime",
        )
        assert "Test Hero" in prompt
        assert "Test City" in prompt
        assert "close-up" in prompt
        assert "manga" in prompt

    def test_build_prompt_no_location(self, continuity_store: ContinuityStore, sample_character: CharacterProfile):
        continuity_store.upsert_character(sample_character)
        prompt = continuity_store.build_prompt(
            character_ids=[sample_character.id],
            location_id=None,
            shot="wide",
            pose="",
            style="",
            scene_notes="",
        )
        assert "Test Hero" in prompt
        assert "Shot: wide" in prompt

    def test_validation_report_no_comfy(self, continuity_store: ContinuityStore):
        report = continuity_store.validation_report(None)
        assert "not configured" in report

    def test_validation_report_bad_path(self, continuity_store: ContinuityStore):
        report = continuity_store.validation_report("/nonexistent/comfy")
        assert "⚠️" in report
