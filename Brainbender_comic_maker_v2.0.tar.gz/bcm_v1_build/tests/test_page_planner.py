from __future__ import annotations

from pathlib import Path

from brainbender.director.page_planner import PagePlanStore, PagePlan, PAGE_TEMPLATES
from brainbender.director.panel_director import PanelCell


class TestPagePlanStore:
    def test_empty_on_start(self, tmp_home: Path):
        store = PagePlanStore()
        assert store.plans() == []

    def test_new_plan(self, tmp_home: Path):
        store = PagePlanStore()
        plan = store.new_plan("Page 1")
        assert plan.page_name == "Page 1"
        assert plan.id is not None
        assert plan.panel_ids == []

    def test_upsert_and_list(self, tmp_home: Path):
        store = PagePlanStore()
        plan = store.new_plan("Page 1")
        store.upsert_plan(plan)
        plans = store.plans()
        assert len(plans) == 1
        assert plans[0].page_name == "Page 1"

    def test_upsert_replaces(self, tmp_home: Path):
        store = PagePlanStore()
        plan = store.new_plan("Page 1")
        store.upsert_plan(plan)
        plan.title = "Updated Title"
        store.upsert_plan(plan)
        assert len(store.plans()) == 1
        assert store.plans()[0].title == "Updated Title"

    def test_delete_plan(self, tmp_home: Path):
        store = PagePlanStore()
        plan = store.new_plan("Page 1")
        store.upsert_plan(plan)
        store.delete_plan(plan.id)
        assert store.plans() == []

    def test_apply_template_creates_panels(self, tmp_home: Path):
        store = PagePlanStore()
        plan = store.new_plan("Page 1")
        plan.template_name = "4 cells - balanced grid"
        result = store.apply_template(plan)
        assert result.panel_ids is not None
        assert len(result.panel_ids) == 4

    def test_apply_template_idempotent(self, tmp_home: Path):
        store = PagePlanStore()
        plan = store.new_plan("Page 1")
        plan.template_name = "4 cells - balanced grid"
        first = store.apply_template(plan)
        first_ids = list(first.panel_ids)
        second = store.apply_template(first)
        assert second.panel_ids == first_ids

    def test_panels_for_plan(self, tmp_home: Path):
        store = PagePlanStore()
        plan = store.new_plan("Page 1")
        plan.template_name = "3 cells - top wide + two bottom"
        store.apply_template(plan)
        panels = store.panels_for_plan(plan)
        assert len(panels) == 3
        assert all(isinstance(p, PanelCell) for p in panels)

    def test_apply_template_all_templates(self, tmp_home: Path):
        for tname in PAGE_TEMPLATES:
            store = PagePlanStore()
            plan = store.new_plan("Test")
            plan.template_name = tname
            result = store.apply_template(plan)
            expected = len(PAGE_TEMPLATES[tname])
            assert len(result.panel_ids) == expected, f"{tname}: expected {expected}, got {len(result.panel_ids)}"

    def test_panels_for_plan_empty(self, tmp_home: Path):
        store = PagePlanStore()
        plan = store.new_plan("Empty")
        assert store.panels_for_plan(plan) == []

    def test_panels_sorted_by_number(self, tmp_home: Path):
        store = PagePlanStore()
        plan = store.new_plan("Page 1")
        plan.template_name = "6 cells - classic comic page"
        store.apply_template(plan)
        panels = store.panels_for_plan(plan)
        numbers = [p.panel_number for p in panels]
        assert numbers == sorted(numbers)
