from __future__ import annotations

from brainbender.comfy.workflows import (
    text_to_image_workflow,
    image_to_image_workflow,
    ipadapter_reference_workflow,
    controlnet_pose_workflow,
    apply_loras,
    safe_seed,
    workflow_required_classes,
)


class TestSafeSeed:
    def test_with_valid_digit(self):
        assert safe_seed("42") == 42

    def test_with_none(self):
        seed = safe_seed(None)
        assert 1 <= seed <= 2**31 - 1

    def test_with_non_digit(self):
        seed = safe_seed("abc")
        assert 1 <= seed <= 2**31 - 1


class TestTextToImageWorkflow:
    def test_structure(self):
        wf = text_to_image_workflow(
            checkpoint="model.safetensors",
            prompt="test",
            negative_prompt="bad",
            width=512,
            height=512,
        )
        assert "1" in wf
        assert wf["1"]["class_type"] == "CheckpointLoaderSimple"
        assert wf["1"]["inputs"]["ckpt_name"] == "model.safetensors"
        assert wf["2"]["class_type"] == "CLIPTextEncode"
        assert wf["2"]["inputs"]["text"] == "test"
        assert wf["4"]["inputs"]["width"] == 512
        assert wf["7"]["class_type"] == "SaveImage"

    def test_seed_override(self):
        wf = text_to_image_workflow(checkpoint="m", prompt="p", negative_prompt="n", seed=12345)
        assert wf["5"]["inputs"]["seed"] == 12345

    def test_custom_prefix(self):
        wf = text_to_image_workflow(checkpoint="m", prompt="p", negative_prompt="n", prefix="my_comic")
        assert wf["7"]["inputs"]["filename_prefix"] == "my_comic"


class TestImageToImageWorkflow:
    def test_structure(self):
        wf = image_to_image_workflow(
            checkpoint="m.safetensors",
            prompt="test",
            negative_prompt="bad",
            uploaded_image_name="input.png",
        )
        assert wf["4"]["class_type"] == "LoadImage"
        assert wf["4"]["inputs"]["image"] == "input.png"
        assert wf["5"]["class_type"] == "VAEEncode"

    def test_denoise(self):
        wf = image_to_image_workflow(checkpoint="m", prompt="p", negative_prompt="n", uploaded_image_name="i.png", denoise=0.6)
        assert wf["6"]["inputs"]["denoise"] == 0.6


class TestIPAdapterWorkflow:
    def test_structure(self):
        wf = ipadapter_reference_workflow(
            checkpoint="m.safetensors",
            prompt="test",
            negative_prompt="bad",
            uploaded_reference_name="ref.png",
        )
        assert wf["6"]["class_type"] == "CLIPVisionLoader"
        assert wf["7"]["class_type"] == "IPAdapterModelLoader"
        assert wf["8"]["class_type"] == "IPAdapterAdvanced"

    def test_custom_models(self):
        wf = ipadapter_reference_workflow(
            checkpoint="m", prompt="p", negative_prompt="n", uploaded_reference_name="r.png",
            ipadapter_model="custom_ip.safetensors", clip_vision_model="custom_clip.safetensors",
        )
        assert wf["6"]["inputs"]["clip_name"] == "custom_clip.safetensors"
        assert wf["7"]["inputs"]["ipadapter_file"] == "custom_ip.safetensors"

    def test_weight(self):
        wf = ipadapter_reference_workflow(
            checkpoint="m", prompt="p", negative_prompt="n", uploaded_reference_name="r.png", weight=0.5,
        )
        assert wf["8"]["inputs"]["weight"] == 0.5


class TestControlNetWorkflow:
    def test_structure(self):
        wf = controlnet_pose_workflow(
            checkpoint="m.safetensors",
            prompt="test",
            negative_prompt="bad",
            uploaded_pose_name="pose.png",
        )
        assert wf["6"]["class_type"] == "ControlNetLoader"
        assert wf["7"]["class_type"] == "ControlNetApplyAdvanced"

    def test_strength(self):
        wf = controlnet_pose_workflow(
            checkpoint="m", prompt="p", negative_prompt="n", uploaded_pose_name="p.png", strength=0.9,
        )
        assert wf["7"]["inputs"]["strength"] == 0.9

    def test_custom_model(self):
        wf = controlnet_pose_workflow(
            checkpoint="m", prompt="p", negative_prompt="n", uploaded_pose_name="p.png",
            controlnet_model="my_control.safetensors",
        )
        assert wf["6"]["inputs"]["control_net_name"] == "my_control.safetensors"


class TestApplyLoras:
    def test_empty_loras_returns_same(self):
        wf = text_to_image_workflow(checkpoint="m", prompt="p", negative_prompt="n")
        original = dict(wf)
        result = apply_loras(wf, [])
        assert result == original

    def test_injects_lora_loader(self):
        wf = text_to_image_workflow(checkpoint="m", prompt="p", negative_prompt="n")
        result = apply_loras(wf, [("style.safetensors", 0.75)])
        lora_nodes = [n for n in result.values() if isinstance(n, dict) and n.get("class_type") == "LoraLoader"]
        assert len(lora_nodes) == 1

    def test_rewires_model_input(self):
        wf = text_to_image_workflow(checkpoint="m", prompt="p", negative_prompt="n")
        result = apply_loras(wf, [("style.safetensors", 0.75)])
        ksampler = result["5"]
        # model input should point to lora node, not "1"
        assert ksampler["inputs"]["model"][0] != "1"
        assert ksampler["inputs"]["model"] != ["1", 0]

    def test_multiple_loras(self):
        wf = text_to_image_workflow(checkpoint="m", prompt="p", negative_prompt="n")
        result = apply_loras(wf, [("lora1.safetensors", 0.5), ("lora2.safetensors", 0.8)])
        lora_nodes = [n for n in result.values() if isinstance(n, dict) and n.get("class_type") == "LoraLoader"]
        assert len(lora_nodes) == 2

    def test_does_not_modify_original(self):
        wf = text_to_image_workflow(checkpoint="m", prompt="p", negative_prompt="n")
        original_keys = set(wf.keys())
        apply_loras(wf, [("style.safetensors", 0.75)])
        assert set(wf.keys()) == original_keys


class TestWorkflowRequiredClasses:
    def test_returns_class_types(self):
        wf = text_to_image_workflow(checkpoint="m", prompt="p", negative_prompt="n")
        classes = workflow_required_classes(wf)
        assert "CheckpointLoaderSimple" in classes
        assert "CLIPTextEncode" in classes
        assert "KSampler" in classes
        assert "VAEDecode" in classes
        assert "SaveImage" in classes
