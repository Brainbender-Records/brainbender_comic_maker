from __future__ import annotations

from pathlib import Path

from brainbender.core.page_layout import PageLayoutStore, LetteringData, PanelData


class TestPageLayoutStore:
    def test_default_page(self, tmp_home: Path):
        store = PageLayoutStore()
        page = store.default_page("My Page")
        assert page.title == "My Page"
        assert page.width == 1200
        assert page.height == 1800
        assert page.panels == []
        assert page.lettering == []

    def test_save_and_load(self, tmp_home: Path):
        store = PageLayoutStore()
        page = store.default_page("Save Test")
        saved = store.save(page)
        assert saved.exists()
        loaded = store.load(saved)
        assert loaded.title == "Save Test"
        assert loaded.width == 1200

    def test_save_with_custom_filename(self, tmp_home: Path):
        store = PageLayoutStore()
        page = store.default_page("Custom File")
        path = store.save(page, "my_custom.json")
        assert path.name == "my_custom.json"

    def test_list_pages(self, tmp_home: Path):
        store = PageLayoutStore()
        assert store.list_pages() == []
        store.save(store.default_page("A"))
        store.save(store.default_page("B"))
        assert len(store.list_pages()) == 2

    def test_make_panel(self, tmp_home: Path):
        store = PageLayoutStore()
        panel = store.make_panel(70, 70, 500, 400)
        assert isinstance(panel, PanelData)
        assert panel.x == 70
        assert panel.y == 70
        assert panel.w == 500
        assert panel.h == 400
        assert panel.image_path == ""

    def test_make_panel_with_image(self, tmp_home: Path):
        store = PageLayoutStore()
        panel = store.make_panel(0, 0, 100, 100, "/path/img.png")
        assert panel.image_path == "/path/img.png"

    def test_make_lettering_speech(self, tmp_home: Path):
        store = PageLayoutStore()
        l = store.make_lettering("speech", "Hello!", 100, 200)
        assert l.kind == "speech"
        assert l.text == "Hello!"
        assert l.bubble is True
        assert l.w == 320

    def test_make_lettering_sfx(self, tmp_home: Path):
        store = PageLayoutStore()
        l = store.make_lettering("sfx", "BOOM!", 100, 200)
        assert l.kind == "sfx"
        assert l.bubble is False
        assert l.w == 420
        assert l.h == 130

    def test_make_lettering_caption(self, tmp_home: Path):
        store = PageLayoutStore()
        l = store.make_lettering("caption", "Later...", 100, 200, font_size=24)
        assert l.kind == "caption"
        assert l.bubble is True
        assert l.h == 90
        assert l.font_size == 24

    def test_template_3row(self, tmp_home: Path):
        store = PageLayoutStore()
        layout = store.template("3 Row Page")
        assert len(layout.panels) == 3

    def test_template_4panel(self, tmp_home: Path):
        store = PageLayoutStore()
        layout = store.template("4 Panel Grid")
        assert len(layout.panels) == 4

    def test_template_6panel(self, tmp_home: Path):
        store = PageLayoutStore()
        layout = store.template("6 Panel Grid")
        assert len(layout.panels) == 6

    def test_template_splash(self, tmp_home: Path):
        store = PageLayoutStore()
        layout = store.template("Splash + 2 Bottom")
        assert len(layout.panels) == 3

    def test_template_unknown_falls_back(self, tmp_home: Path):
        store = PageLayoutStore()
        layout = store.template("Nonexistent Template")
        assert len(layout.panels) == 1

    def test_template_dimensions(self, tmp_home: Path):
        store = PageLayoutStore()
        layout = store.template("4 Panel Grid", width=800, height=1200)
        assert layout.width == 800
        assert layout.height == 1200

    def test_safe_name(self, tmp_home: Path):
        store = PageLayoutStore()
        assert store._safe_name("My Comic Page!") == "my_comic_page_"

    def test_load_with_lettering(self, tmp_home: Path):
        store = PageLayoutStore()
        page = store.default_page("Letter Test")
        page.lettering.append(store.make_lettering("speech", "Hello", 10, 20))
        page.lettering.append(store.make_lettering("sfx", "Bang", 30, 40))
        path = store.save(page, "letter_test.json")
        loaded = store.load(path)
        assert len(loaded.lettering) == 2
        assert loaded.lettering[0].text == "Hello"
        assert loaded.lettering[1].kind == "sfx"
