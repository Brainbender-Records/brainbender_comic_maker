from __future__ import annotations

import uuid
from pathlib import Path

import pytest
from brainbender.continuity import CharacterProfile, ContinuityStore, LocationProfile
from brainbender.director.panel_director import PanelCell


@pytest.fixture
def tmp_home(tmp_path: Path) -> Path:
    base = tmp_path / ".local/share/brainbender-comic-maker"
    return base


@pytest.fixture(autouse=True)
def _patch_paths(monkeypatch: pytest.MonkeyPatch, tmp_home: Path):
    """Patch all module-level path constants that are evaluated at import time."""
    import brainbender.core.paths as paths_mod
    import brainbender.core.image_history as ih_mod
    import brainbender.core.page_layout as pl_mod
    import brainbender.continuity.consistency as cc_mod
    import brainbender.director.panel_director as pd_mod
    import brainbender.director.page_planner as pp_mod

    # Patch the APP_DIR reference in every module that uses it at the module level
    monkeypatch.setattr("brainbender.core.paths.APP_DIR", tmp_home)
    monkeypatch.setattr("brainbender.core.paths.PROJECTS_DIR", tmp_home / "projects")
    monkeypatch.setattr("brainbender.core.paths.HISTORY_DIR", tmp_home / "history")
    monkeypatch.setattr("brainbender.core.paths.SETTINGS_FILE", tmp_home / "settings.json")

    # Re-derive module-level constants that depend on APP_DIR
    monkeypatch.setattr(cc_mod, "CONTINUITY_DIR", tmp_home / "continuity")
    monkeypatch.setattr(cc_mod, "CHARACTER_FILE", tmp_home / "continuity" / "characters.json")
    monkeypatch.setattr(cc_mod, "LOCATION_FILE", tmp_home / "continuity" / "locations.json")
    monkeypatch.setattr(cc_mod, "REFERENCE_DIR", tmp_home / "continuity" / "references")

    monkeypatch.setattr(pd_mod, "DIRECTOR_DIR", tmp_home / "director")
    monkeypatch.setattr(pd_mod, "PANEL_FILE", tmp_home / "director" / "panel_cells.json")

    monkeypatch.setattr(pp_mod, "PLANNER_DIR", tmp_home / "director")
    monkeypatch.setattr(pp_mod, "PAGE_PLAN_FILE", tmp_home / "director" / "page_plans.json")

    # image_history imports HISTORY_DIR locally, so also patch its module attr
    monkeypatch.setattr(ih_mod, "HISTORY_DIR", tmp_home / "history")

    # Ensure dirs exist for the modules that mkdir in __init__
    for d in (tmp_home, tmp_home / "projects", tmp_home / "history",
              tmp_home / "continuity", tmp_home / "continuity" / "references",
              tmp_home / "director"):
        d.mkdir(parents=True, exist_ok=True)

    # Pre-write empty JSON arrays so ContinuityStore / ComicDirectorStore init doesn't do it
    for f in (cc_mod.CHARACTER_FILE, cc_mod.LOCATION_FILE, pd_mod.PANEL_FILE, pp_mod.PAGE_PLAN_FILE):
        if not f.exists():
            f.write_text("[]")


@pytest.fixture
def tmp_img(tmp_path: Path) -> Path:
    from PIL import Image
    img = tmp_path / "test.png"
    Image.new("RGB", (64, 64), color="red").save(img)
    return img


@pytest.fixture
def continuity_store(tmp_home: Path) -> ContinuityStore:
    return ContinuityStore()


@pytest.fixture
def sample_character(continuity_store: ContinuityStore) -> CharacterProfile:
    return continuity_store.new_character("Test Hero")


@pytest.fixture
def sample_location(continuity_store: ContinuityStore) -> LocationProfile:
    return continuity_store.new_location("Test City")


@pytest.fixture
def sample_panel() -> PanelCell:
    return PanelCell(
        id=str(uuid.uuid4()),
        page="Page 1",
        panel_number=1,
        user_prompt="A hero stands tall",
        camera="wide establishing shot",
        mood="dramatic",
        style="semi-realistic graphic novel style",
    )
