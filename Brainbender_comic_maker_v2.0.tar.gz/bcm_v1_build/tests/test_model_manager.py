from __future__ import annotations

from pathlib import Path

import pytest
from brainbender.comfy.model_manager import ModelManager, human_size, CURATED_MODELS, MODEL_EXTENSIONS


class TestHumanSize:
    def test_bytes(self):
        assert human_size(0) == "0 B"
        assert human_size(512) == "512 B"

    def test_kb(self):
        result = human_size(2048)
        assert "KB" in result

    def test_mb(self):
        result = human_size(2_097_152)
        assert "MB" in result

    def test_gb(self):
        result = human_size(2_147_483_648)
        assert "GB" in result


class TestCuratedModels:
    def test_has_entries(self):
        assert len(CURATED_MODELS) >= 7

    def test_all_have_required_keys(self):
        for model in CURATED_MODELS:
            assert "name" in model
            assert "filename" in model
            assert "url" in model
            assert "size_gb" in model
            assert "license" in model

    def test_all_urls_valid(self):
        for model in CURATED_MODELS:
            assert model["url"].startswith("https://")

    def test_sizes_positive(self):
        for model in CURATED_MODELS:
            assert model["size_gb"] > 0


class TestModelManager:
    def test_not_configured_when_empty(self, tmp_home: Path):
        mgr = ModelManager("")
        assert mgr.is_configured() is False

    def test_not_configured_bad_path(self, tmp_home: Path):
        mgr = ModelManager("/nonexistent")
        assert mgr.is_configured() is False

    def test_configured(self, tmp_path: Path):
        comfy = tmp_path / "ComfyUI"
        comfy.mkdir(parents=True)
        (comfy / "main.py").write_text("")
        mgr = ModelManager(str(comfy))
        assert mgr.is_configured() is True

    def test_scan_checkpoints_empty(self, tmp_path: Path):
        comfy = tmp_path / "ComfyUI"
        comfy.mkdir(parents=True)
        mgr = ModelManager(str(comfy))
        assert mgr.scan_checkpoints() == []

    def test_scan_checkpoints_finds_files(self, tmp_path: Path):
        comfy = tmp_path / "ComfyUI"
        models = comfy / "models" / "checkpoints"
        models.mkdir(parents=True)
        (models / "test.safetensors").write_text("fake")
        (models / "other.ckpt").write_text("fake")
        (models / "readme.txt").write_text("ignore")
        mgr = ModelManager(str(comfy))
        entries = mgr.scan_checkpoints()
        assert len(entries) == 2
        names = [e.name for e in entries]
        assert "test.safetensors" in names
        assert "other.ckpt" in names

    def test_scan_loras_empty(self, tmp_path: Path):
        comfy = tmp_path / "ComfyUI"
        comfy.mkdir(parents=True)
        mgr = ModelManager(str(comfy))
        assert mgr.scan_loras() == []

    def test_scan_loras_finds_files(self, tmp_path: Path):
        comfy = tmp_path / "ComfyUI"
        lora_dir = comfy / "models" / "loras"
        lora_dir.mkdir(parents=True)
        (lora_dir / "style.safetensors").write_text("fake")
        (lora_dir / "character.safetensors").write_text("fake")
        mgr = ModelManager(str(comfy))
        loras = mgr.scan_loras()
        assert len(loras) == 2

    def test_import_model(self, tmp_path: Path):
        src = tmp_path / "source.safetensors"
        src.write_text("fake model data")
        comfy = tmp_path / "ComfyUI"
        comfy.mkdir(parents=True)
        mgr = ModelManager(str(comfy))
        dest = mgr.import_model(str(src))
        assert dest.exists()
        assert dest.name == "source.safetensors"
        assert dest.parent.name == "checkpoints"

    def test_import_model_nonexistent_source(self, tmp_path: Path):
        mgr = ModelManager(str(tmp_path / "ComfyUI"))
        with pytest.raises(FileNotFoundError):
            mgr.import_model("/nonexistent.safetensors")

    def test_import_model_wrong_extension(self, tmp_path: Path):
        src = tmp_path / "test.txt"
        src.write_text("data")
        mgr = ModelManager(str(tmp_path / "ComfyUI"))
        with pytest.raises(ValueError, match="safetensors"):
            mgr.import_model(str(src))

    def test_ensure_checkpoint_dir_creates(self, tmp_path: Path):
        comfy = tmp_path / "ComfyUI"
        mgr = ModelManager(str(comfy))
        d = mgr.ensure_checkpoint_dir()
        assert d.exists()
        assert d.name == "checkpoints"

    def test_curated_list(self, tmp_path: Path):
        mgr = ModelManager(str(tmp_path))
        curated = mgr.curated_list()
        assert len(curated) == len(CURATED_MODELS)

    def test_download_presets_empty(self, tmp_path: Path):
        mgr = ModelManager(str(tmp_path))
        assert mgr.load_download_presets() == []

    def test_add_and_load_download_preset(self, tmp_path: Path):
        mgr = ModelManager(str(tmp_path))
        mgr.add_download_preset("My Model", "https://example.com/model.safetensors", "test notes")
        presets = mgr.load_download_presets()
        assert len(presets) == 1
        assert presets[0]["name"] == "My Model"
        assert presets[0]["url"] == "https://example.com/model.safetensors"
