from __future__ import annotations

from pathlib import Path

import pytest
from brainbender.core.image_history import ImageHistoryManager


class TestImageHistoryManager:
    def test_empty_on_start(self, tmp_home: Path):
        mgr = ImageHistoryManager()
        assert mgr.all_entries() == []

    def test_add_entry(self, tmp_home: Path, tmp_img: Path):
        mgr = ImageHistoryManager()
        entry = mgr.add_entry(tmp_img, prompt="a test", checkpoint="model.ckpt", mode="txt2img")
        assert entry["prompt"] == "a test"
        assert entry["checkpoint"] == "model.ckpt"
        assert entry["mode"] == "txt2img"
        assert "id" in entry
        assert Path(entry["path"]).exists()
        assert Path(entry["path"]).suffix == ".png"

    def test_add_entry_creates_thumbnail(self, tmp_home: Path, tmp_img: Path):
        mgr = ImageHistoryManager()
        entry = mgr.add_entry(tmp_img)
        assert entry["thumbnail"] != ""
        assert Path(entry["thumbnail"]).exists()

    def test_all_entries_order(self, tmp_home: Path, tmp_img: Path):
        mgr = ImageHistoryManager()
        mgr.add_entry(tmp_img, prompt="first")
        mgr.add_entry(tmp_img, prompt="second")
        entries = mgr.all_entries()
        assert len(entries) == 2
        assert entries[0]["prompt"] == "second"

    def test_get_entry(self, tmp_home: Path, tmp_img: Path):
        mgr = ImageHistoryManager()
        added = mgr.add_entry(tmp_img)
        fetched = mgr.get_entry(added["id"])
        assert fetched is not None
        assert fetched["id"] == added["id"]

    def test_get_entry_missing(self, tmp_home: Path):
        mgr = ImageHistoryManager()
        assert mgr.get_entry("nonexistent") is None

    def test_delete_entry(self, tmp_home: Path, tmp_img: Path):
        mgr = ImageHistoryManager()
        entry = mgr.add_entry(tmp_img)
        path = Path(entry["path"])
        thumb = Path(entry["thumbnail"])
        assert path.exists()
        assert mgr.delete_entry(entry["id"]) is True
        assert not path.exists()
        assert mgr.get_entry(entry["id"]) is None

    def test_delete_entry_missing(self, tmp_home: Path):
        mgr = ImageHistoryManager()
        assert mgr.delete_entry("nonexistent") is False

    def test_clear_all(self, tmp_home: Path, tmp_img: Path):
        mgr = ImageHistoryManager()
        mgr.add_entry(tmp_img)
        mgr.add_entry(tmp_img)
        assert len(mgr.all_entries()) == 2
        mgr.clear_all()
        assert mgr.all_entries() == []

    def test_persistence(self, tmp_home: Path, tmp_img: Path):
        mgr = ImageHistoryManager()
        mgr.add_entry(tmp_img, prompt="persist test")
        assert len(mgr.all_entries()) == 1

        mgr2 = ImageHistoryManager()
        assert len(mgr2.all_entries()) == 1
        assert mgr2.all_entries()[0]["prompt"] == "persist test"

    def test_add_entry_with_params(self, tmp_home: Path, tmp_img: Path):
        mgr = ImageHistoryManager()
        entry = mgr.add_entry(tmp_img, mode="img2img", params={"denoise": 0.55, "cfg": 7.0})
        assert entry["mode"] == "img2img"
        assert entry["params"]["denoise"] == 0.55

    def test_add_entry_with_negative_prompt(self, tmp_home: Path, tmp_img: Path):
        mgr = ImageHistoryManager()
        entry = mgr.add_entry(tmp_img, prompt="good", negative_prompt="bad")
        assert entry["negative_prompt"] == "bad"
