from __future__ import annotations

from pathlib import Path

from brainbender.director.panel_director import (
    ComicDirectorStore,
    DirectedPromptBuilder,
    PanelCell,
    CAMERA_PRESETS,
    MOOD_PRESETS,
    STYLE_PRESETS,
)
from brainbender.continuity import ContinuityStore, CharacterProfile, LocationProfile


class TestComicDirectorStore:
    def test_empty_on_start(self, tmp_home: Path):
        store = ComicDirectorStore()
        assert store.panels() == []

    def test_new_panel(self, tmp_home: Path):
        store = ComicDirectorStore()
        panel = store.new_panel("Page 1")
        assert panel.page == "Page 1"
        assert panel.panel_number == 1
        assert panel.id is not None
        assert panel.character_ids == []

    def test_new_panel_auto_numbers(self, tmp_home: Path):
        store = ComicDirectorStore()
        p1 = store.new_panel("Page 1")
        store.upsert_panel(p1)
        p2 = store.new_panel("Page 1")
        assert p1.panel_number == 1
        assert p2.panel_number == 2

    def test_upsert_and_list(self, tmp_home: Path):
        store = ComicDirectorStore()
        panel = store.new_panel("Page 1")
        store.upsert_panel(panel)
        panels = store.panels()
        assert len(panels) == 1
        assert panels[0].id == panel.id

    def test_upsert_replaces(self, tmp_home: Path):
        store = ComicDirectorStore()
        panel = store.new_panel("Page 1")
        store.upsert_panel(panel)
        panel.user_prompt = "Updated prompt"
        store.upsert_panel(panel)
        panels = store.panels()
        assert len(panels) == 1
        assert panels[0].user_prompt == "Updated prompt"

    def test_delete_panel(self, tmp_home: Path):
        store = ComicDirectorStore()
        panel = store.new_panel("Page 1")
        store.upsert_panel(panel)
        store.delete_panel(panel.id)
        assert store.panels() == []

    def test_panel_preserves_all_fields(self, tmp_home: Path):
        store = ComicDirectorStore()
        panel = store.new_panel("Page 2")
        panel.user_prompt = "Action scene"
        panel.camera = "action shot"
        panel.mood = "tense"
        panel.style = "manga-inspired comic style"
        panel.dialogue = "Look out!"
        panel.director_notes = "Explosion in background"
        panel.locked_character_continuity = True
        store.upsert_panel(panel)

        loaded = store.panels()[0]
        assert loaded.user_prompt == "Action scene"
        assert loaded.camera == "action shot"
        assert loaded.mood == "tense"
        assert loaded.style == "manga-inspired comic style"
        assert loaded.dialogue == "Look out!"


class TestPanelPresets:
    def test_camera_presets(self):
        assert len(CAMERA_PRESETS) >= 7
        assert "medium shot" in CAMERA_PRESETS

    def test_mood_presets(self):
        assert len(MOOD_PRESETS) >= 7
        assert "dramatic" in MOOD_PRESETS

    def test_style_presets(self):
        assert len(STYLE_PRESETS) >= 5
        assert "semi-realistic graphic novel style" in STYLE_PRESETS


class TestDirectedPromptBuilder:
    def test_build_minimal_panel(self, tmp_home: Path, sample_panel: PanelCell):
        store = ContinuityStore()
        builder = DirectedPromptBuilder(store)
        prompt = builder.build(sample_panel)
        assert "comic book panel" in prompt
        assert "A hero stands tall" in prompt
        assert "wide establishing shot" in prompt

    def test_build_with_character(self, tmp_home: Path, sample_panel: PanelCell, sample_character: CharacterProfile):
        store = ContinuityStore()
        store.upsert_character(sample_character)
        builder = DirectedPromptBuilder(store)
        sample_panel.character_ids = [sample_character.id]
        prompt = builder.build(sample_panel)
        assert "Test Hero" in prompt

    def test_build_with_location(self, tmp_home: Path, sample_panel: PanelCell, sample_location: LocationProfile):
        store = ContinuityStore()
        store.upsert_location(sample_location)
        builder = DirectedPromptBuilder(store)
        sample_panel.location_id = sample_location.id
        sample_panel.locked_location_continuity = True
        prompt = builder.build(sample_panel)
        assert "Test City" in prompt

    def test_build_with_dialogue(self, tmp_home: Path, sample_panel: PanelCell):
        store = ContinuityStore()
        builder = DirectedPromptBuilder(store)
        sample_panel.dialogue = "Hello world"
        prompt = builder.build(sample_panel)
        assert "Hello world" in prompt
        assert "clean space for dialogue" in prompt

    def test_build_with_director_notes(self, tmp_home: Path, sample_panel: PanelCell):
        store = ContinuityStore()
        builder = DirectedPromptBuilder(store)
        sample_panel.director_notes = "Explosion in background"
        prompt = builder.build(sample_panel)
        assert "Explosion in background" in prompt

    def test_build_with_previous_reference(self, tmp_home: Path, sample_panel: PanelCell):
        store = ContinuityStore()
        builder = DirectedPromptBuilder(store)
        sample_panel.use_previous_panel_reference = True
        sample_panel.previous_panel_strength = 0.5
        prompt = builder.build(sample_panel)
        assert "use previous panel as continuity reference" in prompt
        assert "0.50" in prompt

    def test_build_without_character_when_locked_false(self, tmp_home: Path, sample_panel: PanelCell, sample_character: CharacterProfile):
        store = ContinuityStore()
        store.upsert_character(sample_character)
        builder = DirectedPromptBuilder(store)
        sample_panel.character_ids = [sample_character.id]
        sample_panel.locked_character_continuity = False
        prompt = builder.build(sample_panel)
        assert "Test Hero" not in prompt
