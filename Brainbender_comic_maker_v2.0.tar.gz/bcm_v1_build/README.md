# Brainbender Comic Maker v2.0

Open and free AI comic-making frontend. Uses ComfyUI as the image generation backend.

## Quick start (NVIDIA GPU)

### 1. Install ComfyUI with CUDA

```bash
git clone https://github.com/comfyanonymous/ComfyUI ~/ComfyUI
cd ~/ComfyUI
pip install --break-system-packages torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu124
pip install --break-system-packages -r requirements.txt
```

### 2. Download a model

```bash
cd ~/ComfyUI/models/checkpoints
wget https://huggingface.co/Lykon/DreamShaper/resolve/main/DreamShaper_8_pruned.safetensors
```

Any `.safetensors` or `.ckpt` SD1.5/SDXL checkpoint works.

### 3. Install Brainbender Comic Maker

```bash
pip install --break-system-packages -e .
```

### 4. Launch ComfyUI

```bash
cd ~/ComfyUI && python main.py &
```

### 5. Launch the app

```bash
./start.sh
```

On first launch, use the **Setup Wizard** to point the app to `~/ComfyUI`.

## Main workflow

1. Create reusable **Characters** and **Locations** in the Library tab
2. Open **AI Comic Director** — create a page plan
3. Enter a prompt for each cell, assign characters/locations
4. **Generate** each cell or **Batch Generate** the page
5. **Assemble** the page with drag & drop panels
6. Add lettering (speech bubbles, captions, SFX)
7. Export as PDF or CBZ

## Build AppImage

```bash
./packaging/appimage/build_appimage.sh
```

Output: `dist/BrainbenderComicMaker-x86_64.AppImage`

## Features

- AI Comic Director with page planning
- Text-to-image, Image+Text Reference, Character Reference (IPAdapter), Pose ControlNet generation modes
- LoRA support
- Visual page layout editor with drag & drop
- Lettering tools (bubbles, captions, SFX)
- PDF and CBZ export
- Image history browser
- Model manager
- ComfyUI installer/updater

## Requirements

- Python 3.10+
- NVIDIA GPU with CUDA-capable drivers
- ComfyUI (installed separately or via Setup Wizard)
