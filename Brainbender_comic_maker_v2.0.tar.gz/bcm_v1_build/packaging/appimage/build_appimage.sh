#!/usr/bin/env bash
# Build a Brainbender Comic Maker AppImage using linuxdeploy or appimagetool.
# Usage: ./build_appimage.sh [--ci] [--plugin-qt]
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
APPDIR="$ROOT/build/AppDir"
DIST="$ROOT/dist"
CI_MODE=false
PLUGIN_QT=false
for arg in "$@"; do
  case "$arg" in --ci) CI_MODE=true ;; --plugin-qt) PLUGIN_QT=true ;; esac
done

# --- Clean ---
rm -rf "$APPDIR" "$DIST"
mkdir -p "$APPDIR/usr/bin" "$DIST"

# --- Python venv with the app installed ---
echo "==> Creating Python virtual environment and installing app..."
python3 -m venv "$APPDIR/venv-build"
source "$APPDIR/venv-build/bin/activate"
pip install --upgrade pip --quiet
pip install "$ROOT" --quiet
PY_VER=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
SITE=$(python3 -c 'import site; print(site.getsitepackages()[0])')
deactivate

# --- Bundle Python and site-packages ---
echo "==> Bundling Python $PY_VER and site-packages..."
cp -a "$APPDIR/venv-build/bin/python3" "$APPDIR/usr/bin/python3"
LIB_DIR="$APPDIR/usr/lib/python$PY_VER"
mkdir -p "$LIB_DIR"
cp -a "$SITE" "$LIB_DIR/site-packages"

# --- Install system PySide6 libraries via linuxdeploy-plugin-qt if available ---
if $PLUGIN_QT && command -v linuxdeploy >/dev/null 2>&1; then
  echo "==> linuxdeploy-plugin-qt will bundle Qt/PySide6 libraries in the next step."
fi

# --- Copy AppDir metadata ---
echo "==> Copying AppDir metadata..."
cp "$ROOT/packaging/appimage/AppRun" "$APPDIR/AppRun"
cp "$ROOT/packaging/appimage/brainbender-comic-maker.desktop" "$APPDIR/brainbender-comic-maker.desktop"
cp "$ROOT/assets/brainbender-comic-maker.png" "$APPDIR/brainbender-comic-maker.png"
chmod +x "$APPDIR/AppRun"

# --- Remove build venv ---
rm -rf "$APPDIR/venv-build"

# --- Try linuxdeploy first ---
if command -v linuxdeploy >/dev/null 2>&1; then
  echo "==> Using linuxdeploy to build AppImage..."
  LDD_ARGS=("--appdir" "$APPDIR" "--output" "appimage" "--desktop-file" "$APPDIR/brainbender-comic-maker.desktop" "--icon-file" "$APPDIR/brainbender-comic-maker.png")
  if $PLUGIN_QT && command -v linuxdeploy-plugin-qt >/dev/null 2>&1; then
    export LDAI_OUTPUT="$DIST/BrainbenderComicMaker-x86_64.AppImage"
    linuxdeploy "${LDD_ARGS[@]}" --plugin qt
  else
    export LDAI_OUTPUT="$DIST/BrainbenderComicMaker-x86_64.AppImage"
    linuxdeploy "${LDD_ARGS[@]}"
  fi
  echo "==> Built: $DIST/BrainbenderComicMaker-x86_64.AppImage"
  exit 0
fi

# --- Fall back to appimagetool ---
echo "==> linuxdeploy not found; falling back to appimagetool..."
APPIMAGETOOL=""
if command -v appimagetool >/dev/null 2>&1; then
  APPIMAGETOOL="appimagetool"
elif $CI_MODE; then
  echo "==> Downloading appimagetool..."
  mkdir -p "$DIST/tools"
  APPIMAGETOOL="$DIST/tools/appimagetool"
  if [ ! -f "$APPIMAGETOOL" ]; then
    wget -qO "$APPIMAGETOOL" "https://github.com/AppImage/AppImageKit/releases/download/continuous/appimagetool-x86_64.AppImage"
    chmod +x "$APPIMAGETOOL"
  fi
else
  echo "==> appimagetool not found. Install it from:"
  echo "    https://github.com/AppImage/AppImageKit/releases"
  echo "    Then chmod +x and add to PATH."
  echo "==> AppDir prepared at: $APPDIR"
  echo "==> To build manually: appimagetool $APPDIR $DIST/BrainbenderComicMaker-x86_64.AppImage"
  exit 0
fi

echo "==> Building AppImage with appimagetool..."
"$APPIMAGETOOL" "$APPDIR" "$DIST/BrainbenderComicMaker-x86_64.AppImage"
echo "==> Built: $DIST/BrainbenderComicMaker-x86_64.AppImage"
