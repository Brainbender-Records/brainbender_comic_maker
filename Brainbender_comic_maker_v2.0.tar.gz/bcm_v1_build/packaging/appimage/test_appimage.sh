#!/usr/bin/env bash
# Test that the Brainbender Comic Maker AppImage is valid.
# Usage: ./test_appimage.sh [path-to-AppImage]
set -euo pipefail

APPIMAGE="${1:-$ROOT/dist/BrainbenderComicMaker-x86_64.AppImage}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
if [ "$APPIMAGE" = "$ROOT/dist/BrainbenderComicMaker-x86_64.AppImage" ]; then
  APPIMAGE="$ROOT/dist/BrainbenderComicMaker-x86_64.AppImage"
fi

echo "==> Testing AppImage: $APPIMAGE"
FAILED=0

# Test 1: File exists and is executable
if [ -f "$APPIMAGE" ]; then
  echo "  [PASS] AppImage file exists"
else
  echo "  [FAIL] AppImage file not found at $APPIMAGE"
  FAILED=1
fi

if [ -x "$APPIMAGE" ]; then
  echo "  [PASS] AppImage is executable"
else
  echo "  [FAIL] AppImage is not executable"
  FAILED=1
fi

# Test 2: File size is reasonable (> 10 MB means it has bundled Python + deps)
SIZE=$(stat -c%s "$APPIMAGE" 2>/dev/null || stat -f%z "$APPIMAGE" 2>/dev/null || echo 0)
if [ "$SIZE" -gt 10000000 ]; then
  echo "  [PASS] AppImage size is reasonable ($(echo "scale=1; $SIZE/1024/1024" | bc) MB)"
else
  echo "  [WARN] AppImage size seems small ($SIZE bytes); may be missing Python or Qt libraries"
fi

# Test 3: Extract and verify structure
EXTRACT_DIR=$(mktemp -d)
echo "==> Extracting AppImage to $EXTRACT_DIR for inspection..."
if "$APPIMAGE" --appimage-extract >/dev/null 2>&1; then
  EXTRACTED="$EXTRACT_DIR/squashfs-root"
  mv squashfs-root "$EXTRACTED" 2>/dev/null || true
  EXTRACTED=$(find "$EXTRACT_DIR" -maxdepth 1 -type d -name "squashfs-root" 2>/dev/null | head -1)
fi

# If --appimage-extract didn't work inside the workdir, try in the temp dir
if [ ! -d "$EXTRACT_DIR/squashfs-root" ]; then
  cd "$EXTRACT_DIR"
  "$APPIMAGE" --appimage-extract >/dev/null 2>&1 || true
  cd "$ROOT"
fi

EXTRACTED=""
for d in "$EXTRACT_DIR"/squashfs-root "$EXTRACT_DIR"/AppDir; do
  if [ -d "$d" ]; then
    EXTRACTED="$d"
    break
  fi
done

if [ -z "$EXTRACTED" ] || [ ! -d "$EXTRACTED" ]; then
  echo "  [WARN] Could not extract AppImage (may need FUSE). Skipping structure checks."
  rm -rf "$EXTRACT_DIR"
  # Exit with partial pass
  [ "$FAILED" -eq 0 ] && echo "==> All basic checks passed." || echo "==> Some checks FAILED."
  exit $FAILED
fi

echo "==> Inspecting extracted AppDir structure..."

# Test 4: Required files exist
REQUIRED_FILES=(
  "AppRun"
  "brainbender-comic-maker.desktop"
  "brainbender-comic-maker.png"
  "usr/bin/python3"
)
for f in "${REQUIRED_FILES[@]}"; do
  if [ -f "$EXTRACTED/$f" ]; then
    echo "  [PASS] $f found"
  else
    echo "  [FAIL] $f missing"
    FAILED=1
  fi
done

# Test 5: Python site-packages exist
SP_COUNT=$(find "$EXTRACTED/usr/lib" -path "*/site-packages/brainbender" -type d 2>/dev/null | wc -l)
if [ "$SP_COUNT" -ge 1 ]; then
  echo "  [PASS] brainbender package found in site-packages"
else
  echo "  [FAIL] brainbender package not found in site-packages"
  FAILED=1
fi

# Test 6: PySide6 is bundled
if [ -d "$(find "$EXTRACTED/usr/lib" -path "*/site-packages/PySide6" -type d 2>/dev/null | head -1)" ]; then
  echo "  [PASS] PySide6 found"
else
  echo "  [WARN] PySide6 not found (it may be bundled by linuxdeploy-plugin-qt instead)"
fi

# Test 7: Desktop file is valid
DESKTOP="$EXTRACTED/brainbender-comic-maker.desktop"
if grep -q "^Name=" "$DESKTOP" && grep -q "^Exec=" "$DESKTOP" && grep -q "^Icon=" "$DESKTOP"; then
  echo "  [PASS] Desktop file has required fields"
else
  echo "  [FAIL] Desktop file is missing required fields"
  FAILED=1
fi

# Test 8: AppRun references brainbender.app
if grep -q "brainbender.app" "$EXTRACTED/AppRun"; then
  echo "  [PASS] AppRun references brainbender.app module"
else
  echo "  [FAIL] AppRun does not reference brainbender.app"
  FAILED=1
fi

# Cleanup
rm -rf "$EXTRACT_DIR"

echo ""
if [ "$FAILED" -eq 0 ]; then
  echo "==> All checks PASSED! AppImage is valid."
else
  echo "==> Some checks FAILED."
fi
exit $FAILED
