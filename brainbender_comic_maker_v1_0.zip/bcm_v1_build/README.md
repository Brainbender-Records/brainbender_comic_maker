# Brainbender Comic Maker v1.0

Open and free AI comic-making frontend for Ubuntu, designed to work with ComfyUI.

This v1.0 package consolidates the current project into one runnable development build. It is AppImage-ready, but the easiest way to run it right now on Ubuntu is with the included install script.

## What is included

- AI Comic Director tab
- Per-cell / per-panel prompt entry
- Reusable Characters with reference/continuity notes
- Reusable Locations with reference/continuity notes
- Page Planner for 3, 4, and 6-cell pages
- Batch generation workflow for planned pages
- Page Assembly workflow
- Visual page layout editor
- Speech bubbles, captions, and SFX lettering tools
- PDF and CBZ book export
- ComfyUI setup wizard
- ComfyUI installer/update helper
- Model manager for `.safetensors`, `.ckpt`, and `.pt` files
- Workflow preset manager
- AppImage build folder and scripts

## Run on Ubuntu

From the folder where you extracted this project:

```bash
./install_ubuntu_dev.sh
./start.sh
```

The installer creates a local Python virtual environment in `.venv` and installs the app there.

## ComfyUI setup

Brainbender Comic Maker is the comic frontend. ComfyUI is the image generation backend.

On first launch, use the Setup Wizard to either locate ComfyUI or install/update it into `~/ComfyUI`.

You will also need at least one Stable Diffusion checkpoint model in:

```text
ComfyUI/models/checkpoints/
```

Use the built-in Model Manager to import a local `.safetensors` or `.ckpt` model file.

## Main workflow

1. Create reusable Characters.
2. Create reusable Locations.
3. Open the AI Comic Director.
4. Create a page plan.
5. Enter a custom prompt for each comic cell.
6. Select the characters and location for each cell.
7. Generate each cell or batch-generate the page.
8. Assemble the page.
9. Add lettering.
10. Export pages, PDF, or CBZ.

## Build AppImage/AppDir

```bash
./packaging/appimage/build_appimage.sh
```

If `appimagetool` is installed, this creates:

```text
dist/BrainbenderComicMaker-x86_64.AppImage
```

If `appimagetool` is not installed, it still prepares an AppDir at:

```text
build/AppDir
```

## Status

This is a v1.0 local runnable development build. It is not yet a polished public release. The project is designed to be developed further into a one-click AppImage release.
