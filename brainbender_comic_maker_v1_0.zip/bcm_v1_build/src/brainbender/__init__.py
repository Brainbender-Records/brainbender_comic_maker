__app_name__ = 'Brainbender Comic Maker'
__version__ = '1.0.0'
