# Brainbender Comic Maker - Phase 2

Open and free Linux desktop frontend for comic-focused Stable Diffusion workflows using ComfyUI.

## Phase 2 additions

Phase 2 builds on Phase 1 and adds comic-production library tools:

- Character profiles
  - Name, role, appearance, outfit/costume notes
  - Acting/personality notes
  - Prompt phrase for consistent generation
  - Reference image storage
- Prompt template library
  - Built-in templates for establishing shots, close-ups, action panels, dialogue panels, and character sheets
  - Custom templates with placeholders like `{character}`, `{scene}`, and `{style}`
- Style / LoRA preset library
  - Save style prompt add-ons
  - Save negative prompt add-ons
  - Track LoRA/model notes for future ComfyUI workflow integration
- Comic project metadata
  - Title, genre, visual style bible, synopsis, and notes
- Generate tab integration
  - Pick a saved character
  - Pick a prompt template
  - Pick a style preset
  - Send saved character/style context into the generation prompt

## Start on Ubuntu

```bash
cd ~/Downloads
unzip brainbender_comic_maker_phase2.zip -d brainbender_comic_maker_phase2
cd brainbender_comic_maker_phase2
./install_ubuntu.sh
./start.sh
```

## ComfyUI

The app expects ComfyUI at:

```text
http://127.0.0.1:8188
```

Set your ComfyUI folder in **Settings / Models**. The app can try to auto-start ComfyUI if the path is configured.

## Data location

User data is saved under:

```text
~/.brainbender-comic-maker/
```

Important folders:

```text
~/.brainbender-comic-maker/library/characters/
~/.brainbender-comic-maker/library/references/
~/.brainbender-comic-maker/library/templates/
~/.brainbender-comic-maker/library/presets/
~/.brainbender-comic-maker/library/projects/
~/.brainbender-comic-maker/outputs/
```

## Notes

Phase 2 focuses on reusable comic creation data. The next phase should add deeper comic project structure: chapters, pages, panel organization, and autosaved panel metadata linked to projects.
