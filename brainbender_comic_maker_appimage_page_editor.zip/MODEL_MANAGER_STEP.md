# Model Manager Step

This update adds a safer model-management workflow for Brainbender Comic Maker.

## What changed

- Added a **Model Manager** window in Settings.
- Scans `ComfyUI/models/checkpoints` for `.safetensors`, `.ckpt`, and `.pt` files.
- Imports local checkpoint files into the correct ComfyUI folder.
- Creates the checkpoint folder automatically if missing.
- Adds an optional URL downloader for direct model links.
- Adds saved download entries so users can keep model links/notes.

## Important model note

The app does **not** bundle Stable Diffusion models. Models are large and can have separate licenses. Some model sites require account login, license acceptance, or access tokens. For those, download the model manually in your browser, then use:

`Settings → Open Model Manager → Import Local Model`

## Suggested next development step

Add a **workflow preset manager** for comic styles:

- SD 1.5 text-to-image workflow
- SDXL text-to-image workflow
- image-to-image workflow
- comic panel preset
- character reference preset
- future ControlNet/IPAdapter preset placeholders
