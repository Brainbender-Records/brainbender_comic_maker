# Next Step Implemented: First-Run Setup Wizard

This build adds a non-technical first-run flow for connecting Brainbender Comic Maker to ComfyUI.

## Added

- First-run setup wizard
- Auto-detect common ComfyUI folder locations
- Validate that the chosen folder contains `main.py`
- Create/check `ComfyUI/models/checkpoints/`
- Copy local `.safetensors`, `.ckpt`, or `.pt` checkpoint files into ComfyUI
- Start ComfyUI from the wizard
- Settings tab buttons for opening the wizard later
- Better ComfyUI launcher validation and status messages

## Next recommended step

Add a built-in ComfyUI installer helper that can clone ComfyUI from GitHub and create its Python venv automatically. That will make the app closer to one-click for brand new users.
