# Brainbender Comic Maker — Next Steps

## Completed in this update

1. Replaced placeholder-only generation with real ComfyUI API wiring.
2. Added text-to-image workflow creation.
3. Added image-to-image workflow creation using ComfyUI `/upload/image`.
4. Added ComfyUI queue/history polling and output image download.
5. Added UI controls for width, height, steps, CFG, seed, and img2img denoise strength.
6. Added model import into `ComfyUI/models/checkpoints`.
7. Kept the placeholder button for testing the app without a GPU/model.

## What to test next on Ubuntu

1. Install and start ComfyUI normally once.
2. Put a checkpoint in `ComfyUI/models/checkpoints/` or use the app's **Import Checkpoint Model File** button.
3. Run Brainbender Comic Maker.
4. Go to **Settings** and choose the ComfyUI folder.
5. Click **Start / Check ComfyUI**.
6. Go to **Studio**, choose a checkpoint, type a prompt, and click **Generate Panel with ComfyUI**.
7. Try **Image + Text Reference** with a local PNG/JPG reference.

## Next engineering tasks

1. Add a ComfyUI installer/downloader helper for non-technical users.
2. Add a model download manager with curated open-license model URLs.
3. Add LoRA selection and automatic prompt tags.
4. Add generated-image history browser with thumbnails.
5. Add project page thumbnails and drag/drop from history into comic pages.
6. Add a real AppImage build test on Ubuntu using `linuxdeploy`.
