#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
APPDIR="$ROOT/build/AppDir"
DIST="$ROOT/dist"
rm -rf "$APPDIR" "$DIST"
mkdir -p "$APPDIR/usr/bin" "$APPDIR/usr/lib" "$DIST"
python3 -m venv "$APPDIR/venv-build"
source "$APPDIR/venv-build/bin/activate"
pip install --upgrade pip
pip install "$ROOT"
cp -a "$APPDIR/venv-build/bin/python3" "$APPDIR/usr/bin/python3"
SITE=$(python - <<'PY'
import site; print(site.getsitepackages()[0])
PY
)
mkdir -p "$APPDIR/usr/lib/$(basename $(dirname $SITE))"
cp -a "$SITE" "$APPDIR/usr/lib/$(basename $(dirname $SITE))/site-packages"
cp "$ROOT/packaging/appimage/AppRun" "$APPDIR/AppRun"
cp "$ROOT/packaging/appimage/brainbender-comic-maker.desktop" "$APPDIR/brainbender-comic-maker.desktop"
cp "$ROOT/assets/brainbender-comic-maker.png" "$APPDIR/brainbender-comic-maker.png"
chmod +x "$APPDIR/AppRun"
if ! command -v appimagetool >/dev/null 2>&1; then
  echo "appimagetool not found. Download it from AppImage/AppImageKit releases, chmod +x it, and put it in PATH."
  echo "AppDir prepared at: $APPDIR"
  exit 0
fi
appimagetool "$APPDIR" "$DIST/BrainbenderComicMaker-x86_64.AppImage"
echo "Built: $DIST/BrainbenderComicMaker-x86_64.AppImage"
