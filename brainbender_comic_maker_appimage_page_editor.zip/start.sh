#!/usr/bin/env bash
set -e
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"
if [ ! -d .venv ]; then
  echo "Virtual environment missing. Run ./install_ubuntu_dev.sh first."
  exit 1
fi
source .venv/bin/activate
brainbender-comic-maker
