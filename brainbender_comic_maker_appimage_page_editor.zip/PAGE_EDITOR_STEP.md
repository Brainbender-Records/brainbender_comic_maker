# Page Editor Step

This upgrade adds a visual comic page layout editor to Brainbender Comic Maker.

## Added

- Page templates:
  - Single splash page
  - Three-row page
  - Six-panel grid
  - Splash panel with two bottom panels
- Movable/selectable panels using Qt Graphics View.
- Assign generated images or local image files to panels.
- Save and load page layouts as JSON.
- Export a page mockup as PNG.

## How to use

1. Generate or create placeholder panels in the Studio tab.
2. Open **Comic Projects**.
3. Click **Open Page Layout Editor**.
4. Pick a template or add panels manually.
5. Select a panel, pick an image, and click **Assign Image to Selected Panel**.
6. Save the layout or export a PNG.

## Next recommended step

Improve lettering tools inside the page editor:

- Speech bubbles
- Captions
- Sound effects
- Font controls
- Bubble tails
- Per-panel dialogue notes
