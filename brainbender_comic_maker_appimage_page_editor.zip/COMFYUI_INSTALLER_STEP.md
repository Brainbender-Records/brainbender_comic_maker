# ComfyUI Installer Helper Step

This build adds a guided ComfyUI installer/updater for Ubuntu users.

## What it does

- Installs or updates ComfyUI into `~/ComfyUI` by default.
- Creates a ComfyUI Python virtual environment at `~/ComfyUI/venv`.
- Installs ComfyUI requirements.
- Creates `models/checkpoints/` if needed.
- Saves the ComfyUI path into Brainbender Comic Maker settings.
- Updates the launcher to prefer ComfyUI's own `venv/bin/python` when starting the server.

## What it does not do yet

- It does not bundle Stable Diffusion models inside the app.
- It does not automatically download large model files yet.
- It does not install CUDA/NVIDIA drivers.

## Recommended next step

Add a model download manager with a curated list of open-license checkpoints and clear disk-space warnings.
