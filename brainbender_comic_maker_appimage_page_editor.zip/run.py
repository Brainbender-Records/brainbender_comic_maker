#!/usr/bin/env python3
from brainbender.app import main

if __name__ == '__main__':
    main()
