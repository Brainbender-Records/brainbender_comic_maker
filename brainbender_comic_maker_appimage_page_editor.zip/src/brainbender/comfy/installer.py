from __future__ import annotations

import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional


LogFn = Callable[[str], None]


@dataclass
class InstallResult:
    ok: bool
    path: str
    message: str


class ComfyInstaller:
    """Guided ComfyUI installer/updater for local Ubuntu-style installs.

    It intentionally keeps Stable Diffusion model files separate from the app/AppImage.
    """

    REPO_URL = "https://github.com/comfyanonymous/ComfyUI.git"

    def __init__(self, install_dir: str | Path | None = None, log: Optional[LogFn] = None):
        self.install_dir = Path(install_dir or (Path.home() / "ComfyUI")).expanduser()
        self.log = log or (lambda msg: None)

    def _run(self, cmd: list[str], cwd: Path | None = None, timeout: int | None = None) -> None:
        self.log("$ " + " ".join(cmd))
        proc = subprocess.Popen(
            cmd,
            cwd=str(cwd) if cwd else None,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            env={**os.environ, "PYTHONUNBUFFERED": "1"},
        )
        assert proc.stdout is not None
        for line in proc.stdout:
            self.log(line.rstrip())
        rc = proc.wait(timeout=timeout)
        if rc != 0:
            raise RuntimeError(f"Command failed with exit code {rc}: {' '.join(cmd)}")

    def check_tools(self) -> tuple[bool, str]:
        missing = []
        for tool in ("git", "python3"):
            if shutil.which(tool) is None:
                missing.append(tool)
        if missing:
            return False, "Missing required tools: " + ", ".join(missing) + ". Install them with: sudo apt install git python3 python3-venv"
        return True, "Required tools found."

    def install_or_update(self) -> InstallResult:
        ok, msg = self.check_tools()
        self.log(msg)
        if not ok:
            return InstallResult(False, str(self.install_dir), msg)

        try:
            if (self.install_dir / ".git").exists():
                self.log(f"Existing ComfyUI found at {self.install_dir}; updating...")
                self._run(["git", "pull", "--ff-only"], cwd=self.install_dir)
            elif self.install_dir.exists() and any(self.install_dir.iterdir()):
                if not (self.install_dir / "main.py").exists():
                    return InstallResult(False, str(self.install_dir), "Install folder exists but is not empty and does not look like ComfyUI.")
                self.log(f"Existing non-git ComfyUI folder found at {self.install_dir}; skipping clone.")
            else:
                self.install_dir.parent.mkdir(parents=True, exist_ok=True)
                self.log(f"Cloning ComfyUI into {self.install_dir}...")
                self._run(["git", "clone", self.REPO_URL, str(self.install_dir)])

            venv = self.install_dir / "venv"
            if not (venv / "bin" / "python").exists():
                self.log("Creating ComfyUI virtual environment...")
                self._run(["python3", "-m", "venv", str(venv)])

            py = venv / "bin" / "python"
            pip = venv / "bin" / "pip"
            self.log("Upgrading pip...")
            self._run([str(py), "-m", "pip", "install", "--upgrade", "pip"])
            req = self.install_dir / "requirements.txt"
            if req.exists():
                self.log("Installing ComfyUI Python requirements. This can take a while...")
                self._run([str(pip), "install", "-r", str(req)])

            (self.install_dir / "models" / "checkpoints").mkdir(parents=True, exist_ok=True)
            return InstallResult(True, str(self.install_dir), "ComfyUI installed/updated successfully.")
        except Exception as exc:
            return InstallResult(False, str(self.install_dir), str(exc))
