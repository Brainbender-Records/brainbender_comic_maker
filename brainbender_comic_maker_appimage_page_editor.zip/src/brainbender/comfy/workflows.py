from __future__ import annotations

import random
from pathlib import Path
from typing import Any, Dict, Optional


def safe_seed(seed_text: str | None = None) -> int:
    if seed_text and str(seed_text).strip().isdigit():
        return int(str(seed_text).strip())
    return random.randint(1, 2**31 - 1)


def text_to_image_workflow(
    *,
    checkpoint: str,
    prompt: str,
    negative_prompt: str,
    width: int = 768,
    height: int = 768,
    steps: int = 25,
    cfg: float = 7.0,
    sampler: str = "euler",
    scheduler: str = "normal",
    seed: Optional[int] = None,
    prefix: str = "brainbender_panel",
) -> Dict[str, Any]:
    seed = seed if seed is not None else safe_seed()
    return {
        "1": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": checkpoint}},
        "2": {"class_type": "CLIPTextEncode", "inputs": {"text": prompt, "clip": ["1", 1]}},
        "3": {"class_type": "CLIPTextEncode", "inputs": {"text": negative_prompt, "clip": ["1", 1]}},
        "4": {"class_type": "EmptyLatentImage", "inputs": {"width": width, "height": height, "batch_size": 1}},
        "5": {
            "class_type": "KSampler",
            "inputs": {
                "seed": seed,
                "steps": steps,
                "cfg": cfg,
                "sampler_name": sampler,
                "scheduler": scheduler,
                "denoise": 1.0,
                "model": ["1", 0],
                "positive": ["2", 0],
                "negative": ["3", 0],
                "latent_image": ["4", 0],
            },
        },
        "6": {"class_type": "VAEDecode", "inputs": {"samples": ["5", 0], "vae": ["1", 2]}},
        "7": {"class_type": "SaveImage", "inputs": {"filename_prefix": prefix, "images": ["6", 0]}},
    }


def image_to_image_workflow(
    *,
    checkpoint: str,
    prompt: str,
    negative_prompt: str,
    uploaded_image_name: str,
    steps: int = 25,
    cfg: float = 7.0,
    denoise: float = 0.55,
    sampler: str = "euler",
    scheduler: str = "normal",
    seed: Optional[int] = None,
    prefix: str = "brainbender_img2img_panel",
) -> Dict[str, Any]:
    seed = seed if seed is not None else safe_seed()
    return {
        "1": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": checkpoint}},
        "2": {"class_type": "CLIPTextEncode", "inputs": {"text": prompt, "clip": ["1", 1]}},
        "3": {"class_type": "CLIPTextEncode", "inputs": {"text": negative_prompt, "clip": ["1", 1]}},
        "4": {"class_type": "LoadImage", "inputs": {"image": uploaded_image_name}},
        "5": {"class_type": "VAEEncode", "inputs": {"pixels": ["4", 0], "vae": ["1", 2]}},
        "6": {
            "class_type": "KSampler",
            "inputs": {
                "seed": seed,
                "steps": steps,
                "cfg": cfg,
                "sampler_name": sampler,
                "scheduler": scheduler,
                "denoise": denoise,
                "model": ["1", 0],
                "positive": ["2", 0],
                "negative": ["3", 0],
                "latent_image": ["5", 0],
            },
        },
        "7": {"class_type": "VAEDecode", "inputs": {"samples": ["6", 0], "vae": ["1", 2]}},
        "8": {"class_type": "SaveImage", "inputs": {"filename_prefix": prefix, "images": ["7", 0]}},
    }



def ipadapter_reference_workflow(
    *,
    checkpoint: str,
    prompt: str,
    negative_prompt: str,
    uploaded_reference_name: str,
    width: int = 768,
    height: int = 768,
    steps: int = 25,
    cfg: float = 7.0,
    sampler: str = "euler",
    scheduler: str = "normal",
    seed: Optional[int] = None,
    ipadapter_model: str = "ip-adapter-plus_sd15.safetensors",
    clip_vision_model: str = "CLIP-ViT-H-14-laion2B-s32B-b79K.safetensors",
    weight: float = 0.75,
    prefix: str = "brainbender_ipadapter_panel",
) -> Dict[str, Any]:
    """ComfyUI workflow template for IPAdapter-style character/reference consistency.

    This uses common node names from ComfyUI IPAdapter Plus. Users must install the
    relevant custom nodes and models in ComfyUI first. The app validates node names
    before sending this workflow when possible.
    """
    seed = seed if seed is not None else safe_seed()
    return {
        "1": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": checkpoint}},
        "2": {"class_type": "CLIPTextEncode", "inputs": {"text": prompt, "clip": ["1", 1]}},
        "3": {"class_type": "CLIPTextEncode", "inputs": {"text": negative_prompt, "clip": ["1", 1]}},
        "4": {"class_type": "EmptyLatentImage", "inputs": {"width": width, "height": height, "batch_size": 1}},
        "5": {"class_type": "LoadImage", "inputs": {"image": uploaded_reference_name}},
        "6": {"class_type": "CLIPVisionLoader", "inputs": {"clip_name": clip_vision_model}},
        "7": {"class_type": "IPAdapterModelLoader", "inputs": {"ipadapter_file": ipadapter_model}},
        "8": {
            "class_type": "IPAdapterAdvanced",
            "inputs": {
                "model": ["1", 0],
                "ipadapter": ["7", 0],
                "image": ["5", 0],
                "clip_vision": ["6", 0],
                "weight": weight,
                "weight_type": "linear",
                "combine_embeds": "concat",
                "start_at": 0.0,
                "end_at": 1.0,
                "embeds_scaling": "V only",
            },
        },
        "9": {
            "class_type": "KSampler",
            "inputs": {
                "seed": seed,
                "steps": steps,
                "cfg": cfg,
                "sampler_name": sampler,
                "scheduler": scheduler,
                "denoise": 1.0,
                "model": ["8", 0],
                "positive": ["2", 0],
                "negative": ["3", 0],
                "latent_image": ["4", 0],
            },
        },
        "10": {"class_type": "VAEDecode", "inputs": {"samples": ["9", 0], "vae": ["1", 2]}},
        "11": {"class_type": "SaveImage", "inputs": {"filename_prefix": prefix, "images": ["10", 0]}},
    }


def controlnet_pose_workflow(
    *,
    checkpoint: str,
    prompt: str,
    negative_prompt: str,
    uploaded_pose_name: str,
    controlnet_model: str = "control_v11p_sd15_openpose.pth",
    width: int = 768,
    height: int = 768,
    steps: int = 25,
    cfg: float = 7.0,
    sampler: str = "euler",
    scheduler: str = "normal",
    seed: Optional[int] = None,
    strength: float = 0.85,
    prefix: str = "brainbender_controlnet_pose_panel",
) -> Dict[str, Any]:
    """ComfyUI workflow template for pose-guided comic panels with ControlNet.

    This expects a preprocessed pose/control image. Automatic OpenPose preprocessing
    can be added later after the user's ComfyUI custom nodes are known.
    """
    seed = seed if seed is not None else safe_seed()
    return {
        "1": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": checkpoint}},
        "2": {"class_type": "CLIPTextEncode", "inputs": {"text": prompt, "clip": ["1", 1]}},
        "3": {"class_type": "CLIPTextEncode", "inputs": {"text": negative_prompt, "clip": ["1", 1]}},
        "4": {"class_type": "EmptyLatentImage", "inputs": {"width": width, "height": height, "batch_size": 1}},
        "5": {"class_type": "LoadImage", "inputs": {"image": uploaded_pose_name}},
        "6": {"class_type": "ControlNetLoader", "inputs": {"control_net_name": controlnet_model}},
        "7": {"class_type": "ControlNetApplyAdvanced", "inputs": {"positive": ["2", 0], "negative": ["3", 0], "control_net": ["6", 0], "image": ["5", 0], "strength": strength, "start_percent": 0.0, "end_percent": 1.0}},
        "8": {"class_type": "KSampler", "inputs": {"seed": seed, "steps": steps, "cfg": cfg, "sampler_name": sampler, "scheduler": scheduler, "denoise": 1.0, "model": ["1", 0], "positive": ["7", 0], "negative": ["7", 1], "latent_image": ["4", 0]}},
        "9": {"class_type": "VAEDecode", "inputs": {"samples": ["8", 0], "vae": ["1", 2]}},
        "10": {"class_type": "SaveImage", "inputs": {"filename_prefix": prefix, "images": ["9", 0]}},
    }


def workflow_required_classes(workflow: Dict[str, Any]) -> set[str]:
    return {node.get("class_type", "") for node in workflow.values() if node.get("class_type")}
