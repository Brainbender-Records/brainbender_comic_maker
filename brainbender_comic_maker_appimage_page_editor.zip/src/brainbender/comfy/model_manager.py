from __future__ import annotations

import json
import shutil
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Callable, List, Optional
from urllib.parse import urlparse

import requests

MODEL_EXTENSIONS = ('.safetensors', '.ckpt', '.pt')


@dataclass
class ModelEntry:
    name: str
    path: str
    size_bytes: int
    modified: float


class ModelManager:
    def __init__(self, comfy_path: str | Path):
        self.comfy_path = Path(comfy_path).expanduser() if comfy_path else Path()
        self.checkpoint_dir = self.comfy_path / 'models' / 'checkpoints'
        self.downloads_file = self.comfy_path / 'models' / 'brainbender_model_downloads.json'

    def is_configured(self) -> bool:
        return bool(str(self.comfy_path)) and (self.comfy_path / 'main.py').exists()

    def ensure_checkpoint_dir(self) -> Path:
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        return self.checkpoint_dir

    def scan_checkpoints(self) -> List[ModelEntry]:
        if not self.checkpoint_dir.exists():
            return []
        entries: List[ModelEntry] = []
        for p in sorted(self.checkpoint_dir.iterdir()):
            if p.is_file() and p.suffix.lower() in MODEL_EXTENSIONS:
                st = p.stat()
                entries.append(ModelEntry(p.name, str(p), st.st_size, st.st_mtime))
        return entries

    def import_model(self, source: str | Path) -> Path:
        src = Path(source).expanduser()
        if not src.exists():
            raise FileNotFoundError(f'Model file not found: {src}')
        if src.suffix.lower() not in MODEL_EXTENSIONS:
            raise ValueError('Model must be .safetensors, .ckpt, or .pt')
        self.ensure_checkpoint_dir()
        dest = self.checkpoint_dir / src.name
        if src.resolve() != dest.resolve():
            shutil.copy2(src, dest)
        return dest

    def load_download_presets(self) -> list[dict]:
        if self.downloads_file.exists():
            try:
                return json.loads(self.downloads_file.read_text())
            except Exception:
                return []
        return []

    def save_download_presets(self, presets: list[dict]) -> None:
        self.downloads_file.parent.mkdir(parents=True, exist_ok=True)
        self.downloads_file.write_text(json.dumps(presets, indent=2))

    def add_download_preset(self, name: str, url: str, notes: str = '') -> None:
        presets = self.load_download_presets()
        presets.append({'name': name.strip() or self._filename_from_url(url), 'url': url.strip(), 'notes': notes.strip()})
        self.save_download_presets(presets)

    def _filename_from_url(self, url: str) -> str:
        parsed = urlparse(url)
        name = Path(parsed.path).name
        return name or f'model_{int(time.time())}.safetensors'

    def download_model(self, url: str, filename: Optional[str] = None, progress: Optional[Callable[[int, int], None]] = None) -> Path:
        if not url.startswith(('http://', 'https://')):
            raise ValueError('Download URL must start with http:// or https://')
        self.ensure_checkpoint_dir()
        filename = filename or self._filename_from_url(url)
        if not filename.endswith(MODEL_EXTENSIONS):
            raise ValueError('The download filename must end in .safetensors, .ckpt, or .pt')
        dest = self.checkpoint_dir / filename
        tmp = dest.with_suffix(dest.suffix + '.part')
        with requests.get(url, stream=True, timeout=30) as r:
            r.raise_for_status()
            total = int(r.headers.get('content-length') or 0)
            done = 0
            with tmp.open('wb') as fh:
                for chunk in r.iter_content(chunk_size=1024 * 1024):
                    if chunk:
                        fh.write(chunk)
                        done += len(chunk)
                        if progress:
                            progress(done, total)
        tmp.rename(dest)
        return dest


def human_size(size: int) -> str:
    value = float(size)
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if value < 1024 or unit == 'TB':
            return f'{value:.1f} {unit}' if unit != 'B' else f'{int(value)} B'
        value /= 1024
