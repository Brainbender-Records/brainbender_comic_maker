from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Dict, Any

from ..core.paths import APP_DIR

PRESET_FILE = APP_DIR / "workflow_presets.json"


@dataclass
class WorkflowPreset:
    name: str
    family: str = "SD 1.5"
    description: str = ""
    width: int = 768
    height: int = 768
    steps: int = 25
    cfg: float = 7.0
    sampler: str = "euler"
    scheduler: str = "normal"
    denoise: float = 0.55
    prompt_prefix: str = ""
    prompt_suffix: str = "comic book panel, clean composition"
    negative_prompt: str = "blurry, low quality, bad hands, watermark, text artifacts"
    mode_hint: str = "txt2img"
    notes: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WorkflowPreset":
        base = asdict(cls(name="Temporary"))
        base.update(data)
        return cls(**{k: base[k] for k in base})

    def apply_prompt(self, prompt: str) -> str:
        parts = [self.prompt_prefix.strip(), prompt.strip(), self.prompt_suffix.strip()]
        return ", ".join([p for p in parts if p])


def default_presets() -> List[WorkflowPreset]:
    return [
        WorkflowPreset(
            name="SD 1.5 Comic Panel",
            family="SD 1.5",
            description="Balanced 768px comic panel preset for standard SD 1.5-style checkpoints.",
            width=768,
            height=768,
            steps=25,
            cfg=7.0,
            sampler="euler",
            scheduler="normal",
            prompt_suffix="comic book panel, inked linework, dramatic lighting, clear composition",
        ),
        WorkflowPreset(
            name="SDXL Comic Splash Page",
            family="SDXL",
            description="Larger SDXL-style splash image preset.",
            width=1024,
            height=1024,
            steps=30,
            cfg=6.5,
            sampler="dpmpp_2m",
            scheduler="karras",
            prompt_suffix="graphic novel splash page, cinematic composition, highly detailed comic art",
        ),
        WorkflowPreset(
            name="Wide Establishing Shot",
            family="Comic Layout",
            description="Wide panel for location-establishing comic shots.",
            width=1024,
            height=576,
            steps=28,
            cfg=7.0,
            sampler="euler",
            scheduler="normal",
            prompt_prefix="wide establishing shot",
            prompt_suffix="comic panel, environment detail, cinematic framing",
        ),
        WorkflowPreset(
            name="Close-Up Reaction Panel",
            family="Comic Layout",
            description="Portrait panel for faces, emotions, and dialogue moments.",
            width=768,
            height=1024,
            steps=25,
            cfg=7.5,
            sampler="euler",
            scheduler="normal",
            prompt_prefix="close-up reaction shot",
            prompt_suffix="expressive face, comic panel, clean background, strong emotion",
        ),
        WorkflowPreset(
            name="Img2Img Character Continuity",
            family="Reference / Img2Img",
            description="Reference image preset for keeping a character or panel design closer to an input image.",
            width=768,
            height=768,
            steps=24,
            cfg=6.5,
            sampler="euler",
            scheduler="normal",
            denoise=0.45,
            mode_hint="img2img",
            prompt_suffix="consistent character design, comic panel, matching costume and silhouette",
        ),
        WorkflowPreset(
            name="Future ControlNet Pose Slot",
            family="Future Workflow",
            description="Placeholder preset metadata for a future ControlNet/OpenPose workflow.",
            width=768,
            height=1024,
            steps=28,
            cfg=7.0,
            sampler="euler",
            scheduler="normal",
            prompt_suffix="comic panel, pose guided composition, clean anatomy",
            notes="This preset reserves UI metadata. ControlNet node wiring will be added in a later step.",
        ),
        WorkflowPreset(
            name="Future IPAdapter Character Slot",
            family="Future Workflow",
            description="Placeholder preset metadata for a future IPAdapter character-reference workflow.",
            width=768,
            height=768,
            steps=28,
            cfg=6.5,
            sampler="euler",
            scheduler="normal",
            denoise=0.65,
            mode_hint="img2img",
            prompt_suffix="consistent recurring comic character, strong design identity",
            notes="This preset reserves UI metadata. IPAdapter nodes/models will be added in a later step.",
        ),
    ]


class WorkflowPresetManager:
    def __init__(self, path: Path = PRESET_FILE):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.save(default_presets())

    def load(self) -> List[WorkflowPreset]:
        try:
            data = json.loads(self.path.read_text())
            return [WorkflowPreset.from_dict(item) for item in data]
        except Exception:
            presets = default_presets()
            self.save(presets)
            return presets

    def save(self, presets: List[WorkflowPreset]) -> None:
        self.path.write_text(json.dumps([asdict(p) for p in presets], indent=2))

    def add(self, preset: WorkflowPreset) -> None:
        presets = [p for p in self.load() if p.name != preset.name]
        presets.append(preset)
        self.save(presets)

    def by_name(self, name: str) -> WorkflowPreset | None:
        for preset in self.load():
            if preset.name == name:
                return preset
        return None
