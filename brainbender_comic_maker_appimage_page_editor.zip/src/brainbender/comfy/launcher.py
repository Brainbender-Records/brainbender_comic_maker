from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Iterable, List, Tuple

import requests


class ComfyLauncher:
    def __init__(self, url: str = 'http://127.0.0.1:8188', path: str = ''):
        self.url = (url or 'http://127.0.0.1:8188').rstrip('/')
        self.path = str(Path(path).expanduser()) if path else ''
        self.proc = None

    def is_running(self) -> bool:
        try:
            return requests.get(self.url + '/system_stats', timeout=1.5).ok
        except Exception:
            return False

    @staticmethod
    def candidate_paths() -> List[str]:
        home = Path.home()
        candidates: Iterable[Path] = [
            home / 'ComfyUI',
            home / 'comfyui',
            home / 'AI' / 'ComfyUI',
            home / 'Apps' / 'ComfyUI',
            home / 'Projects' / 'ComfyUI',
            home / 'Downloads' / 'ComfyUI',
            Path('/opt/ComfyUI'),
            Path('/usr/local/ComfyUI'),
        ]
        found: List[str] = []
        for p in candidates:
            if (p / 'main.py').exists():
                found.append(str(p))
        return found

    @staticmethod
    def validate_path(path: str) -> Tuple[bool, str]:
        if not path:
            return False, 'No ComfyUI folder selected.'
        p = Path(path).expanduser()
        if not p.exists():
            return False, f'Folder does not exist: {p}'
        if not (p / 'main.py').exists():
            return False, 'This folder does not look like ComfyUI because main.py was not found.'
        return True, 'ComfyUI folder looks valid.'

    @staticmethod
    def model_status(path: str) -> Tuple[int, str]:
        if not path:
            return 0, 'Choose a ComfyUI folder to check models.'
        ckpt_dir = Path(path).expanduser() / 'models' / 'checkpoints'
        ckpt_dir.mkdir(parents=True, exist_ok=True)
        models = [p.name for p in ckpt_dir.glob('*') if p.suffix.lower() in {'.safetensors', '.ckpt', '.pt'}]
        if not models:
            return 0, f'No checkpoint models found in {ckpt_dir}'
        return len(models), f'Found {len(models)} checkpoint model(s).'

    def start(self) -> Tuple[bool, str]:
        if self.is_running():
            return True, 'ComfyUI already running.'
        ok, msg = self.validate_path(self.path)
        if not ok:
            return False, msg

        venv_python = Path(self.path) / 'venv' / 'bin' / 'python'
        command_options = []
        if venv_python.exists():
            command_options.append([str(venv_python), 'main.py', '--listen', '127.0.0.1', '--port', '8188'])
        command_options += [
            [sys.executable, 'main.py', '--listen', '127.0.0.1', '--port', '8188'],
            ['python3', 'main.py', '--listen', '127.0.0.1', '--port', '8188'],
        ]
        last_error = ''
        env = os.environ.copy()
        env.setdefault('PYTHONUNBUFFERED', '1')
        for cmd in command_options:
            try:
                self.proc = subprocess.Popen(cmd, cwd=self.path, env=env)
                for _ in range(80):
                    if self.is_running():
                        return True, 'ComfyUI started and is responding.'
                    if self.proc.poll() is not None:
                        break
                    time.sleep(0.5)
                last_error = 'ComfyUI process started but did not answer in time.'
            except Exception as exc:
                last_error = str(exc)
        return False, 'Could not start ComfyUI. ' + last_error
