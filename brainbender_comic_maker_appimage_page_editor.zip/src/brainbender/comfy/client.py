from __future__ import annotations

import json
import shutil
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import urlencode

import requests
from PIL import Image, ImageDraw

from .workflows import controlnet_pose_workflow, image_to_image_workflow, ipadapter_reference_workflow, safe_seed, text_to_image_workflow, workflow_required_classes


class ComfyError(RuntimeError):
    pass


class ComfyClient:
    def __init__(self, url: str = "http://127.0.0.1:8188"):
        self.url = (url or "http://127.0.0.1:8188").rstrip("/")
        self.client_id = str(uuid.uuid4())

    def ping(self) -> bool:
        try:
            return requests.get(self.url + "/system_stats", timeout=2).ok
        except Exception:
            return False

    def object_info(self) -> Dict[str, Any]:
        try:
            r = requests.get(self.url + "/object_info", timeout=10)
            if r.ok:
                return r.json()
        except Exception:
            pass
        return {}

    def installed_node_classes(self) -> set[str]:
        return set(self.object_info().keys())

    def validate_workflow_nodes(self, workflow: Dict[str, Any]) -> tuple[bool, list[str]]:
        installed = self.installed_node_classes()
        if not installed:
            return False, ["Could not read ComfyUI /object_info. Is ComfyUI running?"]
        required = sorted(workflow_required_classes(workflow))
        missing = [name for name in required if name not in installed]
        return not missing, missing

    def list_checkpoints(self, comfy_path: str | Path | None) -> List[str]:
        if not comfy_path:
            return []
        p = Path(comfy_path).expanduser() / "models" / "checkpoints"
        if not p.exists():
            return []
        return sorted(
            x.name
            for x in p.glob("*")
            if x.suffix.lower() in (".safetensors", ".ckpt", ".pt") and x.is_file()
        )

    def import_model_file(self, comfy_path: str | Path, model_file: str | Path) -> Path:
        src = Path(model_file).expanduser()
        if src.suffix.lower() not in (".safetensors", ".ckpt", ".pt"):
            raise ComfyError("Model file must be .safetensors, .ckpt, or .pt")
        dest_dir = Path(comfy_path).expanduser() / "models" / "checkpoints"
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / src.name
        if src.resolve() != dest.resolve():
            shutil.copy2(src, dest)
        return dest

    def upload_image(self, image_path: str | Path) -> str:
        image_path = Path(image_path).expanduser()
        if not image_path.exists():
            raise ComfyError(f"Reference image not found: {image_path}")
        with image_path.open("rb") as fh:
            files = {"image": (image_path.name, fh, "application/octet-stream")}
            data = {"overwrite": "true", "type": "input"}
            r = requests.post(self.url + "/upload/image", files=files, data=data, timeout=60)
        if not r.ok:
            raise ComfyError(f"ComfyUI image upload failed: {r.status_code} {r.text[:300]}")
        payload = r.json()
        return payload.get("name") or image_path.name

    def queue_prompt(self, workflow: Dict[str, Any]) -> str:
        payload = {"prompt": workflow, "client_id": self.client_id}
        r = requests.post(self.url + "/prompt", json=payload, timeout=30)
        if not r.ok:
            raise ComfyError(f"ComfyUI prompt failed: {r.status_code} {r.text[:500]}")
        data = r.json()
        prompt_id = data.get("prompt_id")
        if not prompt_id:
            raise ComfyError(f"ComfyUI did not return a prompt_id: {data}")
        return prompt_id

    def wait_for_history(self, prompt_id: str, timeout_seconds: int = 900) -> Dict[str, Any]:
        deadline = time.time() + timeout_seconds
        while time.time() < deadline:
            r = requests.get(self.url + f"/history/{prompt_id}", timeout=10)
            if r.ok:
                hist = r.json()
                if prompt_id in hist:
                    return hist[prompt_id]
            time.sleep(1.5)
        raise ComfyError("Timed out waiting for ComfyUI generation to finish")

    def _history_images(self, history_item: Dict[str, Any]) -> List[Dict[str, str]]:
        images: List[Dict[str, str]] = []
        outputs = history_item.get("outputs", {})
        for node_out in outputs.values():
            for img in node_out.get("images", []) or []:
                if "filename" in img:
                    images.append(img)
        return images

    def download_output_image(self, image_info: Dict[str, str], out_dir: str | Path) -> Path:
        out_dir = Path(out_dir).expanduser()
        out_dir.mkdir(parents=True, exist_ok=True)
        query = urlencode(
            {
                "filename": image_info.get("filename", ""),
                "subfolder": image_info.get("subfolder", ""),
                "type": image_info.get("type", "output"),
            }
        )
        r = requests.get(self.url + "/view?" + query, timeout=120)
        if not r.ok:
            raise ComfyError(f"Could not download generated image: {r.status_code}")
        name = image_info.get("filename") or f"brainbender_{int(time.time())}.png"
        dest = out_dir / name
        dest.write_bytes(r.content)
        return dest

    def generate_text_to_image(
        self,
        *,
        checkpoint: str,
        prompt: str,
        negative_prompt: str,
        out_dir: str | Path,
        width: int = 768,
        height: int = 768,
        steps: int = 25,
        cfg: float = 7.0,
        seed: Optional[int] = None,
        sampler: str = "euler",
        scheduler: str = "normal",
    ) -> Path:
        if not self.ping():
            raise ComfyError("ComfyUI is not running or is not reachable.")
        workflow = text_to_image_workflow(
            checkpoint=checkpoint,
            prompt=prompt,
            negative_prompt=negative_prompt,
            width=width,
            height=height,
            steps=steps,
            cfg=cfg,
            seed=seed,
            sampler=sampler,
            scheduler=scheduler,
        )
        prompt_id = self.queue_prompt(workflow)
        history = self.wait_for_history(prompt_id)
        images = self._history_images(history)
        if not images:
            raise ComfyError("ComfyUI finished but returned no images.")
        return self.download_output_image(images[-1], out_dir)

    def generate_image_to_image(
        self,
        *,
        checkpoint: str,
        prompt: str,
        negative_prompt: str,
        reference_image: str | Path,
        out_dir: str | Path,
        steps: int = 25,
        cfg: float = 7.0,
        denoise: float = 0.55,
        seed: Optional[int] = None,
        sampler: str = "euler",
        scheduler: str = "normal",
    ) -> Path:
        if not self.ping():
            raise ComfyError("ComfyUI is not running or is not reachable.")
        uploaded_name = self.upload_image(reference_image)
        workflow = image_to_image_workflow(
            checkpoint=checkpoint,
            prompt=prompt,
            negative_prompt=negative_prompt,
            uploaded_image_name=uploaded_name,
            steps=steps,
            cfg=cfg,
            denoise=denoise,
            seed=seed,
            sampler=sampler,
            scheduler=scheduler,
        )
        prompt_id = self.queue_prompt(workflow)
        history = self.wait_for_history(prompt_id)
        images = self._history_images(history)
        if not images:
            raise ComfyError("ComfyUI finished but returned no images.")
        return self.download_output_image(images[-1], out_dir)

    def generate_ipadapter_reference(
        self,
        *,
        checkpoint: str,
        prompt: str,
        negative_prompt: str,
        reference_image: str | Path,
        out_dir: str | Path,
        width: int = 768,
        height: int = 768,
        steps: int = 25,
        cfg: float = 7.0,
        seed: Optional[int] = None,
        sampler: str = "euler",
        scheduler: str = "normal",
        ipadapter_model: str = "ip-adapter-plus_sd15.safetensors",
        clip_vision_model: str = "CLIP-ViT-H-14-laion2B-s32B-b79K.safetensors",
        weight: float = 0.75,
        validate_nodes: bool = True,
    ) -> Path:
        if not self.ping():
            raise ComfyError("ComfyUI is not running or is not reachable.")
        uploaded_name = self.upload_image(reference_image)
        workflow = ipadapter_reference_workflow(
            checkpoint=checkpoint,
            prompt=prompt,
            negative_prompt=negative_prompt,
            uploaded_reference_name=uploaded_name,
            width=width,
            height=height,
            steps=steps,
            cfg=cfg,
            seed=seed,
            sampler=sampler,
            scheduler=scheduler,
            ipadapter_model=ipadapter_model,
            clip_vision_model=clip_vision_model,
            weight=weight,
        )
        if validate_nodes:
            ok, missing = self.validate_workflow_nodes(workflow)
            if not ok:
                raise ComfyError("Missing ComfyUI nodes for IPAdapter workflow: " + ", ".join(missing))
        prompt_id = self.queue_prompt(workflow)
        history = self.wait_for_history(prompt_id)
        images = self._history_images(history)
        if not images:
            raise ComfyError("ComfyUI finished but returned no images.")
        return self.download_output_image(images[-1], out_dir)

    def generate_controlnet_pose(
        self,
        *,
        checkpoint: str,
        prompt: str,
        negative_prompt: str,
        pose_image: str | Path,
        out_dir: str | Path,
        width: int = 768,
        height: int = 768,
        steps: int = 25,
        cfg: float = 7.0,
        seed: Optional[int] = None,
        sampler: str = "euler",
        scheduler: str = "normal",
        controlnet_model: str = "control_v11p_sd15_openpose.pth",
        strength: float = 0.85,
        validate_nodes: bool = True,
    ) -> Path:
        if not self.ping():
            raise ComfyError("ComfyUI is not running or is not reachable.")
        uploaded_name = self.upload_image(pose_image)
        workflow = controlnet_pose_workflow(
            checkpoint=checkpoint,
            prompt=prompt,
            negative_prompt=negative_prompt,
            uploaded_pose_name=uploaded_name,
            controlnet_model=controlnet_model,
            width=width,
            height=height,
            steps=steps,
            cfg=cfg,
            seed=seed,
            sampler=sampler,
            scheduler=scheduler,
            strength=strength,
        )
        if validate_nodes:
            ok, missing = self.validate_workflow_nodes(workflow)
            if not ok:
                raise ComfyError("Missing ComfyUI nodes for ControlNet workflow: " + ", ".join(missing))
        prompt_id = self.queue_prompt(workflow)
        history = self.wait_for_history(prompt_id)
        images = self._history_images(history)
        if not images:
            raise ComfyError("ComfyUI finished but returned no images.")
        return self.download_output_image(images[-1], out_dir)

    def generate_placeholder(self, prompt: str, out_dir: str | Path) -> str:
        out = Path(out_dir).expanduser()
        out.mkdir(parents=True, exist_ok=True)
        path = out / f"placeholder_panel_{int(time.time())}.png"
        img = Image.new("RGB", (1024, 1024), "white")
        d = ImageDraw.Draw(img)
        d.rectangle((30, 30, 994, 994), outline="black", width=6)
        d.text((60, 80), "Brainbender Comic Maker\nPlaceholder panel\n\n" + prompt[:800], fill="black")
        img.save(path)
        return str(path)
