from pathlib import Path
from zipfile import ZipFile
from PIL import Image, ImageDraw, ImageFont
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter

class Exporter:
    def export_contact_pdf(self, images, dest):
        dest=Path(dest); dest.parent.mkdir(parents=True, exist_ok=True)
        c=canvas.Canvas(str(dest), pagesize=letter)
        w,h=letter; x,y=40,h-240
        for i,img in enumerate(images):
            c.drawImage(str(img), x, y, width=220, height=220, preserveAspectRatio=True, mask='auto')
            c.drawString(x, y-14, Path(img).name)
            x += 260
            if x>330: x=40; y-=280
            if y<60: c.showPage(); x,y=40,h-240
        c.save(); return str(dest)
    def export_cbz(self, images, dest):
        dest=Path(dest); dest.parent.mkdir(parents=True, exist_ok=True)
        with ZipFile(dest,'w') as z:
            for n,img in enumerate(images,1): z.write(img, f'{n:03d}_{Path(img).name}')
        return str(dest)
