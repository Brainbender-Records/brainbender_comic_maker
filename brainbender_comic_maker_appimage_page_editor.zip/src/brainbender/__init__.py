__app_name__ = 'Brainbender Comic Maker'
__version__ = '0.8.0-appimage'
