import json, shutil, uuid
from pathlib import Path
from .paths import APP_DIR, PROJECTS_DIR

class JsonLibrary:
    def __init__(self, name):
        self.path = APP_DIR/f'{name}.json'
        self.items=[]; self.load()
    def load(self):
        if self.path.exists():
            try: self.items=json.loads(self.path.read_text())
            except Exception: self.items=[]
    def save(self):
        self.path.write_text(json.dumps(self.items, indent=2))
    def add(self, item):
        item.setdefault('id', str(uuid.uuid4()))
        self.items.append(item); self.save(); return item
    def all(self): return list(self.items)

class ProjectStore:
    def __init__(self):
        PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
    def create_project(self, name):
        slug=''.join(c.lower() if c.isalnum() else '-' for c in name).strip('-') or 'comic'
        path=PROJECTS_DIR/slug; path.mkdir(parents=True, exist_ok=True)
        meta={'name':name,'chapters':[],'pages':[]}
        (path/'project.json').write_text(json.dumps(meta, indent=2))
        (path/'pages').mkdir(exist_ok=True); (path/'assets').mkdir(exist_ok=True)
        return path
