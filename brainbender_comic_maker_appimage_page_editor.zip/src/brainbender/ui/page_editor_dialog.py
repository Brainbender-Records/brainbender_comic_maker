from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, QRectF
from PySide6.QtGui import QBrush, QImage, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (
    QComboBox, QDialog, QFileDialog, QGraphicsPixmapItem, QGraphicsRectItem,
    QGraphicsScene, QGraphicsTextItem, QGraphicsView, QHBoxLayout, QLabel,
    QLineEdit, QListWidget, QMessageBox, QPushButton, QSpinBox, QVBoxLayout,
    QWidget
)

from ..core.page_layout import PageLayoutData, PageLayoutStore, PanelData
from ..core.paths import data_dir


class PanelItem(QGraphicsRectItem):
    def __init__(self, panel: PanelData):
        super().__init__(0, 0, panel.w, panel.h)
        self.panel = panel
        self.setPos(panel.x, panel.y)
        self.setFlags(
            QGraphicsRectItem.ItemIsMovable |
            QGraphicsRectItem.ItemIsSelectable |
            QGraphicsRectItem.ItemSendsGeometryChanges
        )
        self.setPen(QPen(Qt.black, 6))
        self.setBrush(QBrush(Qt.white))
        self.image_item = None
        self.caption_item = QGraphicsTextItem(panel.caption or "Panel")
        self.caption_item.setDefaultTextColor(Qt.black)
        self.caption_item.setParentItem(self)
        self.caption_item.setPos(12, 10)
        self._load_image()

    def _load_image(self):
        if self.image_item:
            self.scene().removeItem(self.image_item) if self.scene() else None
            self.image_item = None
        if self.panel.image_path and Path(self.panel.image_path).exists():
            pix = QPixmap(self.panel.image_path)
            if not pix.isNull():
                scaled = pix.scaled(int(self.panel.w), int(self.panel.h), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
                self.image_item = QGraphicsPixmapItem(scaled, self)
                self.image_item.setOffset((self.panel.w - scaled.width()) / 2, (self.panel.h - scaled.height()) / 2)
                self.image_item.setZValue(-1)

    def set_image(self, path: str):
        self.panel.image_path = path
        self._load_image()

    def sync(self):
        self.panel.x = float(self.pos().x())
        self.panel.y = float(self.pos().y())
        self.panel.w = float(self.rect().width())
        self.panel.h = float(self.rect().height())
        self.panel.caption = self.caption_item.toPlainText()


class PageEditorDialog(QDialog):
    """Simple visual page layout editor with templates, image assignment, JSON save/load, and PNG export."""

    def __init__(self, generated_images: list[str], parent=None):
        super().__init__(parent)
        self.setWindowTitle("Brainbender Page Layout Editor")
        self.resize(1250, 840)
        self.store = PageLayoutStore()
        self.generated_images = generated_images
        self.layout_data = self.store.template("6 Panel Grid")
        self.scene = QGraphicsScene(self)
        self.view = QGraphicsView(self.scene)
        self.view.setRenderHints(QPainter.Antialiasing | QPainter.SmoothPixmapTransform)
        self.panel_items: list[PanelItem] = []
        self._build_ui()
        self.render_layout()

    def _build_ui(self):
        root = QHBoxLayout(self)
        side = QVBoxLayout()
        root.addWidget(self.view, 1)
        root.addLayout(side)

        self.title_edit = QLineEdit(self.layout_data.title)
        self.template_combo = QComboBox()
        self.template_combo.addItems(["Single Splash", "3 Row Page", "6 Panel Grid", "Splash + 2 Bottom"])
        self.template_combo.setCurrentText("6 Panel Grid")
        self.page_width = QSpinBox(); self.page_width.setRange(600, 4000); self.page_width.setValue(self.layout_data.width); self.page_width.setSingleStep(100)
        self.page_height = QSpinBox(); self.page_height.setRange(600, 6000); self.page_height.setValue(self.layout_data.height); self.page_height.setSingleStep(100)

        new_template = QPushButton("Apply Template")
        add_panel = QPushButton("Add Blank Panel")
        assign_image = QPushButton("Assign Image to Selected Panel")
        save = QPushButton("Save Layout JSON")
        load = QPushButton("Load Layout JSON")
        export = QPushButton("Export Page PNG")
        delete = QPushButton("Delete Selected Panel")

        new_template.clicked.connect(self.apply_template)
        add_panel.clicked.connect(self.add_panel)
        assign_image.clicked.connect(self.assign_image)
        save.clicked.connect(self.save_layout)
        load.clicked.connect(self.load_layout)
        export.clicked.connect(self.export_png)
        delete.clicked.connect(self.delete_selected)

        self.image_list = QListWidget()
        for img in self.generated_images:
            self.image_list.addItem(img)

        side.addWidget(QLabel("Page Title")); side.addWidget(self.title_edit)
        side.addWidget(QLabel("Template")); side.addWidget(self.template_combo)
        side.addWidget(QLabel("Width")); side.addWidget(self.page_width)
        side.addWidget(QLabel("Height")); side.addWidget(self.page_height)
        side.addWidget(new_template); side.addWidget(add_panel); side.addWidget(delete)
        side.addWidget(QLabel("Generated/Available Images")); side.addWidget(self.image_list, 1)
        side.addWidget(assign_image); side.addWidget(save); side.addWidget(load); side.addWidget(export)

    def render_layout(self):
        self.scene.clear()
        self.panel_items = []
        self.scene.setSceneRect(0, 0, self.layout_data.width, self.layout_data.height)
        page = self.scene.addRect(0, 0, self.layout_data.width, self.layout_data.height, QPen(Qt.black, 2), QBrush(Qt.white))
        page.setZValue(-10)
        for panel in self.layout_data.panels:
            item = PanelItem(panel)
            self.scene.addItem(item)
            self.panel_items.append(item)
        self.view.fitInView(self.scene.sceneRect(), Qt.KeepAspectRatio)

    def current_panel(self) -> PanelItem | None:
        for item in self.scene.selectedItems():
            if isinstance(item, PanelItem):
                return item
        return None

    def sync_items(self):
        self.layout_data.title = self.title_edit.text().strip() or "Untitled Page"
        self.layout_data.width = self.page_width.value()
        self.layout_data.height = self.page_height.value()
        for item in self.panel_items:
            item.sync()

    def apply_template(self):
        self.layout_data = self.store.template(self.template_combo.currentText(), self.page_width.value(), self.page_height.value())
        self.title_edit.setText(self.layout_data.title)
        self.render_layout()

    def add_panel(self):
        self.sync_items()
        self.layout_data.panels.append(self.store.make_panel(100, 100, 420, 320))
        self.render_layout()

    def delete_selected(self):
        item = self.current_panel()
        if not item:
            return
        self.sync_items()
        self.layout_data.panels = [p for p in self.layout_data.panels if p.id != item.panel.id]
        self.render_layout()

    def assign_image(self):
        item = self.current_panel()
        if not item:
            QMessageBox.information(self, "Select panel", "Click a panel first.")
            return
        path = ""
        if self.image_list.currentItem():
            path = self.image_list.currentItem().text()
        if not path:
            path, _ = QFileDialog.getOpenFileName(self, "Choose panel image", "", "Images (*.png *.jpg *.jpeg *.webp)")
        if path:
            item.set_image(path)

    def save_layout(self):
        self.sync_items()
        path = self.store.save(self.layout_data)
        QMessageBox.information(self, "Saved", f"Saved layout:\n{path}")

    def load_layout(self):
        path, _ = QFileDialog.getOpenFileName(self, "Load page layout", str(self.store.root), "Page Layout (*.json)")
        if path:
            self.layout_data = self.store.load(path)
            self.title_edit.setText(self.layout_data.title)
            self.page_width.setValue(self.layout_data.width)
            self.page_height.setValue(self.layout_data.height)
            self.render_layout()

    def export_png(self):
        self.sync_items()
        out_dir = data_dir() / "exports"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in self.layout_data.title.lower()) or "page"
        path = out_dir / f"{safe}.png"
        image = QImage(self.layout_data.width, self.layout_data.height, QImage.Format_ARGB32)
        image.fill(Qt.white)
        painter = QPainter(image)
        self.scene.render(painter, QRectF(0, 0, self.layout_data.width, self.layout_data.height), QRectF(0, 0, self.layout_data.width, self.layout_data.height))
        painter.end()
        image.save(str(path))
        QMessageBox.information(self, "Exported", f"Exported page PNG:\n{path}")
