from __future__ import annotations

import traceback
from pathlib import Path

from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import *

from ..comfy.model_manager import ModelManager, human_size


class DownloadWorker(QThread):
    progress = Signal(int, int)
    finished_ok = Signal(str)
    failed = Signal(str)

    def __init__(self, manager: ModelManager, url: str, filename: str):
        super().__init__()
        self.manager = manager
        self.url = url
        self.filename = filename

    def run(self):
        try:
            path = self.manager.download_model(self.url, self.filename or None, self.progress.emit)
            self.finished_ok.emit(str(path))
        except Exception as exc:
            self.failed.emit(f'{exc}\n\n{traceback.format_exc(limit=2)}')


class ModelManagerDialog(QDialog):
    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Brainbender Model Manager')
        self.resize(850, 560)
        self.settings = settings
        self.manager = ModelManager(settings.get('comfy_path'))
        self.worker = None
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        self.status = QLabel('')
        layout.addWidget(self.status)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(['Model', 'Size', 'Modified', 'Path'])
        self.table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.table)

        row = QHBoxLayout()
        refresh = QPushButton('Refresh')
        import_btn = QPushButton('Import Local Model')
        open_folder = QPushButton('Open Checkpoints Folder')
        refresh.clicked.connect(self.refresh)
        import_btn.clicked.connect(self.import_local)
        open_folder.clicked.connect(self.open_folder)
        row.addWidget(refresh); row.addWidget(import_btn); row.addWidget(open_folder)
        layout.addLayout(row)

        group = QGroupBox('Optional Download Helper')
        form = QFormLayout(group)
        self.download_name = QLineEdit()
        self.download_url = QLineEdit()
        self.download_notes = QTextEdit(); self.download_notes.setMaximumHeight(65)
        self.progress = QProgressBar()
        save_preset = QPushButton('Save Download Entry')
        download = QPushButton('Download Model From URL')
        save_preset.clicked.connect(self.save_download_entry)
        download.clicked.connect(self.download_from_url)
        form.addRow('Filename', self.download_name)
        form.addRow('Model URL', self.download_url)
        form.addRow('Notes / license reminder', self.download_notes)
        form.addRow('', save_preset)
        form.addRow('', download)
        form.addRow('Progress', self.progress)
        layout.addWidget(group)

        self.preset_list = QListWidget()
        self.preset_list.itemDoubleClicked.connect(self.load_preset)
        layout.addWidget(QLabel('Saved download entries. Double-click to load one.'))
        layout.addWidget(self.preset_list)

        info = QLabel('Models are not bundled with the app. Only import or download models you have rights to use. Some model sites require login, license acceptance, or tokens; in those cases download manually and use Import Local Model.')
        info.setWordWrap(True)
        layout.addWidget(info)

        close = QPushButton('Close')
        close.clicked.connect(self.accept)
        layout.addWidget(close)

    def refresh(self):
        if not self.manager.is_configured():
            self.status.setText('ComfyUI is not configured. Set the ComfyUI folder in Settings first.')
            return
        self.manager.ensure_checkpoint_dir()
        models = self.manager.scan_checkpoints()
        self.status.setText(f'Checkpoint folder: {self.manager.checkpoint_dir} — {len(models)} model(s) found')
        self.table.setRowCount(len(models))
        for r, m in enumerate(models):
            self.table.setItem(r, 0, QTableWidgetItem(m.name))
            self.table.setItem(r, 1, QTableWidgetItem(human_size(m.size_bytes)))
            self.table.setItem(r, 2, QTableWidgetItem(str(Path(m.path).stat().st_mtime)))
            self.table.setItem(r, 3, QTableWidgetItem(m.path))
        self.preset_list.clear()
        for p in self.manager.load_download_presets():
            item = QListWidgetItem(p.get('name') or p.get('url'))
            item.setData(32, p)
            self.preset_list.addItem(item)

    def import_local(self):
        f, _ = QFileDialog.getOpenFileName(self, 'Import model', '', 'Models (*.safetensors *.ckpt *.pt)')
        if not f:
            return
        try:
            path = self.manager.import_model(f)
            QMessageBox.information(self, 'Imported', f'Imported model:\n{path}')
            self.refresh()
        except Exception as exc:
            QMessageBox.critical(self, 'Import failed', str(exc))

    def open_folder(self):
        self.manager.ensure_checkpoint_dir()
        QMessageBox.information(self, 'Checkpoint folder', str(self.manager.checkpoint_dir))

    def save_download_entry(self):
        try:
            self.manager.add_download_preset(self.download_name.text(), self.download_url.text(), self.download_notes.toPlainText())
            self.refresh()
        except Exception as exc:
            QMessageBox.critical(self, 'Could not save entry', str(exc))

    def load_preset(self, item):
        p = item.data(32) or {}
        self.download_name.setText(p.get('name', ''))
        self.download_url.setText(p.get('url', ''))
        self.download_notes.setPlainText(p.get('notes', ''))

    def download_from_url(self):
        url = self.download_url.text().strip()
        filename = self.download_name.text().strip()
        if not url:
            QMessageBox.warning(self, 'URL needed', 'Paste a direct model download URL first.')
            return
        self.progress.setValue(0)
        self.worker = DownloadWorker(self.manager, url, filename)
        self.worker.progress.connect(self._download_progress)
        self.worker.finished_ok.connect(self._download_done)
        self.worker.failed.connect(self._download_failed)
        self.worker.start()

    def _download_progress(self, done: int, total: int):
        if total:
            self.progress.setValue(int(done * 100 / total))
        else:
            self.progress.setMaximum(0)

    def _download_done(self, path: str):
        self.progress.setMaximum(100); self.progress.setValue(100)
        QMessageBox.information(self, 'Download complete', path)
        self.refresh()

    def _download_failed(self, error: str):
        self.progress.setMaximum(100); self.progress.setValue(0)
        QMessageBox.critical(self, 'Download failed', error.split('\n\n')[0])
