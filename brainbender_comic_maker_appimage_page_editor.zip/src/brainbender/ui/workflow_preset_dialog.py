from __future__ import annotations

from PySide6.QtWidgets import *

from ..comfy.presets import WorkflowPreset, WorkflowPresetManager


class WorkflowPresetDialog(QDialog):
    def __init__(self, manager: WorkflowPresetManager, parent=None):
        super().__init__(parent)
        self.manager = manager
        self.setWindowTitle("Workflow Preset Manager")
        self.resize(820, 560)
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        root = QHBoxLayout(self)
        left = QVBoxLayout(); right = QVBoxLayout()
        root.addLayout(left, 1); root.addLayout(right, 2)

        self.list_widget = QListWidget()
        self.list_widget.currentRowChanged.connect(self.load_selected)
        left.addWidget(QLabel("Presets")); left.addWidget(self.list_widget)
        reset = QPushButton("Reset Defaults")
        reset.clicked.connect(self.reset_defaults)
        left.addWidget(reset)

        form = QFormLayout()
        self.name = QLineEdit()
        self.family = QLineEdit()
        self.description = QPlainTextEdit(); self.description.setMaximumHeight(70)
        self.width = QSpinBox(); self.width.setRange(256, 2048); self.width.setSingleStep(64)
        self.height = QSpinBox(); self.height.setRange(256, 2048); self.height.setSingleStep(64)
        self.steps = QSpinBox(); self.steps.setRange(1, 150)
        self.cfg = QDoubleSpinBox(); self.cfg.setRange(1.0, 30.0); self.cfg.setSingleStep(0.5)
        self.sampler = QComboBox(); self.sampler.addItems(["euler", "euler_ancestral", "heun", "dpm_2", "dpmpp_2m", "dpmpp_sde", "ddim"])
        self.scheduler = QComboBox(); self.scheduler.addItems(["normal", "karras", "exponential", "sgm_uniform", "simple", "ddim_uniform"])
        self.denoise = QDoubleSpinBox(); self.denoise.setRange(0.05, 1.0); self.denoise.setSingleStep(0.05)
        self.mode_hint = QComboBox(); self.mode_hint.addItems(["txt2img", "img2img", "future"])
        self.prefix = QPlainTextEdit(); self.prefix.setMaximumHeight(60)
        self.suffix = QPlainTextEdit(); self.suffix.setMaximumHeight(80)
        self.negative = QPlainTextEdit(); self.negative.setMaximumHeight(80)
        self.notes = QPlainTextEdit(); self.notes.setMaximumHeight(80)

        form.addRow("Name", self.name)
        form.addRow("Family", self.family)
        form.addRow("Description", self.description)
        form.addRow("Width", self.width); form.addRow("Height", self.height)
        form.addRow("Steps", self.steps); form.addRow("CFG", self.cfg)
        form.addRow("Sampler", self.sampler); form.addRow("Scheduler", self.scheduler)
        form.addRow("Img2Img denoise", self.denoise)
        form.addRow("Mode hint", self.mode_hint)
        form.addRow("Prompt prefix", self.prefix)
        form.addRow("Prompt suffix", self.suffix)
        form.addRow("Negative prompt", self.negative)
        form.addRow("Notes", self.notes)
        right.addLayout(form)

        buttons = QHBoxLayout()
        save = QPushButton("Save Preset")
        duplicate = QPushButton("Duplicate As New")
        close = QPushButton("Close")
        save.clicked.connect(self.save_current)
        duplicate.clicked.connect(self.duplicate_current)
        close.clicked.connect(self.accept)
        buttons.addWidget(save); buttons.addWidget(duplicate); buttons.addStretch(1); buttons.addWidget(close)
        right.addLayout(buttons)

    def refresh(self):
        self.list_widget.clear()
        for preset in self.manager.load():
            self.list_widget.addItem(f"{preset.name}  [{preset.family}]")
        if self.list_widget.count():
            self.list_widget.setCurrentRow(0)

    def _selected_name(self) -> str | None:
        item = self.list_widget.currentItem()
        if not item:
            return None
        return item.text().split("  [", 1)[0]

    def load_selected(self, *_):
        name = self._selected_name()
        preset = self.manager.by_name(name) if name else None
        if not preset:
            return
        self.name.setText(preset.name)
        self.family.setText(preset.family)
        self.description.setPlainText(preset.description)
        self.width.setValue(preset.width); self.height.setValue(preset.height)
        self.steps.setValue(preset.steps); self.cfg.setValue(preset.cfg)
        self.sampler.setCurrentText(preset.sampler); self.scheduler.setCurrentText(preset.scheduler)
        self.denoise.setValue(preset.denoise)
        self.mode_hint.setCurrentText(preset.mode_hint if preset.mode_hint in ["txt2img", "img2img", "future"] else "txt2img")
        self.prefix.setPlainText(preset.prompt_prefix)
        self.suffix.setPlainText(preset.prompt_suffix)
        self.negative.setPlainText(preset.negative_prompt)
        self.notes.setPlainText(preset.notes)

    def current_preset(self) -> WorkflowPreset:
        return WorkflowPreset(
            name=self.name.text().strip() or "Untitled Preset",
            family=self.family.text().strip() or "Custom",
            description=self.description.toPlainText().strip(),
            width=self.width.value(),
            height=self.height.value(),
            steps=self.steps.value(),
            cfg=self.cfg.value(),
            sampler=self.sampler.currentText(),
            scheduler=self.scheduler.currentText(),
            denoise=self.denoise.value(),
            mode_hint=self.mode_hint.currentText(),
            prompt_prefix=self.prefix.toPlainText().strip(),
            prompt_suffix=self.suffix.toPlainText().strip(),
            negative_prompt=self.negative.toPlainText().strip(),
            notes=self.notes.toPlainText().strip(),
        )

    def save_current(self):
        self.manager.add(self.current_preset())
        self.refresh()

    def duplicate_current(self):
        preset = self.current_preset()
        preset.name = preset.name + " Copy"
        self.manager.add(preset)
        self.refresh()

    def reset_defaults(self):
        from ..comfy.presets import default_presets
        if QMessageBox.question(self, "Reset presets", "Replace custom presets with defaults?") == QMessageBox.Yes:
            self.manager.save(default_presets())
            self.refresh()
