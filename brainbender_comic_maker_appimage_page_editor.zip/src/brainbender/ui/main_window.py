from __future__ import annotations

import traceback
from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import *

from ..comfy.client import ComfyClient, ComfyError
from ..comfy.launcher import ComfyLauncher
from ..core.library import JsonLibrary, ProjectStore
from ..core.settings import Settings
from ..exporter.exporter import Exporter
from .setup_wizard import SetupWizard
from .comfy_installer_dialog import ComfyInstallerDialog
from .model_manager_dialog import ModelManagerDialog
from .workflow_preset_dialog import WorkflowPresetDialog
from ..comfy.presets import WorkflowPresetManager
from ..continuity import ContinuityStore
from .continuity_dialog import ContinuityDialog
from .page_editor_dialog import PageEditorDialog


class GenerationWorker(QThread):
    finished_ok = Signal(str)
    failed = Signal(str)

    def __init__(self, client: ComfyClient, params: dict):
        super().__init__()
        self.client = client
        self.params = params

    def run(self):
        try:
            mode = self.params.pop("mode")
            if mode == "img2img":
                path = self.client.generate_image_to_image(**self.params)
            elif mode == "ipadapter":
                path = self.client.generate_ipadapter_reference(**self.params)
            elif mode == "controlnet_pose":
                path = self.client.generate_controlnet_pose(**self.params)
            else:
                path = self.client.generate_text_to_image(**self.params)
            self.finished_ok.emit(str(path))
        except Exception as exc:
            self.failed.emit(f"{exc}\n\n{traceback.format_exc(limit=2)}")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Brainbender Comic Maker — AppImage Edition")
        self.resize(1180, 780)
        self.settings = Settings()
        self.client = ComfyClient(self.settings.get("comfy_url"))
        self.characters = JsonLibrary("characters")
        self.locations = JsonLibrary("locations")
        self.projects = ProjectStore()
        self.generated = []
        self.worker = None
        self.preset_manager = WorkflowPresetManager()
        self.continuity_store = ContinuityStore()
        self._build_ui()
        self.refresh_models()
        self.log("Ready. Use Setup Wizard if ComfyUI is not configured yet.")
        if not self.settings.get("setup_complete"):
            self.open_setup_wizard(first_run=True)

    def _build_ui(self):
        tabs = QTabWidget()
        self.setCentralWidget(tabs)
        tabs.addTab(self._studio_tab(), "Studio")
        tabs.addTab(self._library_tab(), "Characters & Continuity")
        tabs.addTab(self._projects_tab(), "Comic Projects")
        tabs.addTab(self._export_tab(), "Export")
        tabs.addTab(self._settings_tab(), "Settings")

    def _studio_tab(self):
        w = QWidget()
        box = QHBoxLayout(w)
        left = QVBoxLayout()
        right = QVBoxLayout()
        box.addLayout(left, 2)
        box.addLayout(right, 1)

        self.prompt = QPlainTextEdit()
        self.prompt.setPlaceholderText("Describe the comic panel...")
        self.negative = QLineEdit("blurry, low quality, bad hands, watermark")
        self.mode = QComboBox()
        self.mode.addItems(["Text to Image", "Image + Text Reference", "Character Reference (IPAdapter)", "Pose Reference (ControlNet)"])
        self.ref_path = QLineEdit()
        choose = QPushButton("Choose Reference Image")
        choose.clicked.connect(self.choose_reference)
        self.model_combo = QComboBox()
        self.preset_combo = QComboBox()
        preset_row = QHBoxLayout()
        apply_preset = QPushButton("Apply Preset")
        manage_presets = QPushButton("Manage Presets")
        apply_preset.clicked.connect(self.apply_selected_preset)
        manage_presets.clicked.connect(self.open_preset_manager)
        preset_row.addWidget(self.preset_combo)
        preset_row.addWidget(apply_preset)
        preset_row.addWidget(manage_presets)

        grid = QGridLayout()
        self.width_spin = QSpinBox(); self.width_spin.setRange(256, 2048); self.width_spin.setSingleStep(64); self.width_spin.setValue(768)
        self.height_spin = QSpinBox(); self.height_spin.setRange(256, 2048); self.height_spin.setSingleStep(64); self.height_spin.setValue(768)
        self.steps_spin = QSpinBox(); self.steps_spin.setRange(1, 150); self.steps_spin.setValue(25)
        self.cfg_spin = QDoubleSpinBox(); self.cfg_spin.setRange(1.0, 30.0); self.cfg_spin.setSingleStep(0.5); self.cfg_spin.setValue(7.0)
        self.denoise_spin = QDoubleSpinBox(); self.denoise_spin.setRange(0.05, 1.0); self.denoise_spin.setSingleStep(0.05); self.denoise_spin.setValue(0.55)
        self.seed_edit = QLineEdit(); self.seed_edit.setPlaceholderText("blank = random")
        self.sampler_combo = QComboBox(); self.sampler_combo.addItems(["euler", "euler_ancestral", "heun", "dpm_2", "dpmpp_2m", "dpmpp_sde", "ddim"])
        self.scheduler_combo = QComboBox(); self.scheduler_combo.addItems(["normal", "karras", "exponential", "sgm_uniform", "simple", "ddim_uniform"])
        self.ipadapter_model_edit = QLineEdit("ip-adapter-plus_sd15.safetensors")
        self.clip_vision_model_edit = QLineEdit("CLIP-ViT-H-14-laion2B-s32B-b79K.safetensors")
        self.controlnet_model_edit = QLineEdit("control_v11p_sd15_openpose.pth")
        self.adapter_weight_spin = QDoubleSpinBox(); self.adapter_weight_spin.setRange(0.05, 2.0); self.adapter_weight_spin.setSingleStep(0.05); self.adapter_weight_spin.setValue(0.75)
        self.validate_nodes_check = QCheckBox("Validate optional ComfyUI nodes before sending workflow")
        self.validate_nodes_check.setChecked(True)
        grid.addWidget(QLabel("Width"), 0, 0); grid.addWidget(self.width_spin, 0, 1)
        grid.addWidget(QLabel("Height"), 0, 2); grid.addWidget(self.height_spin, 0, 3)
        grid.addWidget(QLabel("Steps"), 1, 0); grid.addWidget(self.steps_spin, 1, 1)
        grid.addWidget(QLabel("CFG"), 1, 2); grid.addWidget(self.cfg_spin, 1, 3)
        grid.addWidget(QLabel("Img2Img strength"), 2, 0); grid.addWidget(self.denoise_spin, 2, 1)
        grid.addWidget(QLabel("Seed"), 2, 2); grid.addWidget(self.seed_edit, 2, 3)
        grid.addWidget(QLabel("Sampler"), 3, 0); grid.addWidget(self.sampler_combo, 3, 1)
        grid.addWidget(QLabel("Scheduler"), 3, 2); grid.addWidget(self.scheduler_combo, 3, 3)
        grid.addWidget(QLabel("IPAdapter model"), 4, 0); grid.addWidget(self.ipadapter_model_edit, 4, 1)
        grid.addWidget(QLabel("CLIP Vision"), 4, 2); grid.addWidget(self.clip_vision_model_edit, 4, 3)
        grid.addWidget(QLabel("ControlNet model"), 5, 0); grid.addWidget(self.controlnet_model_edit, 5, 1)
        grid.addWidget(QLabel("Ref/control strength"), 5, 2); grid.addWidget(self.adapter_weight_spin, 5, 3)
        grid.addWidget(self.validate_nodes_check, 6, 0, 1, 4)

        gen = QPushButton("Generate Panel with ComfyUI")
        gen.clicked.connect(self.generate_panel)
        test = QPushButton("Create Placeholder Panel")
        test.clicked.connect(self.generate_placeholder_panel)
        refresh = QPushButton("Refresh Models")
        refresh.clicked.connect(self.refresh_models)

        left.addWidget(QLabel("Prompt")); left.addWidget(self.prompt)
        left.addWidget(QLabel("Negative Prompt")); left.addWidget(self.negative)
        left.addWidget(QLabel("Mode")); left.addWidget(self.mode)
        left.addWidget(QLabel("Reference Image")); left.addWidget(self.ref_path); left.addWidget(choose)
        left.addWidget(QLabel("Checkpoint")); left.addWidget(self.model_combo)
        left.addWidget(QLabel("Workflow Preset")); left.addLayout(preset_row)
        left.addLayout(grid)
        row = QHBoxLayout(); row.addWidget(gen); row.addWidget(test); row.addWidget(refresh); left.addLayout(row)

        self.preview = QLabel("Generated panel preview")
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setMinimumSize(420, 420)
        self.preview.setStyleSheet("border:1px solid #888")
        self.status = QTextEdit(); self.status.setReadOnly(True)
        right.addWidget(self.preview); right.addWidget(QLabel("Log")); right.addWidget(self.status)
        self.refresh_presets()
        return w

    def _library_tab(self):
        w = QWidget(); layout = QVBoxLayout(w)
        form = QFormLayout()
        self.char_name = QLineEdit(); self.char_desc = QPlainTextEdit()
        self.loc_name = QLineEdit(); self.loc_desc = QPlainTextEdit()
        form.addRow("Character name", self.char_name)
        form.addRow("Character notes/look/outfit", self.char_desc)
        form.addRow("Location name", self.loc_name)
        form.addRow("Location notes", self.loc_desc)
        buttons = QHBoxLayout()
        a = QPushButton("Save Character"); b = QPushButton("Save Location"); c = QPushButton("Build Continuity Prompt")
        d = QPushButton("Open Character Consistency Tools")
        a.clicked.connect(self.save_character); b.clicked.connect(self.save_location); c.clicked.connect(self.build_continuity_prompt); d.clicked.connect(self.open_continuity_tools)
        buttons.addWidget(a); buttons.addWidget(b); buttons.addWidget(c); buttons.addWidget(d)
        self.library_view = QTextEdit(); self.library_view.setReadOnly(True)
        layout.addLayout(form); layout.addLayout(buttons); layout.addWidget(self.library_view)
        self.refresh_library_view()
        return w

    def _projects_tab(self):
        w = QWidget(); layout = QVBoxLayout(w)
        self.project_name = QLineEdit("My Comic Book")
        create = QPushButton("Create Comic Project"); create.clicked.connect(self.create_project)
        self.page_notes = QPlainTextEdit(); self.page_notes.setPlaceholderText("Page script, panel notes, dialogue notes...")
        layout.addWidget(QLabel("Project name")); layout.addWidget(self.project_name); layout.addWidget(create)
        layout.addWidget(QLabel("Page / chapter notes")); layout.addWidget(self.page_notes)
        editor = QPushButton("Open Page Layout Editor")
        editor.clicked.connect(self.open_page_editor)
        layout.addWidget(editor)
        layout.addWidget(QLabel("Page editor supports templates, movable panels, image assignment, save/load JSON, and PNG export."))
        return w

    def _export_tab(self):
        w = QWidget(); layout = QVBoxLayout(w)
        pdf = QPushButton("Export Generated Panels as PDF Contact Sheet")
        cbz = QPushButton("Export Generated Panels as CBZ")
        pdf.clicked.connect(self.export_pdf); cbz.clicked.connect(self.export_cbz)
        self.export_log = QTextEdit(); self.export_log.setReadOnly(True)
        layout.addWidget(pdf); layout.addWidget(cbz); layout.addWidget(self.export_log)
        return w

    def _settings_tab(self):
        w = QWidget(); layout = QFormLayout(w)
        self.comfy_url = QLineEdit(self.settings.get("comfy_url"))
        self.comfy_path = QLineEdit(self.settings.get("comfy_path"))
        self.output_dir = QLineEdit(self.settings.get("output_dir"))
        choose = QPushButton("Choose ComfyUI Folder"); choose.clicked.connect(self.choose_comfy)
        save = QPushButton("Save Settings"); save.clicked.connect(self.save_settings)
        start = QPushButton("Start / Check ComfyUI"); start.clicked.connect(self.start_comfy)
        wizard = QPushButton("Open First-Run Setup Wizard"); wizard.clicked.connect(self.open_setup_wizard)
        detect = QPushButton("Auto-Detect ComfyUI Folder"); detect.clicked.connect(self.auto_detect_comfy)
        install_comfy = QPushButton("Install / Update ComfyUI"); install_comfy.clicked.connect(self.install_comfy)
        import_model = QPushButton("Import Checkpoint Model File"); import_model.clicked.connect(self.import_model)
        model_manager = QPushButton("Open Model Manager"); model_manager.clicked.connect(self.open_model_manager)
        preset_manager = QPushButton("Open Workflow Preset Manager"); preset_manager.clicked.connect(self.open_preset_manager)
        continuity_tools = QPushButton("Open Character Consistency Tools"); continuity_tools.clicked.connect(self.open_continuity_tools)
        validate_optional = QPushButton("Check Optional Workflow Nodes"); validate_optional.clicked.connect(self.check_optional_workflows)
        layout.addRow("ComfyUI URL", self.comfy_url)
        layout.addRow("ComfyUI folder", self.comfy_path)
        layout.addRow("", choose)
        layout.addRow("Output folder", self.output_dir)
        layout.addRow("", save)
        layout.addRow("", wizard)
        layout.addRow("", detect)
        layout.addRow("", start)
        layout.addRow("", install_comfy)
        layout.addRow("", import_model)
        layout.addRow("", model_manager)
        layout.addRow("", preset_manager)
        layout.addRow("", continuity_tools)
        layout.addRow("", validate_optional)
        return w

    def log(self, msg):
        self.status.append(str(msg))

    def choose_reference(self):
        f, _ = QFileDialog.getOpenFileName(self, "Reference image", "", "Images (*.png *.jpg *.jpeg *.webp)")
        if f: self.ref_path.setText(f)

    def choose_comfy(self):
        d = QFileDialog.getExistingDirectory(self, "Choose ComfyUI folder")
        if d: self.comfy_path.setText(d)

    def save_settings(self):
        for k, widget in [("comfy_url", self.comfy_url), ("comfy_path", self.comfy_path), ("output_dir", self.output_dir)]:
            self.settings.set(k, widget.text())
        self.client = ComfyClient(self.settings.get("comfy_url"))
        self.refresh_models()
        self.log("Settings saved.")

    def open_setup_wizard(self, first_run=False):
        wiz = SetupWizard(self.settings, self)
        if wiz.exec():
            self.settings.set("setup_complete", True)
            self.comfy_url.setText(self.settings.get("comfy_url"))
            self.comfy_path.setText(self.settings.get("comfy_path"))
            self.client = ComfyClient(self.settings.get("comfy_url"))
            self.refresh_models()
            self.log("Setup wizard finished.")
        elif first_run:
            self.log("Setup wizard skipped. You can open it later from Settings.")

    def install_comfy(self):
        dlg = ComfyInstallerDialog(self.settings, self)
        if dlg.exec():
            self.comfy_path.setText(self.settings.get("comfy_path"))
            self.save_settings()
            self.log("ComfyUI install/update helper finished.")

    def auto_detect_comfy(self):
        found = ComfyLauncher.candidate_paths()
        if found:
            self.comfy_path.setText(found[0])
            self.save_settings()
            self.log(f"Detected ComfyUI folder: {found[0]}")
        else:
            QMessageBox.information(self, "ComfyUI not detected", "Could not find ComfyUI automatically. Use Choose ComfyUI Folder or install ComfyUI first.")

    def start_comfy(self):
        self.save_settings()
        ok, msg = ComfyLauncher(self.settings.get("comfy_url"), self.settings.get("comfy_path")).start()
        self.log(msg)
        self.refresh_models()

    def refresh_models(self):
        self.model_combo.clear()
        models = self.client.list_checkpoints(self.settings.get("comfy_path")) if self.settings.get("comfy_path") else []
        self.model_combo.addItems(models or ["No checkpoint detected yet"])

    def open_model_manager(self):
        dlg = ModelManagerDialog(self.settings, self)
        dlg.exec()
        self.refresh_models()

    def refresh_presets(self):
        if not hasattr(self, "preset_combo"):
            return
        current = self.preset_combo.currentText()
        self.preset_combo.clear()
        for preset in self.preset_manager.load():
            self.preset_combo.addItem(preset.name)
        if current:
            self.preset_combo.setCurrentText(current)

    def open_preset_manager(self):
        dlg = WorkflowPresetDialog(self.preset_manager, self)
        dlg.exec()
        self.refresh_presets()

    def apply_selected_preset(self):
        preset = self.preset_manager.by_name(self.preset_combo.currentText())
        if not preset:
            return
        self.width_spin.setValue(preset.width)
        self.height_spin.setValue(preset.height)
        self.steps_spin.setValue(preset.steps)
        self.cfg_spin.setValue(preset.cfg)
        self.denoise_spin.setValue(preset.denoise)
        self.sampler_combo.setCurrentText(preset.sampler)
        self.scheduler_combo.setCurrentText(preset.scheduler)
        if preset.mode_hint == "img2img":
            self.mode.setCurrentText("Image + Text Reference")
        elif preset.mode_hint == "txt2img":
            self.mode.setCurrentText("Text to Image")
        if preset.negative_prompt:
            self.negative.setText(preset.negative_prompt)
        self.log(f"Applied workflow preset: {preset.name}")

    def _prompt_with_preset(self, prompt: str) -> str:
        preset = self.preset_manager.by_name(self.preset_combo.currentText()) if hasattr(self, "preset_combo") else None
        return preset.apply_prompt(prompt) if preset else prompt

    def check_optional_workflows(self):
        from ..comfy.workflows import ipadapter_reference_workflow, controlnet_pose_workflow
        dummy_ckpt = self.model_combo.currentText().strip() or "dummy.safetensors"
        reports = []
        for name, workflow in [
            ("IPAdapter character reference", ipadapter_reference_workflow(checkpoint=dummy_ckpt, prompt="test", negative_prompt="", uploaded_reference_name="test.png")),
            ("ControlNet pose reference", controlnet_pose_workflow(checkpoint=dummy_ckpt, prompt="test", negative_prompt="", uploaded_pose_name="test.png")),
        ]:
            ok, missing = self.client.validate_workflow_nodes(workflow)
            if ok:
                reports.append(f"✅ {name}: required node classes are available.")
            else:
                reports.append(f"⚠️ {name}: missing {', '.join(missing)}")
        QMessageBox.information(self, "Optional Workflow Node Check", "\n\n".join(reports))

    def import_model(self):
        if not self.settings.get("comfy_path"):
            QMessageBox.warning(self, "ComfyUI folder needed", "Choose your ComfyUI folder in Settings first.")
            return
        f, _ = QFileDialog.getOpenFileName(self, "Choose checkpoint", "", "Models (*.safetensors *.ckpt *.pt)")
        if not f: return
        try:
            dest = self.client.import_model_file(self.settings.get("comfy_path"), f)
            self.log(f"Imported model: {dest}")
            self.refresh_models()
        except Exception as exc:
            QMessageBox.critical(self, "Model import failed", str(exc))

    def _selected_checkpoint(self) -> str:
        ckpt = self.model_combo.currentText().strip()
        if not ckpt or ckpt.startswith("No checkpoint"):
            raise ComfyError("No checkpoint selected. Add a .safetensors/.ckpt model to ComfyUI/models/checkpoints first.")
        return ckpt

    def _seed(self):
        text = self.seed_edit.text().strip()
        return int(text) if text.isdigit() else None

    def generate_panel(self):
        self.save_settings()
        raw_prompt = self.prompt.toPlainText().strip() or "comic panel"
        prompt = self._prompt_with_preset(raw_prompt)
        mode_text = self.mode.currentText()
        if mode_text.startswith("Image"):
            mode = "img2img"
        elif mode_text.startswith("Character"):
            mode = "ipadapter"
        elif mode_text.startswith("Pose"):
            mode = "controlnet_pose"
        else:
            mode = "txt2img"
        params = {
            "mode": mode,
            "checkpoint": self._selected_checkpoint(),
            "prompt": prompt,
            "negative_prompt": self.negative.text(),
            "out_dir": self.settings.get("output_dir"),
            "steps": self.steps_spin.value(),
            "cfg": self.cfg_spin.value(),
            "seed": self._seed(),
            "sampler": self.sampler_combo.currentText(),
            "scheduler": self.scheduler_combo.currentText(),
        }
        if mode == "txt2img":
            params["width"] = self.width_spin.value(); params["height"] = self.height_spin.value()
        elif mode == "img2img":
            ref = self.ref_path.text().strip()
            if not ref:
                QMessageBox.warning(self, "Reference needed", "Choose a reference image for Image + Text Reference mode.")
                return
            params["reference_image"] = ref; params["denoise"] = self.denoise_spin.value()
        elif mode == "ipadapter":
            ref = self.ref_path.text().strip()
            if not ref:
                QMessageBox.warning(self, "Character reference needed", "Choose a character/reference image for IPAdapter mode.")
                return
            params["reference_image"] = ref
            params["width"] = self.width_spin.value(); params["height"] = self.height_spin.value()
            params["ipadapter_model"] = self.ipadapter_model_edit.text().strip()
            params["clip_vision_model"] = self.clip_vision_model_edit.text().strip()
            params["weight"] = self.adapter_weight_spin.value()
            params["validate_nodes"] = self.validate_nodes_check.isChecked()
        elif mode == "controlnet_pose":
            ref = self.ref_path.text().strip()
            if not ref:
                QMessageBox.warning(self, "Pose reference needed", "Choose a pose/control image for ControlNet mode.")
                return
            params["pose_image"] = ref
            params["width"] = self.width_spin.value(); params["height"] = self.height_spin.value()
            params["controlnet_model"] = self.controlnet_model_edit.text().strip()
            params["strength"] = self.adapter_weight_spin.value()
            params["validate_nodes"] = self.validate_nodes_check.isChecked()
        self.log(f"Queued ComfyUI generation mode: {mode}. This may take a while...")
        self.worker = GenerationWorker(self.client, params)
        self.worker.finished_ok.connect(self._generation_done)
        self.worker.failed.connect(self._generation_failed)
        self.worker.start()

    def _generation_done(self, path: str):
        self.generated.append(path)
        self.preview.setPixmap(QPixmap(path).scaled(self.preview.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        self.log(f"Generated: {path}")

    def _generation_failed(self, error: str):
        self.log("Generation failed:\n" + error)
        QMessageBox.critical(self, "Generation failed", error.split("\n\n")[0])

    def generate_placeholder_panel(self):
        out = self.settings.get("output_dir")
        prompt = self.prompt.toPlainText().strip() or "comic panel"
        path = self.client.generate_placeholder(prompt, out)
        self.generated.append(path)
        self.preview.setPixmap(QPixmap(path).scaled(self.preview.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        self.log(f"Created placeholder: {path}")

    def save_character(self):
        self.characters.add({"name": self.char_name.text(), "notes": self.char_desc.toPlainText()})
        self.refresh_library_view()

    def save_location(self):
        self.locations.add({"name": self.loc_name.text(), "notes": self.loc_desc.toPlainText()})
        self.refresh_library_view()

    def refresh_library_view(self):
        txt = "Characters:\n" + "\n".join(f"- {c.get('name')}: {c.get('notes','')[:160]}" for c in self.characters.all())
        txt += "\n\nLocations:\n" + "\n".join(f"- {c.get('name')}: {c.get('notes','')[:160]}" for c in self.locations.all())
        if hasattr(self, "library_view"):
            self.library_view.setPlainText(txt)

    def open_continuity_tools(self):
        dlg = ContinuityDialog(self.continuity_store, self.settings, self)
        dlg.exec()

    def build_continuity_prompt(self):
        # Keep older quick notes, but prefer the richer Phase consistency profiles.
        profile_parts = [c.prompt_block() for c in self.continuity_store.characters()[-3:]]
        profile_parts += [l.prompt_block() for l in self.continuity_store.locations()[-2:]]
        legacy_parts = [c.get("name", "") + ": " + c.get("notes", "") for c in self.characters.all()[-3:]]
        legacy_parts += [l.get("name", "") + ": " + l.get("notes", "") for l in self.locations.all()[-2:]]
        parts = [p for p in profile_parts + legacy_parts if p.strip()]
        if not parts:
            QMessageBox.information(self, "No continuity saved", "Add characters/locations first, or open Character Consistency Tools.")
            return
        self.prompt.setPlainText((self.prompt.toPlainText() + "\n\nContinuity references:\n" + "\n".join(parts)).strip())

    def create_project(self):
        p = self.projects.create_project(self.project_name.text())
        QMessageBox.information(self, "Project created", str(p))

    def open_page_editor(self):
        dlg = PageEditorDialog(self.generated, self)
        dlg.exec()

    def export_pdf(self):
        if not self.generated: return
        dest = str(Path(self.settings.get("output_dir")) / "brainbender_contact_sheet.pdf")
        self.export_log.append(Exporter().export_contact_pdf(self.generated, dest))

    def export_cbz(self):
        if not self.generated: return
        dest = str(Path(self.settings.get("output_dir")) / "brainbender_comic.cbz")
        self.export_log.append(Exporter().export_cbz(self.generated, dest))
