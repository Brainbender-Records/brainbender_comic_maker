from __future__ import annotations

from PySide6.QtWidgets import *

from ..continuity import ContinuityStore


class ContinuityDialog(QDialog):
    def __init__(self, store: ContinuityStore, settings, parent=None):
        super().__init__(parent)
        self.store = store
        self.settings = settings
        self.setWindowTitle("Character Consistency Tools")
        self.resize(900, 650)
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        layout = QHBoxLayout(self)
        left = QVBoxLayout(); right = QVBoxLayout()
        layout.addLayout(left, 1); layout.addLayout(right, 2)

        self.character_list = QListWidget()
        self.character_list.currentRowChanged.connect(self.load_selected_character)
        new_char = QPushButton("New Character")
        new_char.clicked.connect(self.new_character)
        left.addWidget(QLabel("Characters")); left.addWidget(self.character_list); left.addWidget(new_char)

        self.name = QLineEdit()
        self.description = QPlainTextEdit()
        self.outfit = QPlainTextEdit()
        self.face_notes = QPlainTextEdit()
        self.personality = QPlainTextEdit()
        self.color_notes = QLineEdit()
        self.negative_notes = QLineEdit()
        self.ref_list = QListWidget()
        import_ref = QPushButton("Import Character Reference Image")
        import_ref.clicked.connect(self.import_reference)
        save = QPushButton("Save Character")
        save.clicked.connect(self.save_character)

        form = QFormLayout()
        form.addRow("Name", self.name)
        form.addRow("Description", self.description)
        form.addRow("Outfit", self.outfit)
        form.addRow("Face / hair / body notes", self.face_notes)
        form.addRow("Personality / expression guide", self.personality)
        form.addRow("Color palette", self.color_notes)
        form.addRow("Negative notes", self.negative_notes)
        right.addLayout(form)
        right.addWidget(QLabel("Reference slots")); right.addWidget(self.ref_list)
        row = QHBoxLayout(); row.addWidget(import_ref); row.addWidget(save); right.addLayout(row)

        self.location_name = QLineEdit()
        self.location_desc = QPlainTextEdit()
        save_loc = QPushButton("Save Location")
        save_loc.clicked.connect(self.save_location)
        right.addWidget(QLabel("Quick Location Memory"))
        right.addWidget(self.location_name); right.addWidget(self.location_desc); right.addWidget(save_loc)

        self.report = QTextEdit(); self.report.setReadOnly(True)
        check = QPushButton("Check ControlNet / IPAdapter Readiness")
        check.clicked.connect(self.validate)
        right.addWidget(check); right.addWidget(self.report)
        self.current_id = None
        self.current_refs = []

    def refresh(self):
        self.character_list.clear()
        self.characters = self.store.characters()
        for c in self.characters:
            self.character_list.addItem(c.name)
        self.validate()

    def new_character(self):
        c = self.store.new_character("New Character")
        self.current_id = c.id
        self.current_refs = []
        self.name.setText(c.name)
        self.description.clear(); self.outfit.clear(); self.face_notes.clear(); self.personality.clear(); self.color_notes.clear(); self.negative_notes.clear(); self.ref_list.clear()

    def load_selected_character(self, row):
        if row < 0 or row >= len(getattr(self, "characters", [])):
            return
        c = self.characters[row]
        self.current_id = c.id
        self.current_refs = c.reference_slots or []
        self.name.setText(c.name)
        self.description.setPlainText(c.description)
        self.outfit.setPlainText(c.outfit)
        self.face_notes.setPlainText(c.face_notes)
        self.personality.setPlainText(c.personality)
        self.color_notes.setText(c.color_notes)
        self.negative_notes.setText(c.negative_notes)
        self.ref_list.clear()
        for ref in self.current_refs:
            self.ref_list.addItem(f"{ref.get('kind','ref')}: {ref.get('label','')} — {ref.get('path','')}")

    def import_reference(self):
        path, _ = QFileDialog.getOpenFileName(self, "Choose character reference", "", "Images (*.png *.jpg *.jpeg *.webp)")
        if not path:
            return
        label, ok = QInputDialog.getText(self, "Reference label", "Label:", text=self.name.text() or "character reference")
        if not ok:
            return
        slot = self.store.import_reference(path, label, "character")
        self.current_refs.append(slot.__dict__)
        self.ref_list.addItem(f"{slot.kind}: {slot.label} — {slot.path}")

    def save_character(self):
        from ..continuity import CharacterProfile
        c = CharacterProfile(
            id=self.current_id or self.store.new_character(self.name.text()).id,
            name=self.name.text() or "Unnamed Character",
            description=self.description.toPlainText(),
            outfit=self.outfit.toPlainText(),
            personality=self.personality.toPlainText(),
            face_notes=self.face_notes.toPlainText(),
            color_notes=self.color_notes.text(),
            negative_notes=self.negative_notes.text(),
            reference_slots=self.current_refs,
        )
        self.store.upsert_character(c)
        self.refresh()

    def save_location(self):
        loc = self.store.new_location(self.location_name.text())
        loc.description = self.location_desc.toPlainText()
        self.store.upsert_location(loc)
        QMessageBox.information(self, "Saved", "Location memory saved.")

    def validate(self):
        self.report.setPlainText(self.store.validation_report(self.settings.get("comfy_path")))
