from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import QDialog, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton, QTextEdit, QVBoxLayout

from ..comfy.installer import ComfyInstaller
from ..core.settings import Settings


class InstallerWorker(QThread):
    log_line = Signal(str)
    finished_result = Signal(bool, str, str)

    def __init__(self, target_dir: str):
        super().__init__()
        self.target_dir = target_dir

    def run(self):
        installer = ComfyInstaller(self.target_dir, log=lambda m: self.log_line.emit(m))
        result = installer.install_or_update()
        self.finished_result.emit(result.ok, result.path, result.message)


class ComfyInstallerDialog(QDialog):
    def __init__(self, settings: Settings, parent=None):
        super().__init__(parent)
        self.settings = settings
        self.worker = None
        self.setWindowTitle('Install or Update ComfyUI')
        self.resize(760, 520)

        layout = QVBoxLayout(self)
        intro = QLabel(
            'This helper installs ComfyUI into a normal folder on your computer.\n'
            'Models are not bundled because they are very large; after install, use the model import button to add a .safetensors or .ckpt checkpoint.'
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        row = QHBoxLayout()
        self.path = QLineEdit(settings.get('comfy_path') or str(Path.home() / 'ComfyUI'))
        browse = QPushButton('Browse')
        browse.clicked.connect(self.browse)
        row.addWidget(QLabel('Install folder:'))
        row.addWidget(self.path, 1)
        row.addWidget(browse)
        layout.addLayout(row)

        button_row = QHBoxLayout()
        self.install_btn = QPushButton('Install / Update ComfyUI')
        self.install_btn.clicked.connect(self.start_install)
        close = QPushButton('Close')
        close.clicked.connect(self.accept)
        button_row.addWidget(self.install_btn)
        button_row.addWidget(close)
        layout.addLayout(button_row)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        layout.addWidget(self.log, 1)

    def browse(self):
        d = QFileDialog.getExistingDirectory(self, 'Choose install folder or parent folder', str(Path.home()))
        if d:
            p = Path(d)
            if p.name.lower() != 'comfyui' and not (p / 'main.py').exists():
                p = p / 'ComfyUI'
            self.path.setText(str(p))

    def start_install(self):
        target = self.path.text().strip()
        if not target:
            QMessageBox.warning(self, 'Folder needed', 'Choose an install folder first.')
            return
        self.install_btn.setEnabled(False)
        self.log.append('Starting ComfyUI install/update...')
        self.worker = InstallerWorker(target)
        self.worker.log_line.connect(self.log.append)
        self.worker.finished_result.connect(self.finished)
        self.worker.start()

    def finished(self, ok: bool, path: str, message: str):
        self.install_btn.setEnabled(True)
        self.log.append('\n' + message)
        if ok:
            self.settings.set('comfy_path', path)
            self.settings.set('comfy_url', self.settings.get('comfy_url') or 'http://127.0.0.1:8188')
            QMessageBox.information(self, 'ComfyUI ready', f'{message}\n\nSaved path:\n{path}')
        else:
            QMessageBox.critical(self, 'Install failed', message)
