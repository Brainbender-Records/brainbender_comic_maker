import os, sys
from PySide6.QtWidgets import QApplication
from .ui.main_window import MainWindow


def main():
    os.environ.setdefault('QT_QUICK_BACKEND', 'software')
    app = QApplication(sys.argv)
    app.setApplicationName('Brainbender Comic Maker')
    win = MainWindow()
    win.resize(1280, 820)
    win.show()
    sys.exit(app.exec())
