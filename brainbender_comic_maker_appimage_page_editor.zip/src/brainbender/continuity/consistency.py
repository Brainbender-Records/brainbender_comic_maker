from __future__ import annotations

import json
import shutil
import uuid
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List

from ..core.paths import APP_DIR

CONTINUITY_DIR = APP_DIR / "continuity"
CHARACTER_FILE = CONTINUITY_DIR / "characters.json"
LOCATION_FILE = CONTINUITY_DIR / "locations.json"
REFERENCE_DIR = CONTINUITY_DIR / "references"


@dataclass
class ReferenceSlot:
    id: str
    label: str
    kind: str = "character"  # character, pose, outfit, location, prop
    path: str = ""
    notes: str = ""


@dataclass
class CharacterProfile:
    id: str
    name: str
    description: str = ""
    outfit: str = ""
    personality: str = ""
    face_notes: str = ""
    color_notes: str = ""
    negative_notes: str = ""
    reference_slots: List[Dict[str, Any]] | None = None

    def __post_init__(self):
        if self.reference_slots is None:
            self.reference_slots = []

    def prompt_block(self) -> str:
        parts = [
            f"Recurring character: {self.name}",
            self.description,
            f"Outfit: {self.outfit}" if self.outfit else "",
            f"Personality/expression guide: {self.personality}" if self.personality else "",
            f"Face/hair/body notes: {self.face_notes}" if self.face_notes else "",
            f"Color palette: {self.color_notes}" if self.color_notes else "",
        ]
        return ", ".join([p.strip() for p in parts if p and p.strip()])


@dataclass
class LocationProfile:
    id: str
    name: str
    description: str = ""
    mood: str = ""
    lighting: str = ""
    palette: str = ""

    def prompt_block(self) -> str:
        parts = [
            f"Recurring location: {self.name}",
            self.description,
            f"Mood: {self.mood}" if self.mood else "",
            f"Lighting: {self.lighting}" if self.lighting else "",
            f"Color palette: {self.palette}" if self.palette else "",
        ]
        return ", ".join([p.strip() for p in parts if p and p.strip()])


class ContinuityStore:
    def __init__(self):
        CONTINUITY_DIR.mkdir(parents=True, exist_ok=True)
        REFERENCE_DIR.mkdir(parents=True, exist_ok=True)
        for file in (CHARACTER_FILE, LOCATION_FILE):
            if not file.exists():
                file.write_text("[]")

    def _load(self, path: Path) -> list[dict]:
        try:
            return json.loads(path.read_text())
        except Exception:
            return []

    def _save(self, path: Path, items: list[dict]) -> None:
        path.write_text(json.dumps(items, indent=2))

    def characters(self) -> list[CharacterProfile]:
        return [CharacterProfile(**item) for item in self._load(CHARACTER_FILE)]

    def locations(self) -> list[LocationProfile]:
        return [LocationProfile(**item) for item in self._load(LOCATION_FILE)]

    def upsert_character(self, profile: CharacterProfile) -> None:
        items = [asdict(p) for p in self.characters() if p.id != profile.id]
        items.append(asdict(profile))
        self._save(CHARACTER_FILE, items)

    def upsert_location(self, profile: LocationProfile) -> None:
        items = [asdict(p) for p in self.locations() if p.id != profile.id]
        items.append(asdict(profile))
        self._save(LOCATION_FILE, items)

    def new_character(self, name: str) -> CharacterProfile:
        return CharacterProfile(id=str(uuid.uuid4()), name=name.strip() or "Unnamed Character")

    def new_location(self, name: str) -> LocationProfile:
        return LocationProfile(id=str(uuid.uuid4()), name=name.strip() or "Unnamed Location")

    def import_reference(self, source: str, label: str, kind: str = "character", notes: str = "") -> ReferenceSlot:
        src = Path(source)
        if not src.exists():
            raise FileNotFoundError(source)
        slot_id = str(uuid.uuid4())
        ext = src.suffix.lower() or ".png"
        dest = REFERENCE_DIR / f"{slot_id}{ext}"
        shutil.copy2(src, dest)
        return ReferenceSlot(id=slot_id, label=label or src.stem, kind=kind, path=str(dest), notes=notes)

    def build_prompt(self, character_ids: list[str], location_id: str | None, shot: str, pose: str, style: str, scene_notes: str) -> str:
        chars = {c.id: c for c in self.characters()}
        locs = {l.id: l for l in self.locations()}
        blocks = []
        for cid in character_ids:
            if cid in chars:
                blocks.append(chars[cid].prompt_block())
        if location_id and location_id in locs:
            blocks.append(locs[location_id].prompt_block())
        for label, value in [("Shot", shot), ("Pose/action", pose), ("Comic style", style), ("Scene continuity", scene_notes)]:
            if value.strip():
                blocks.append(f"{label}: {value.strip()}")
        return "\n".join(blocks)

    def validation_report(self, comfy_path: str | None) -> str:
        lines = ["Character consistency readiness check:"]
        if not comfy_path:
            lines.append("❌ ComfyUI folder is not configured.")
            return "\n".join(lines)
        root = Path(comfy_path)
        custom_nodes = root / "custom_nodes"
        controlnet_models = root / "models" / "controlnet"
        clip_vision = root / "models" / "clip_vision"
        ipadapter = root / "models" / "ipadapter"
        checks = [
            (root / "main.py", "ComfyUI main.py"),
            (custom_nodes, "custom_nodes folder"),
            (controlnet_models, "ControlNet models folder"),
            (clip_vision, "CLIP Vision folder for IPAdapter"),
            (ipadapter, "IPAdapter models folder"),
        ]
        for path, label in checks:
            lines.append(("✅" if path.exists() else "⚠️") + f" {label}: {path}")
        lines.append("")
        lines.append("Note: this step adds validation and prompt/reference management. Actual ControlNet/IPAdapter node graph execution is the next wiring task after the required ComfyUI custom nodes/models are installed.")
        return "\n".join(lines)
