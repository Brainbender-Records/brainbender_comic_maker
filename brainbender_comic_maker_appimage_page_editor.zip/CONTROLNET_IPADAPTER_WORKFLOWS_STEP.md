# Next Step Completed: ControlNet / IPAdapter Workflow Wiring

This update adds the first real wiring layer for advanced comic consistency workflows.

## Added

- IPAdapter-style character/reference workflow template
- ControlNet pose/reference workflow template
- Optional-node validation using ComfyUI `/object_info`
- New Studio generation modes:
  - Text to Image
  - Image + Text Reference
  - Character Reference (IPAdapter)
  - Pose Reference (ControlNet)
- UI fields for:
  - IPAdapter model filename
  - CLIP Vision model filename
  - ControlNet model filename
  - Reference/control strength
  - Validate optional nodes before generation
- Settings button: **Check Optional Workflow Nodes**

## Important

These workflows require matching ComfyUI custom nodes and model files. The app now detects missing node classes and explains what is unavailable instead of failing silently.

Common folders:

```text
~/ComfyUI/models/ipadapter/
~/ComfyUI/models/clip_vision/
~/ComfyUI/models/controlnet/
~/ComfyUI/custom_nodes/
```

## Recommended next step

Add a guided dependency installer that helps users install the common ComfyUI custom node packs used for comic consistency, such as IPAdapter and ControlNet/Aux preprocessors.

