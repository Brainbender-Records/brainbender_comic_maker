#!/usr/bin/env bash
set -e
sudo apt update
sudo apt install -y python3 python3-venv python3-pip libxcb-cursor0 libegl1 libopengl0 fuse
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -e .
mkdir -p "$HOME/.local/share/applications"
cat > "$HOME/.local/share/applications/brainbender-comic-maker.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Brainbender Comic Maker
Comment=AI comic maker frontend for ComfyUI
Exec=$(pwd)/start.sh
Icon=$(pwd)/assets/brainbender-comic-maker.png
Terminal=false
Categories=Graphics;AudioVideo;
DESKTOP
chmod +x start.sh
update-desktop-database "$HOME/.local/share/applications" || true
echo "Installed. Run ./start.sh or launch Brainbender Comic Maker from your app menu."
