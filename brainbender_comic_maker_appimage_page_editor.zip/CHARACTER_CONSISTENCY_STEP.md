# Character Consistency Step

This upgrade adds the first real consistency layer for Brainbender Comic Maker.

## Added

- Character Consistency Tools dialog
- Rich character profiles:
  - description
  - outfit
  - face/hair/body notes
  - personality/expression notes
  - color palette
  - negative notes
- Character reference image import slots
- Recurring location memory
- Continuity prompt builder using saved character/location profiles
- ControlNet/IPAdapter readiness validation

## Important

This step does **not** yet execute a full ControlNet or IPAdapter ComfyUI graph. It prepares the app for that by managing reference material and checking whether the expected folders/custom-node environment exists.

Next wiring step:

1. Add a ControlNet/OpenPose workflow JSON.
2. Add an IPAdapter character reference workflow JSON.
3. Detect required ComfyUI custom nodes.
4. Send selected character reference image paths into those workflows.
5. Return generated panels into the same Brainbender history/gallery.
