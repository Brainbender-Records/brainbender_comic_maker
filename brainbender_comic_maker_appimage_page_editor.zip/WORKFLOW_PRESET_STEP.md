# Workflow Preset Manager Step

This update adds a comic-focused workflow preset layer for Brainbender Comic Maker.

## Added

- Workflow Preset Manager window
- Default presets for:
  - SD 1.5 Comic Panel
  - SDXL Comic Splash Page
  - Wide Establishing Shot
  - Close-Up Reaction Panel
  - Img2Img Character Continuity
  - Future ControlNet Pose Slot
  - Future IPAdapter Character Slot
- Preset fields for:
  - width / height
  - steps
  - CFG
  - sampler
  - scheduler
  - img2img denoise
  - prompt prefix / suffix
  - negative prompt
  - notes
- Presets are saved in the user config folder as `workflow_presets.json`.

## Important

The ControlNet and IPAdapter presets are metadata placeholders right now. They prepare the UI and project structure for those workflows, but the actual custom-node workflows still need to be added after the required ComfyUI nodes and model paths are known.

## Next step

Add a character consistency workflow module that supports:

1. Character profile images
2. Pose/reference image slots
3. IPAdapter/ControlNet workflow templates
4. Validation for required ComfyUI custom nodes
5. Clear install guidance when nodes or models are missing
