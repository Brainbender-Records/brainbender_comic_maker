from pathlib import Path
import json

APP_DIR = Path.home() / '.brainbender-comic-maker'
SETTINGS_FILE = APP_DIR / 'settings.json'
HISTORY_DIR = APP_DIR / 'history'
OUTPUT_DIR = APP_DIR / 'outputs'
INPUT_DIR = APP_DIR / 'inputs'

DEFAULT_SETTINGS = {
    'comfy_url': 'http://127.0.0.1:8188',
    'comfy_path': '',
    'python_command': 'python3',
    'last_checkpoint': '',
    'output_dir': str(OUTPUT_DIR),
}

def ensure_dirs():
    for p in [APP_DIR, HISTORY_DIR, OUTPUT_DIR, INPUT_DIR]:
        p.mkdir(parents=True, exist_ok=True)

def load_settings():
    ensure_dirs()
    if SETTINGS_FILE.exists():
        try:
            data = json.loads(SETTINGS_FILE.read_text())
            return {**DEFAULT_SETTINGS, **data}
        except Exception:
            return DEFAULT_SETTINGS.copy()
    save_settings(DEFAULT_SETTINGS.copy())
    return DEFAULT_SETTINGS.copy()

def save_settings(settings):
    ensure_dirs()
    SETTINGS_FILE.write_text(json.dumps(settings, indent=2))
