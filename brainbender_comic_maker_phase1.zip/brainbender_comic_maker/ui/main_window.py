from pathlib import Path
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QTextEdit,
    QPushButton, QFileDialog, QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox,
    QListWidget, QListWidgetItem, QMessageBox, QTabWidget, QGroupBox, QCheckBox
)
from PySide6.QtCore import Qt, QThread
from PySide6.QtGui import QPixmap

from ..core.paths import load_settings, save_settings, OUTPUT_DIR
from ..core.comfy_manager import ComfyManager
from ..core.comfy_client import ComfyClient
from ..core.model_manager import ModelManager
from ..core.history import HistoryStore
from .worker import GenerateWorker

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Brainbender Comic Maker - ComfyUI Comic Frontend')
        self.settings = load_settings()
        self.ref_image = ''
        self.history = HistoryStore()
        self.thread = None
        self.worker = None
        self._build_ui()
        self.refresh_models()
        self.refresh_history()
        self.check_comfy_startup()

    def _build_ui(self):
        tabs = QTabWidget()
        tabs.addTab(self._generation_tab(), 'Generate')
        tabs.addTab(self._settings_tab(), 'Settings / Models')
        tabs.addTab(self._history_tab(), 'History')
        self.setCentralWidget(tabs)
        self.statusBar().showMessage('Ready')

    def _generation_tab(self):
        root = QWidget(); layout = QHBoxLayout(root)
        left = QVBoxLayout(); right = QVBoxLayout()
        layout.addLayout(left, 2); layout.addLayout(right, 1)

        comic_box = QGroupBox('Comic Panel Context')
        cg = QGridLayout(comic_box)
        self.character = QLineEdit(); self.character.setPlaceholderText('Example: Detective Jonah, black suit, tired eyes')
        self.scene = QLineEdit(); self.scene.setPlaceholderText('Example: rainy alley outside a neon diner')
        self.panel_type = QComboBox(); self.panel_type.addItems(['Establishing shot','Close-up reaction','Action panel','Dialogue panel','Splash panel','Object insert'])
        self.style = QLineEdit(); self.style.setPlaceholderText('Example: graphic novel, clean ink lines, cinematic lighting')
        cg.addWidget(QLabel('Character'),0,0); cg.addWidget(self.character,0,1)
        cg.addWidget(QLabel('Scene'),1,0); cg.addWidget(self.scene,1,1)
        cg.addWidget(QLabel('Panel Type'),2,0); cg.addWidget(self.panel_type,2,1)
        cg.addWidget(QLabel('Style'),3,0); cg.addWidget(self.style,3,1)
        left.addWidget(comic_box)

        self.prompt = QTextEdit(); self.prompt.setPlaceholderText('Describe the comic panel you want...')
        self.negative = QTextEdit(); self.negative.setPlaceholderText('Negative prompt: blurry, bad hands, text artifacts, watermark...')
        self.negative.setMaximumHeight(80)
        left.addWidget(QLabel('Prompt'))
        left.addWidget(self.prompt)
        left.addWidget(QLabel('Negative Prompt'))
        left.addWidget(self.negative)

        opts = QGridLayout()
        self.mode_img2img = QCheckBox('Use reference image / img2img')
        self.ref_label = QLabel('No reference image selected')
        choose_ref = QPushButton('Choose Reference Image')
        choose_ref.clicked.connect(self.choose_reference)
        self.width = QSpinBox(); self.width.setRange(256, 2048); self.width.setSingleStep(64); self.width.setValue(768)
        self.height = QSpinBox(); self.height.setRange(256, 2048); self.height.setSingleStep(64); self.height.setValue(768)
        self.steps = QSpinBox(); self.steps.setRange(1, 150); self.steps.setValue(25)
        self.cfg = QDoubleSpinBox(); self.cfg.setRange(1, 30); self.cfg.setValue(7.0); self.cfg.setSingleStep(.5)
        self.denoise = QDoubleSpinBox(); self.denoise.setRange(0.05, 1.0); self.denoise.setValue(.55); self.denoise.setSingleStep(.05)
        self.seed = QLineEdit(); self.seed.setPlaceholderText('blank = random')
        self.checkpoint = QComboBox()
        opts.addWidget(self.mode_img2img,0,0,1,2); opts.addWidget(choose_ref,1,0); opts.addWidget(self.ref_label,1,1)
        opts.addWidget(QLabel('Checkpoint'),2,0); opts.addWidget(self.checkpoint,2,1)
        opts.addWidget(QLabel('Width'),3,0); opts.addWidget(self.width,3,1)
        opts.addWidget(QLabel('Height'),4,0); opts.addWidget(self.height,4,1)
        opts.addWidget(QLabel('Steps'),5,0); opts.addWidget(self.steps,5,1)
        opts.addWidget(QLabel('CFG'),6,0); opts.addWidget(self.cfg,6,1)
        opts.addWidget(QLabel('Img2Img Strength'),7,0); opts.addWidget(self.denoise,7,1)
        opts.addWidget(QLabel('Seed'),8,0); opts.addWidget(self.seed,8,1)
        left.addLayout(opts)

        self.generate_btn = QPushButton('Generate Comic Panel')
        self.generate_btn.clicked.connect(self.generate)
        left.addWidget(self.generate_btn)

        self.preview = QLabel('Generated image preview')
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setMinimumSize(420, 420)
        self.preview.setStyleSheet('border: 1px solid #777; background: #202020; color: #ddd;')
        right.addWidget(self.preview)
        self.last_meta = QLabel('No generation yet')
        self.last_meta.setWordWrap(True)
        right.addWidget(self.last_meta)
        return root

    def _settings_tab(self):
        root = QWidget(); layout = QVBoxLayout(root)
        self.comfy_url = QLineEdit(self.settings.get('comfy_url','http://127.0.0.1:8188'))
        self.comfy_path = QLineEdit(self.settings.get('comfy_path',''))
        self.python_cmd = QLineEdit(self.settings.get('python_command','python3'))
        browse = QPushButton('Choose ComfyUI Folder')
        browse.clicked.connect(self.choose_comfy_folder)
        save = QPushButton('Save Settings')
        save.clicked.connect(self.save_settings_clicked)
        start = QPushButton('Start / Check ComfyUI')
        start.clicked.connect(self.start_comfy_clicked)
        import_model = QPushButton('Import Local Model File')
        import_model.clicked.connect(self.import_model_clicked)
        refresh = QPushButton('Refresh Models')
        refresh.clicked.connect(self.refresh_models)
        layout.addWidget(QLabel('ComfyUI URL')); layout.addWidget(self.comfy_url)
        layout.addWidget(QLabel('ComfyUI Folder')); layout.addWidget(self.comfy_path); layout.addWidget(browse)
        layout.addWidget(QLabel('Python Command')); layout.addWidget(self.python_cmd)
        layout.addWidget(save); layout.addWidget(start); layout.addWidget(import_model); layout.addWidget(refresh)
        self.models_label = QLabel('Models:')
        layout.addWidget(self.models_label)
        layout.addStretch(1)
        return root

    def _history_tab(self):
        root = QWidget(); layout = QHBoxLayout(root)
        self.history_list = QListWidget(); self.history_list.currentItemChanged.connect(self.show_history_item)
        self.history_preview = QLabel('Select a history item')
        self.history_preview.setAlignment(Qt.AlignCenter); self.history_preview.setMinimumSize(500,500)
        self.history_preview.setStyleSheet('border: 1px solid #777;')
        layout.addWidget(self.history_list,1); layout.addWidget(self.history_preview,2)
        return root

    def manager(self):
        self.settings = load_settings()
        return ComfyManager(self.settings['comfy_url'], self.settings['comfy_path'], self.settings['python_command'])

    def check_comfy_startup(self):
        m = self.manager()
        if not m.is_running() and self.settings.get('comfy_path'):
            ok, msg = m.start()
            self.statusBar().showMessage(msg)
        elif m.is_running():
            self.statusBar().showMessage('ComfyUI connected.')
        else:
            self.statusBar().showMessage('Set your ComfyUI folder in Settings to enable auto-start.')

    def choose_reference(self):
        fp, _ = QFileDialog.getOpenFileName(self, 'Choose reference image', str(Path.home()), 'Images (*.png *.jpg *.jpeg *.webp)')
        if fp:
            self.ref_image = fp; self.ref_label.setText(Path(fp).name); self.mode_img2img.setChecked(True)

    def choose_comfy_folder(self):
        d = QFileDialog.getExistingDirectory(self, 'Choose ComfyUI folder', str(Path.home()))
        if d: self.comfy_path.setText(d)

    def save_settings_clicked(self):
        self.settings['comfy_url'] = self.comfy_url.text().strip()
        self.settings['comfy_path'] = self.comfy_path.text().strip()
        self.settings['python_command'] = self.python_cmd.text().strip() or 'python3'
        save_settings(self.settings); self.refresh_models(); QMessageBox.information(self, 'Saved', 'Settings saved.')

    def start_comfy_clicked(self):
        self.save_settings_clicked()
        ok, msg = self.manager().start()
        QMessageBox.information(self, 'ComfyUI', msg) if ok else QMessageBox.warning(self, 'ComfyUI', msg)

    def refresh_models(self):
        m = self.manager()
        models = m.list_checkpoints()
        self.checkpoint.clear(); self.checkpoint.addItems(models)
        self.models_label.setText('Models detected:\n' + ('\n'.join(models) if models else 'No checkpoints found. Put models in ComfyUI/models/checkpoints/'))

    def import_model_clicked(self):
        fp, _ = QFileDialog.getOpenFileName(self, 'Choose model file', str(Path.home()), 'Models (*.safetensors *.ckpt *.pt *.pth)')
        if not fp: return
        try:
            mm = ModelManager(self.manager().model_dir())
            dest = mm.import_model(fp)
            self.refresh_models()
            QMessageBox.information(self, 'Model Imported', f'Imported to {dest}')
        except Exception as e:
            QMessageBox.warning(self, 'Import failed', str(e))

    def build_prompt(self):
        parts = [self.prompt.toPlainText().strip()]
        if self.character.text().strip(): parts.append('Character: ' + self.character.text().strip())
        if self.scene.text().strip(): parts.append('Scene: ' + self.scene.text().strip())
        parts.append('Panel type: ' + self.panel_type.currentText())
        if self.style.text().strip(): parts.append('Style: ' + self.style.text().strip())
        parts.append('comic panel, professional sequential art, clear composition')
        return ', '.join([p for p in parts if p])

    def generate(self):
        if not self.manager().is_running():
            ok, msg = self.manager().start()
            if not ok:
                QMessageBox.warning(self, 'ComfyUI not running', msg); return
        prompt = self.build_prompt()
        if not prompt.strip():
            QMessageBox.warning(self, 'Prompt required', 'Enter a prompt first.'); return
        mode = 'img2img' if self.mode_img2img.isChecked() else 'txt2img'
        if mode == 'img2img' and not self.ref_image:
            QMessageBox.warning(self, 'Reference required', 'Choose a reference image or uncheck img2img.'); return
        common = dict(prompt=prompt, negative=self.negative.toPlainText().strip(), checkpoint=self.checkpoint.currentText(), width=self.width.value(), height=self.height.value(), steps=self.steps.value(), cfg=self.cfg.value(), seed=self.seed.text().strip(), dest_dir=str(OUTPUT_DIR))
        args = dict(common)
        if mode == 'img2img':
            args['image_path'] = self.ref_image; args['denoise'] = self.denoise.value()
        metadata = {k: v for k, v in common.items() if k != 'dest_dir'}
        metadata.update({'mode': mode, 'character': self.character.text(), 'scene': self.scene.text(), 'panel_type': self.panel_type.currentText(), 'style': self.style.text(), 'reference_image': self.ref_image})
        self.generate_btn.setEnabled(False); self.statusBar().showMessage('Generating...')
        self.thread = QThread(); self.worker = GenerateWorker(ComfyClient(self.settings['comfy_url']), mode, args, metadata, self.history)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.generation_done)
        self.worker.error.connect(self.generation_error)
        self.worker.status.connect(self.statusBar().showMessage)
        self.worker.finished.connect(self.thread.quit); self.worker.error.connect(self.thread.quit)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()

    def generation_done(self, image, meta):
        self.generate_btn.setEnabled(True); self.statusBar().showMessage('Generation complete.')
        self.set_preview(self.preview, image)
        self.last_meta.setText(f"Saved: {image}\nSeed: {meta.get('seed')}\nMode: {meta.get('mode')}")
        self.refresh_history()

    def generation_error(self, message):
        self.generate_btn.setEnabled(True); self.statusBar().showMessage('Generation failed.')
        QMessageBox.warning(self, 'Generation failed', message)

    def refresh_history(self):
        if not hasattr(self, 'history_list'): return
        self.history_list.clear()
        for item in self.history.list_items():
            li = QListWidgetItem(f"{item.get('created_at','')} | {item.get('mode','')} | seed {item.get('seed','')}")
            li.setData(Qt.UserRole, item)
            self.history_list.addItem(li)

    def show_history_item(self, current, previous):
        if not current: return
        item = current.data(Qt.UserRole)
        self.set_preview(self.history_preview, item.get('image',''))

    def set_preview(self, label, image_path):
        pix = QPixmap(image_path)
        if pix.isNull():
            label.setText('Could not load image'); return
        label.setPixmap(pix.scaled(label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
