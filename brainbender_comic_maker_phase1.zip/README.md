# Brainbender Comic Maker

Brainbender Comic Maker is a Linux desktop frontend for ComfyUI designed for comic panel generation.

## What Phase 1 includes

- PySide6 desktop GUI
- ComfyUI connection check
- Auto-start ComfyUI if a local ComfyUI folder is configured
- Model/checkpoint detection
- Import local `.safetensors`, `.ckpt`, `.pt`, or `.pth` model files
- Text-to-image generation through ComfyUI
- Image-to-image/reference image generation through ComfyUI
- Comic-specific prompt fields: character, scene, panel type, style
- Image preview
- Generation history with metadata saved in `~/.brainbender-comic-maker`
- Ubuntu installer script
- Snap starter config

## Requirements

You need Ubuntu and Python 3. You also need ComfyUI installed locally.

ComfyUI official repo:

```bash
git clone https://github.com/comfyanonymous/ComfyUI.git
cd ComfyUI
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python main.py
```

Then open:

```text
http://127.0.0.1:8188
```

## Installing Brainbender Comic Maker

From the extracted folder:

```bash
./install_ubuntu.sh
```

## Starting Brainbender Comic Maker

```bash
source .venv/bin/activate
python run.py
```

or:

```bash
./start.sh
```

## First setup inside Brainbender Comic Maker

1. Open the **Settings / Models** tab.
2. Set the ComfyUI folder, for example:

```text
/home/YOUR_USERNAME/ComfyUI
```

3. Click **Save Settings**.
4. Click **Start / Check ComfyUI**.
5. Put at least one Stable Diffusion checkpoint in:

```text
ComfyUI/models/checkpoints/
```

or use **Import Local Model File**.

## Notes

This app does not include a Stable Diffusion model. Models are large and have their own licenses. Brainbender Comic Maker detects and uses models installed in ComfyUI.

This is Phase 1 code. Later phases should add character libraries, page layout, speech bubbles, PDF/CBZ export, and polished Snap packaging.
