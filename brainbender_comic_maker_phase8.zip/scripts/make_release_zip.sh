#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
VERSION=$(python3 - <<'PY'
import re
text=open('pyproject.toml').read()
print(re.search(r'version = "([^"]+)"', text).group(1))
PY
)
OUT="../brainbender_comic_maker_v${VERSION}.zip"
python3 scripts/check_release.py
rm -f "$OUT"
zip -r "$OUT" . -x "*.venv*" "__pycache__/*" "*.pyc" ".git/*" "*.snap"
echo "Created $OUT"
