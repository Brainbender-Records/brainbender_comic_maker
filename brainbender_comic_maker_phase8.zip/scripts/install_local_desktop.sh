#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
DESKTOP_DIR="$HOME/.local/share/applications"
BIN_DIR="$HOME/.local/bin"
ICON_DIR="$HOME/.local/share/icons/hicolor/scalable/apps"
mkdir -p "$DESKTOP_DIR" "$BIN_DIR" "$ICON_DIR"
cp "$APP_DIR/snap/gui/brainbender-comic-maker.svg" "$ICON_DIR/brainbender-comic-maker.svg"
cat > "$BIN_DIR/brainbender-comic-maker" <<LAUNCHER
#!/usr/bin/env bash
cd "$APP_DIR"
if [ -d .venv ]; then
  source .venv/bin/activate
fi
python3 run.py
LAUNCHER
chmod +x "$BIN_DIR/brainbender-comic-maker"
sed "s|Icon=.*|Icon=brainbender-comic-maker|; s|Exec=.*|Exec=$BIN_DIR/brainbender-comic-maker|" "$APP_DIR/brainbender-comic-maker.desktop" > "$DESKTOP_DIR/brainbender-comic-maker.desktop"
chmod +x "$DESKTOP_DIR/brainbender-comic-maker.desktop"
update-desktop-database "$DESKTOP_DIR" >/dev/null 2>&1 || true
echo "Installed desktop launcher. Look for 'Brainbender Comic Maker' in your app menu."
