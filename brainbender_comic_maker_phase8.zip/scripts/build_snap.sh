#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v snapcraft >/dev/null || { echo "Install snapcraft first: sudo snap install snapcraft --classic"; exit 1; }
snapcraft clean || true
snapcraft
