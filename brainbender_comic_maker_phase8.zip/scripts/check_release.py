#!/usr/bin/env python3
from pathlib import Path
required = [
    "pyproject.toml", "LICENSE", "README.md", "run.py", "requirements.txt",
    "snap/snapcraft.yaml", "snap/gui/brainbender-comic-maker.desktop",
    "snap/gui/brainbender-comic-maker.svg",
    "scripts/build_snap.sh", "scripts/install_local_desktop.sh",
]
missing = [p for p in required if not Path(p).exists()]
if missing:
    print("Missing release files:")
    for p in missing:
        print(" -", p)
    raise SystemExit(1)
print("Release check passed: all required packaging files exist.")
