# Phase 8 Release Notes

Phase 8 turns Brainbender Comic Maker into a distributable Ubuntu application.

## Added

- `pyproject.toml` with a real console entry point: `brainbender-comic-maker`
- MIT license file
- Finished Snap starter with desktop launcher and icon
- Local desktop launcher installer
- Snap build script
- Release zip script
- Release validation script
- GitHub-ready `.gitignore`
- GitHub Actions workflow scaffold

## Local desktop install

```bash
./install_ubuntu.sh
./scripts/install_local_desktop.sh
```

Then open **Brainbender Comic Maker** from the Ubuntu application menu.

## Build Snap

```bash
sudo snap install snapcraft --classic
./scripts/build_snap.sh
```

Install the local snap:

```bash
sudo snap install brainbender-comic-maker_0.8.0_amd64.snap --dangerous --classic
```

## Release zip

```bash
./scripts/make_release_zip.sh
```
