# Brainbender Comic Maker — Phase 8

Free/open Ubuntu comic-making frontend for ComfyUI and Stable Diffusion.

Phase 8 adds the release/distribution layer: Snap packaging, desktop launcher files, build scripts, release validation, GitHub metadata, and local app-menu installation.

## Features through Phase 8

- ComfyUI detection and optional auto-start
- Model manager and local checkpoint detection
- Text-to-image and image-to-image panel generation
- Character, style, template, and continuity tools
- Comic projects with chapters, pages, and panels
- Visual page layout editor
- Speech bubbles, captions, and SFX lettering
- PDF, CBZ, and PNG export
- Snap packaging starter
- Ubuntu app-menu launcher installer

## Run on Ubuntu

```bash
cd ~/Downloads
unzip brainbender_comic_maker_phase8.zip -d brainbender_comic_maker_phase8
cd brainbender_comic_maker_phase8
./install_ubuntu.sh
./start.sh
```

## Install into Ubuntu app menu

```bash
./scripts/install_local_desktop.sh
```

Then search for **Brainbender Comic Maker** in your applications menu.

## Build a Snap package

```bash
sudo snap install snapcraft --classic
./scripts/build_snap.sh
```

Install the generated local snap with:

```bash
sudo snap install brainbender-comic-maker_0.8.0_amd64.snap --dangerous --classic
```

## Release check

```bash
python3 scripts/check_release.py
```

## Important note

This is still an alpha application. The package provides real source files and release scaffolding, but you should test generation workflows with your local ComfyUI setup before sharing a release publicly.
