from __future__ import annotations
from pathlib import Path
from PySide6.QtCore import Qt, QRectF, QPointF, Signal
from PySide6.QtGui import QPainter, QPen, QBrush, QPixmap, QColor, QAction, QImage
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QComboBox, QFileDialog,
    QListWidget, QListWidgetItem, QMessageBox, QGraphicsView, QGraphicsScene,
    QGraphicsRectItem, QGraphicsPixmapItem, QGraphicsSimpleTextItem, QInputDialog
)

PAGE_W = 850
PAGE_H = 1100

TEMPLATES = {
    '1 Panel Splash': [(40, 40, 770, 1020)],
    '2 Panels Vertical': [(40, 40, 770, 500), (40, 560, 770, 500)],
    '3 Panels Stack': [(40, 40, 770, 320), (40, 390, 770, 320), (40, 740, 770, 320)],
    '4 Panel Grid': [(40, 40, 370, 500), (440, 40, 370, 500), (40, 570, 370, 490), (440, 570, 370, 490)],
    '6 Panel Grid': [(40, 40, 240, 320), (305, 40, 240, 320), (570, 40, 240, 320), (40, 390, 240, 320), (305, 390, 240, 320), (570, 390, 240, 320)],
    'Manga Strip': [(40, 40, 770, 230), (40, 300, 770, 230), (40, 560, 770, 230), (40, 820, 770, 240)],
}

class PanelRectItem(QGraphicsRectItem):
    def __init__(self, panel: dict):
        super().__init__(0, 0, panel.get('w', 300), panel.get('h', 220))
        self.panel = panel
        self.setPos(panel.get('x', 40), panel.get('y', 40))
        self.setFlags(
            QGraphicsRectItem.ItemIsMovable |
            QGraphicsRectItem.ItemIsSelectable |
            QGraphicsRectItem.ItemSendsGeometryChanges
        )
        self.setPen(QPen(QColor('#111111'), 4))
        self.setBrush(QBrush(QColor(255, 255, 255, 20)))
        self.image_item = None
        self.label_item = QGraphicsSimpleTextItem(panel.get('title', 'Panel'), self)
        self.label_item.setBrush(QBrush(QColor('#111111')))
        self.label_item.setPos(8, 8)
        self._load_image()

    def _load_image(self):
        image_path = self.panel.get('image', '')
        if not image_path or not Path(image_path).exists():
            return
        pix = QPixmap(image_path)
        if pix.isNull():
            return
        scaled = pix.scaled(int(self.rect().width()), int(self.rect().height()), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        self.image_item = QGraphicsPixmapItem(scaled, self)
        self.image_item.setOffset((self.rect().width() - scaled.width()) / 2, (self.rect().height() - scaled.height()) / 2)
        self.image_item.setZValue(-1)

    def sync(self):
        pos = self.pos()
        self.panel['x'] = round(pos.x(), 2)
        self.panel['y'] = round(pos.y(), 2)
        self.panel['w'] = round(self.rect().width(), 2)
        self.panel['h'] = round(self.rect().height(), 2)

    def set_size(self, w: float, h: float):
        self.prepareGeometryChange()
        self.setRect(0, 0, w, h)
        if self.image_item:
            self.image_item.setParentItem(None)
            self.image_item = None
            self._load_image()

class ComicPageCanvas(QGraphicsView):
    changed = Signal()
    selection_changed = Signal(object)

    def __init__(self):
        super().__init__()
        self.scene = QGraphicsScene(self)
        self.setScene(self.scene)
        self.setRenderHint(QPainter.Antialiasing)
        self.setDragMode(QGraphicsView.RubberBandDrag)
        self.setMinimumSize(700, 700)
        self.page_rect = self.scene.addRect(0, 0, PAGE_W, PAGE_H, QPen(QColor('#444444'), 2), QBrush(QColor('#f8f8f8')))
        self.page_rect.setZValue(-10)
        self.items_by_id = {}
        self.scene.selectionChanged.connect(self._selection_changed)

    def _selection_changed(self):
        selected = [i for i in self.scene.selectedItems() if isinstance(i, PanelRectItem)]
        self.selection_changed.emit(selected[0].panel if selected else None)

    def load_layout(self, layout: dict):
        for item in list(self.items_by_id.values()):
            self.scene.removeItem(item)
        self.items_by_id = {}
        for panel in layout.get('layout_panels', []):
            self.add_panel_item(panel)
        self.fitInView(self.scene.sceneRect(), Qt.KeepAspectRatio)

    def current_layout(self):
        panels = []
        for item in self.items_by_id.values():
            item.sync()
            panels.append(dict(item.panel))
        return {'page_width': PAGE_W, 'page_height': PAGE_H, 'layout_panels': panels}

    def add_panel_item(self, panel: dict):
        item = PanelRectItem(panel)
        self.scene.addItem(item)
        self.items_by_id[panel['id']] = item
        return item

    def apply_template(self, name: str):
        rects = TEMPLATES.get(name, TEMPLATES['4 Panel Grid'])
        self.load_layout({'layout_panels': [
            {'id': f'layout_{idx+1}', 'title': f'Panel {idx+1}', 'x': x, 'y': y, 'w': w, 'h': h, 'image': ''}
            for idx, (x, y, w, h) in enumerate(rects)
        ]})
        self.changed.emit()

    def selected_item(self):
        selected = [i for i in self.scene.selectedItems() if isinstance(i, PanelRectItem)]
        return selected[0] if selected else None

    def export_png(self, path: str):
        image = QImage(PAGE_W, PAGE_H, QImage.Format_ARGB32)
        image.fill(QColor('#ffffff'))
        painter = QPainter(image)
        self.scene.render(painter, QRectF(0, 0, PAGE_W, PAGE_H), QRectF(0, 0, PAGE_W, PAGE_H))
        painter.end()
        image.save(path)

class PageLayoutEditor(QWidget):
    def __init__(self, project_store):
        super().__init__()
        self.projects = project_store
        self.current_project = None
        self.current_chapter_id = ''
        self.current_page_id = ''
        self._build_ui()
        self.refresh_projects()

    def _build_ui(self):
        root = QHBoxLayout(self)
        left = QVBoxLayout(); center = QVBoxLayout(); right = QVBoxLayout()
        root.addLayout(left, 1); root.addLayout(center, 4); root.addLayout(right, 1)

        self.project_combo = QComboBox(); self.project_combo.currentIndexChanged.connect(self.project_changed)
        self.chapter_combo = QComboBox(); self.chapter_combo.currentIndexChanged.connect(self.chapter_changed)
        self.page_combo = QComboBox(); self.page_combo.currentIndexChanged.connect(self.page_changed)
        left.addWidget(QLabel('Project')); left.addWidget(self.project_combo)
        left.addWidget(QLabel('Chapter')); left.addWidget(self.chapter_combo)
        left.addWidget(QLabel('Page')); left.addWidget(self.page_combo)
        refresh = QPushButton('Refresh Projects'); refresh.clicked.connect(self.refresh_projects); left.addWidget(refresh)

        self.template_combo = QComboBox(); self.template_combo.addItems(list(TEMPLATES.keys()))
        apply_tpl = QPushButton('Apply Layout Template'); apply_tpl.clicked.connect(self.apply_template)
        left.addWidget(QLabel('Layout Template')); left.addWidget(self.template_combo); left.addWidget(apply_tpl)
        add_panel = QPushButton('Add Empty Panel'); add_panel.clicked.connect(self.add_empty_panel)
        left.addWidget(add_panel)
        save = QPushButton('Save Layout'); save.clicked.connect(self.save_layout)
        export = QPushButton('Export Page PNG'); export.clicked.connect(self.export_page)
        left.addWidget(save); left.addWidget(export); left.addStretch(1)

        self.canvas = ComicPageCanvas(); center.addWidget(self.canvas)

        self.panel_list = QListWidget(); self.panel_list.currentItemChanged.connect(self.panel_list_changed)
        right.addWidget(QLabel('Layout Panels')); right.addWidget(self.panel_list)
        self.selected_label = QLabel('No panel selected'); self.selected_label.setWordWrap(True)
        right.addWidget(self.selected_label)
        choose_image = QPushButton('Assign Image to Panel'); choose_image.clicked.connect(self.assign_image)
        title_btn = QPushButton('Rename Panel'); title_btn.clicked.connect(self.rename_panel)
        size_btn = QPushButton('Set Panel Size'); size_btn.clicked.connect(self.set_panel_size)
        delete_btn = QPushButton('Delete Selected Panel'); delete_btn.clicked.connect(self.delete_panel)
        right.addWidget(choose_image); right.addWidget(title_btn); right.addWidget(size_btn); right.addWidget(delete_btn); right.addStretch(1)
        self.canvas.selection_changed.connect(self.canvas_selection_changed)

    def refresh_projects(self):
        current = self.project_combo.currentData()
        self.project_combo.blockSignals(True); self.project_combo.clear()
        for p in self.projects.list():
            self.project_combo.addItem(p.get('title','Untitled Project'), p.get('id',''))
        self.project_combo.blockSignals(False)
        if current:
            idx = self.project_combo.findData(current)
            if idx >= 0: self.project_combo.setCurrentIndex(idx)
        self.project_changed()

    def project_changed(self):
        pid = self.project_combo.currentData()
        self.current_project = self.projects.get(pid) if pid else None
        self.chapter_combo.blockSignals(True); self.chapter_combo.clear()
        if self.current_project:
            for c in self.current_project.get('chapters', []): self.chapter_combo.addItem(c.get('title','Chapter'), c.get('id',''))
        self.chapter_combo.blockSignals(False)
        self.chapter_changed()

    def chapter_changed(self):
        self.current_chapter_id = self.chapter_combo.currentData() or ''
        self.page_combo.blockSignals(True); self.page_combo.clear()
        chapter = self._current_chapter()
        if chapter:
            for p in chapter.get('pages', []): self.page_combo.addItem(p.get('title','Page'), p.get('id',''))
        self.page_combo.blockSignals(False)
        self.page_changed()

    def page_changed(self):
        self.current_page_id = self.page_combo.currentData() or ''
        page = self._current_page()
        layout = page.get('layout', {}) if page else {}
        if not layout:
            # Seed from existing phase 3 panels if present.
            layout = {'layout_panels': []}
            for idx, panel in enumerate((page or {}).get('panels', [])):
                x = 40 + (idx % 2) * 400; y = 40 + (idx // 2) * 360
                layout['layout_panels'].append({'id': panel.get('id', f'p{idx}'), 'title': panel.get('title', f'Panel {idx+1}'), 'x': x, 'y': y, 'w': 370, 'h': 320, 'image': panel.get('image','')})
        self.canvas.load_layout(layout)
        self.refresh_panel_list()

    def _current_chapter(self):
        if not self.current_project: return None
        return next((c for c in self.current_project.get('chapters', []) if c.get('id') == self.current_chapter_id), None)

    def _current_page(self):
        ch = self._current_chapter()
        if not ch: return None
        return next((p for p in ch.get('pages', []) if p.get('id') == self.current_page_id), None)

    def apply_template(self):
        if not self._current_page():
            QMessageBox.warning(self, 'Select page', 'Select a project, chapter, and page first.'); return
        self.canvas.apply_template(self.template_combo.currentText())
        self.refresh_panel_list()

    def add_empty_panel(self):
        n = len(self.canvas.items_by_id) + 1
        panel = {'id': f'custom_{n}', 'title': f'Panel {n}', 'x': 60, 'y': 60, 'w': 320, 'h': 240, 'image': ''}
        self.canvas.add_panel_item(panel); self.refresh_panel_list()

    def refresh_panel_list(self):
        self.panel_list.blockSignals(True); self.panel_list.clear()
        for panel in self.canvas.current_layout().get('layout_panels', []):
            item = QListWidgetItem(f"{panel.get('title','Panel')}  {int(panel.get('w',0))}x{int(panel.get('h',0))}")
            item.setData(Qt.UserRole, panel.get('id'))
            self.panel_list.addItem(item)
        self.panel_list.blockSignals(False)

    def panel_list_changed(self, current, previous):
        if not current: return
        pid = current.data(Qt.UserRole)
        item = self.canvas.items_by_id.get(pid)
        if item:
            self.canvas.scene.clearSelection(); item.setSelected(True); self.canvas.centerOn(item)

    def canvas_selection_changed(self, panel):
        if not panel:
            self.selected_label.setText('No panel selected'); return
        self.selected_label.setText(f"Selected: {panel.get('title')}\nImage: {Path(panel.get('image','')).name if panel.get('image') else 'None'}")

    def assign_image(self):
        item = self.canvas.selected_item()
        if not item:
            QMessageBox.warning(self, 'Select panel', 'Select a panel first.'); return
        fp, _ = QFileDialog.getOpenFileName(self, 'Choose panel image', str(Path.home()), 'Images (*.png *.jpg *.jpeg *.webp)')
        if fp:
            item.panel['image'] = fp
            panel = dict(item.panel); item.setParentItem(None)
            self.canvas.scene.removeItem(item)
            new_item = self.canvas.add_panel_item(panel); new_item.setSelected(True)
            self.refresh_panel_list()

    def rename_panel(self):
        item = self.canvas.selected_item()
        if not item: return
        text, ok = QInputDialog.getText(self, 'Rename Panel', 'Panel title:', text=item.panel.get('title','Panel'))
        if ok and text.strip():
            item.panel['title'] = text.strip(); item.label_item.setText(text.strip()); self.refresh_panel_list()

    def set_panel_size(self):
        item = self.canvas.selected_item()
        if not item: return
        w, ok = QInputDialog.getInt(self, 'Panel Width', 'Width:', int(item.rect().width()), 50, PAGE_W, 10)
        if not ok: return
        h, ok = QInputDialog.getInt(self, 'Panel Height', 'Height:', int(item.rect().height()), 50, PAGE_H, 10)
        if ok:
            item.set_size(w, h); self.refresh_panel_list()

    def delete_panel(self):
        item = self.canvas.selected_item()
        if not item: return
        self.canvas.scene.removeItem(item); self.canvas.items_by_id.pop(item.panel.get('id'), None); self.refresh_panel_list()

    def save_layout(self):
        pid = self.project_combo.currentData()
        if not pid or not self.current_chapter_id or not self.current_page_id:
            QMessageBox.warning(self, 'Select page', 'Select a project, chapter, and page first.'); return
        layout = self.canvas.current_layout()
        page = self.projects.update_page(pid, self.current_chapter_id, self.current_page_id, layout=layout)
        self.current_project = self.projects.get(pid)
        QMessageBox.information(self, 'Saved', f"Saved layout for {page.get('title','page')}.")

    def export_page(self):
        if not self._current_page():
            QMessageBox.warning(self, 'Select page', 'Select a page first.'); return
        fp, _ = QFileDialog.getSaveFileName(self, 'Export page PNG', str(Path.home() / 'comic_page.png'), 'PNG Image (*.png)')
        if fp:
            if not fp.lower().endswith('.png'): fp += '.png'
            self.canvas.export_png(fp)
            QMessageBox.information(self, 'Exported', f'Page exported to:\n{fp}')
