# Brainbender Comic Maker — Phase 7

Free/open local comic-making frontend for Ubuntu using ComfyUI as the Stable Diffusion backend.

## Phase 7 adds

- Release/export tab
- Project export readiness summary
- Print-size presets: US Letter, comic book trim, square web, A4
- Render saved page layouts + lettering to high-resolution PNG pages
- Multi-page PDF export
- CBZ comic archive export
- Optional cover image
- Export manifest JSON
- Organized export folders for finished comic releases

## Run on Ubuntu

```bash
cd ~/Downloads
unzip brainbender_comic_maker_phase7.zip -d brainbender_comic_maker_phase7
cd brainbender_comic_maker_phase7
./install_ubuntu.sh
./start.sh
```

## Important workflow

1. Create or open a project.
2. Add chapters and pages.
3. Use the Page Layout Editor to place panels and lettering.
4. Click **Save Layout + Lettering** for every page you want exported.
5. Go to **Export / Release**.
6. Choose PDF, CBZ, PNG pages, or all three.

The app uses saved project JSON files in your home application data folder, so each phase can read the same project data if the package name remains the same.

## ComfyUI

The generator still expects ComfyUI locally. The app can check/start ComfyUI from the Settings tab if you set the ComfyUI folder.

## Snap packaging

The `snap/snapcraft.yaml` file is still a starter. Phase 8 will focus on finishing the Snap/release packaging.
