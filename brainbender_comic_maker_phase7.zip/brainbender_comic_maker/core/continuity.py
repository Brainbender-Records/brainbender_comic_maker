from __future__ import annotations
from pathlib import Path
import json, uuid, datetime, shutil
from .paths import APP_DIR, ensure_dirs

CONT_DIR = APP_DIR / 'continuity'
POSE_DIR = CONT_DIR / 'poses'
LOCATION_DIR = CONT_DIR / 'locations'
PROP_DIR = CONT_DIR / 'props'
SCENE_DIR = CONT_DIR / 'scenes'
REF_DIR = CONT_DIR / 'references'

def now():
    return datetime.datetime.now().isoformat(timespec='seconds')

class JsonStore:
    def __init__(self, path: Path):
        ensure_dirs(); path.parent.mkdir(parents=True, exist_ok=True); self.path = path
        if not self.path.exists(): self.path.write_text('[]')
    def list(self):
        try:
            data = json.loads(self.path.read_text())
            return data if isinstance(data, list) else []
        except Exception:
            return []
    def save_all(self, items):
        self.path.write_text(json.dumps(items, indent=2))
    def get(self, item_id):
        return next((x for x in self.list() if x.get('id') == item_id), None)
    def upsert(self, item):
        items = self.list(); item = dict(item)
        if not item.get('id'): item['id'] = str(uuid.uuid4())
        item['updated_at'] = now(); item.setdefault('created_at', item['updated_at'])
        for i, existing in enumerate(items):
            if existing.get('id') == item['id']:
                items[i] = item; self.save_all(items); return item
        items.append(item); self.save_all(items); return item
    def delete(self, item_id):
        self.save_all([x for x in self.list() if x.get('id') != item_id])

class ContinuityStore:
    def __init__(self):
        self.characters = JsonStore(CONT_DIR / 'continuity_characters.json')
        self.locations = JsonStore(CONT_DIR / 'locations.json')
        self.props = JsonStore(CONT_DIR / 'props.json')
        self.scenes = JsonStore(CONT_DIR / 'scene_memories.json')
        self.poses = JsonStore(CONT_DIR / 'poses.json')
        REF_DIR.mkdir(parents=True, exist_ok=True)

    def import_reference(self, kind: str, item_id: str, image_path: str) -> str:
        src = Path(image_path)
        dest = REF_DIR / f'{kind}_{item_id}_{uuid.uuid4().hex[:8]}{src.suffix.lower()}'
        shutil.copy2(src, dest)
        return str(dest)

    def build_prompt(self, character=None, location=None, pose=None, scene=None, prop=None, shot_type='', continuity_notes='', panel_action=''):
        parts = []
        if shot_type: parts.append(f'Shot type: {shot_type}.')
        if character:
            parts.append('Character continuity: ' + ', '.join(x for x in [
                character.get('name',''), character.get('visual_description',''), character.get('face_notes',''),
                character.get('hair_notes',''), character.get('outfit_notes',''), character.get('must_keep','')
            ] if x) + '.')
        if location:
            parts.append('Location continuity: ' + ', '.join(x for x in [location.get('name',''), location.get('description',''), location.get('lighting',''), location.get('must_keep','')] if x) + '.')
        if pose:
            parts.append('Pose/camera: ' + ', '.join(x for x in [pose.get('name',''), pose.get('body_pose',''), pose.get('camera_angle',''), pose.get('expression','')] if x) + '.')
        if prop:
            parts.append('Important prop: ' + ', '.join(x for x in [prop.get('name',''), prop.get('description',''), prop.get('must_keep','')] if x) + '.')
        if scene:
            parts.append('Scene memory: ' + ', '.join(x for x in [scene.get('name',''), scene.get('summary',''), scene.get('time_of_day',''), scene.get('mood',''), scene.get('continuity_notes','')] if x) + '.')
        if continuity_notes: parts.append('Continuity rules: ' + continuity_notes)
        if panel_action: parts.append('Panel action: ' + panel_action)
        return '\n'.join(parts).strip()
