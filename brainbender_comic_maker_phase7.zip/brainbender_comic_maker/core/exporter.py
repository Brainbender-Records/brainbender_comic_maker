from __future__ import annotations
from pathlib import Path
from typing import Iterable
import json, zipfile, datetime, shutil
from PIL import Image, ImageDraw, ImageFont, ImageOps

PAGE_PRESETS = {
    'US Letter Portrait 8.5x11': (2550, 3300),
    'Comic Book 6.625x10.25': (1988, 3075),
    'Square Web 2048': (2048, 2048),
    'A4 Portrait': (2480, 3508),
}

def safe_name(text: str) -> str:
    keep = ''.join(c if c.isalnum() or c in (' ','-','_') else '_' for c in text.strip())
    return '_'.join(keep.split())[:80] or 'comic_export'

def _font(size: int, bold: bool=False):
    candidates = [
        '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
        '/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf',
    ]
    for path in candidates:
        if Path(path).exists():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()

def _fit_cover(src: Image.Image, size: tuple[int,int]) -> Image.Image:
    src = ImageOps.exif_transpose(src).convert('RGB')
    return ImageOps.fit(src, size, method=Image.Resampling.LANCZOS, centering=(0.5,0.5))

def _wrap_text(draw: ImageDraw.ImageDraw, text: str, font, max_width: int) -> list[str]:
    lines = []
    for paragraph in text.split('\n'):
        words = paragraph.split()
        if not words:
            lines.append('')
            continue
        line = words[0]
        for word in words[1:]:
            test = line + ' ' + word
            bbox = draw.textbbox((0,0), test, font=font)
            if bbox[2] - bbox[0] <= max_width:
                line = test
            else:
                lines.append(line); line = word
        lines.append(line)
    return lines

def render_page(page: dict, out_path: Path, preset_name: str='US Letter Portrait 8.5x11') -> Path:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    target_w, target_h = PAGE_PRESETS.get(preset_name, PAGE_PRESETS['US Letter Portrait 8.5x11'])
    layout = page.get('layout') or {}
    base_w = float(layout.get('page_width', 850)); base_h = float(layout.get('page_height', 1100))
    sx, sy = target_w / base_w, target_h / base_h
    img = Image.new('RGB', (target_w, target_h), 'white')
    draw = ImageDraw.Draw(img)

    for panel in layout.get('layout_panels', []):
        x, y = int(panel.get('x',0)*sx), int(panel.get('y',0)*sy)
        w, h = int(panel.get('w',100)*sx), int(panel.get('h',100)*sy)
        path = panel.get('image','')
        if path and Path(path).exists():
            try:
                pimg = Image.open(path)
                img.paste(_fit_cover(pimg, (max(1,w), max(1,h))), (x,y))
            except Exception:
                draw.rectangle([x,y,x+w,y+h], fill=(245,245,245))
        else:
            draw.rectangle([x,y,x+w,y+h], fill=(250,250,250))
        bw = max(3, int(4 * (sx+sy)/2))
        for i in range(bw): draw.rectangle([x+i,y+i,x+w-i,y+h-i], outline=(10,10,10))

    for lettering in layout.get('lettering', []):
        x, y = int(lettering.get('x',0)*sx), int(lettering.get('y',0)*sy)
        w, h = int(lettering.get('w',200)*sx), int(lettering.get('h',80)*sy)
        typ = lettering.get('type','speech')
        fill = lettering.get('fill', '#ffffff')
        border = lettering.get('border', '#111111')
        bw = max(2, int(lettering.get('border_width', 3) * (sx+sy)/2))
        if typ == 'speech':
            draw.ellipse([x,y,x+w,y+h], fill=fill, outline=border, width=bw)
        else:
            draw.rectangle([x,y,x+w,y+h], fill=fill, outline=border, width=bw)
        fs = max(8, int(lettering.get('font_size', 20) * (sx+sy)/2))
        font = _font(fs, bold=(typ == 'sfx' or lettering.get('bold', False)))
        text = lettering.get('text','')
        lines = _wrap_text(draw, text, font, max(10, w-30))
        yy = y + max(8, int(12*sy))
        for line in lines:
            draw.text((x + max(8, int(14*sx)), yy), line, fill=lettering.get('text_color','#111111'), font=font)
            bbox = draw.textbbox((0,0), line, font=font)
            yy += (bbox[3]-bbox[1]) + max(2, int(4*sy))

    img.save(out_path)
    return out_path

def iter_pages(project: dict):
    for chapter_index, chapter in enumerate(project.get('chapters', []), start=1):
        for page_index, page in enumerate(chapter.get('pages', []), start=1):
            yield chapter_index, chapter, page_index, page

def export_project(project: dict, destination: Path, preset_name: str='US Letter Portrait 8.5x11', include_pdf=True, include_cbz=True, include_pngs=True, cover_image: str='') -> dict:
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    export_name = f"{safe_name(project.get('title','Brainbender_Comic'))}_{stamp}"
    export_dir = destination / export_name
    pages_dir = export_dir / 'pages'
    pages_dir.mkdir(parents=True, exist_ok=True)

    manifest = {
        'title': project.get('title','Untitled'),
        'creator': project.get('creator',''),
        'description': project.get('description',''),
        'preset': preset_name,
        'exported_at': datetime.datetime.now().isoformat(timespec='seconds'),
        'pages': [],
    }
    page_files = []
    count = 0
    if cover_image and Path(cover_image).exists():
        cover_out = pages_dir / '000_cover.png'
        ImageOps.exif_transpose(Image.open(cover_image)).convert('RGB').save(cover_out)
        page_files.append(cover_out); manifest['cover'] = str(cover_out)

    for chapter_index, chapter, page_index, page in iter_pages(project):
        count += 1
        filename = f"{count:03d}_ch{chapter_index:02d}_pg{page_index:02d}_{safe_name(page.get('title','page'))}.png"
        out = render_page(page, pages_dir / filename, preset_name)
        page_files.append(out)
        manifest['pages'].append({'file': str(out), 'chapter': chapter.get('title','Chapter'), 'page': page.get('title','Page')})

    (export_dir / 'manifest.json').write_text(json.dumps(manifest, indent=2))

    pdf_path = None; cbz_path = None
    if include_pdf and page_files:
        pdf_path = export_dir / f"{export_name}.pdf"
        images = [Image.open(p).convert('RGB') for p in page_files]
        images[0].save(pdf_path, save_all=True, append_images=images[1:])
        for im in images: im.close()
    if include_cbz and page_files:
        cbz_path = export_dir / f"{export_name}.cbz"
        with zipfile.ZipFile(cbz_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
            for p in page_files:
                zf.write(p, arcname=p.name)
            zf.write(export_dir / 'manifest.json', arcname='manifest.json')
    if not include_pngs:
        # Keep PNGs when PDF/CBZ are not requested so the export is never empty.
        if include_pdf or include_cbz:
            shutil.rmtree(pages_dir, ignore_errors=True)
    return {'export_dir': str(export_dir), 'pdf': str(pdf_path) if pdf_path else '', 'cbz': str(cbz_path) if cbz_path else '', 'page_count': len(page_files)}
