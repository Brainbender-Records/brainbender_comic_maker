from __future__ import annotations
from pathlib import Path
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox, QFileDialog, QCheckBox, QTextEdit, QMessageBox, QLineEdit, QGroupBox, QFormLayout
from ..core.library import ProjectStore
from ..core.paths import APP_DIR
from ..core.exporter import PAGE_PRESETS, export_project

class ExportTab(QWidget):
    def __init__(self, projects: ProjectStore):
        super().__init__(); self.projects = projects; self.cover_image = ''; self.destination = str(Path.home() / 'BrainbenderComicExports')
        self._build_ui(); self.refresh_projects()

    def _build_ui(self):
        root = QVBoxLayout(self)
        top = QGroupBox('Release Export')
        form = QFormLayout(top)
        self.project_combo = QComboBox(); form.addRow('Project', self.project_combo)
        refresh = QPushButton('Refresh Projects'); refresh.clicked.connect(self.refresh_projects); form.addRow('', refresh)
        self.preset_combo = QComboBox(); self.preset_combo.addItems(list(PAGE_PRESETS.keys())); form.addRow('Print / Page Size', self.preset_combo)
        self.destination_line = QLineEdit(self.destination)
        choose_dest = QPushButton('Choose Export Folder'); choose_dest.clicked.connect(self.choose_destination)
        row = QHBoxLayout(); row.addWidget(self.destination_line); row.addWidget(choose_dest); form.addRow('Destination', row)
        self.cover_label = QLabel('No cover selected')
        cover_btn = QPushButton('Choose Cover Image'); cover_btn.clicked.connect(self.choose_cover)
        cover_row = QHBoxLayout(); cover_row.addWidget(self.cover_label); cover_row.addWidget(cover_btn); form.addRow('Optional Cover', cover_row)
        self.pdf_check = QCheckBox('Export PDF'); self.pdf_check.setChecked(True)
        self.cbz_check = QCheckBox('Export CBZ comic archive'); self.cbz_check.setChecked(True)
        self.png_check = QCheckBox('Keep rendered PNG pages folder'); self.png_check.setChecked(True)
        checks = QVBoxLayout(); checks.addWidget(self.pdf_check); checks.addWidget(self.cbz_check); checks.addWidget(self.png_check); form.addRow('Formats', checks)
        root.addWidget(top)
        self.summary = QTextEdit(); self.summary.setReadOnly(True); self.summary.setPlaceholderText('Select a project to see export readiness.'); root.addWidget(self.summary, 1)
        self.project_combo.currentIndexChanged.connect(self.update_summary)
        export_btn = QPushButton('Export Comic Release Package'); export_btn.clicked.connect(self.export_clicked); root.addWidget(export_btn)
        note = QLabel('Phase 7 exports saved page layouts/lettering into print-size PNG pages, then builds PDF and/or CBZ files. Save pages in the Page Layout Editor before exporting.')
        note.setWordWrap(True); root.addWidget(note)

    def refresh_projects(self):
        current = self.project_combo.currentData(); self.project_combo.blockSignals(True); self.project_combo.clear()
        for p in self.projects.list(): self.project_combo.addItem(p.get('title','Untitled Project'), p.get('id',''))
        self.project_combo.blockSignals(False)
        if current:
            idx = self.project_combo.findData(current)
            if idx >= 0: self.project_combo.setCurrentIndex(idx)
        self.update_summary()

    def choose_destination(self):
        folder = QFileDialog.getExistingDirectory(self, 'Choose export destination', self.destination_line.text() or str(Path.home()))
        if folder: self.destination_line.setText(folder)

    def choose_cover(self):
        fp, _ = QFileDialog.getOpenFileName(self, 'Choose cover image', str(Path.home()), 'Images (*.png *.jpg *.jpeg *.webp)')
        if fp:
            self.cover_image = fp; self.cover_label.setText(Path(fp).name)

    def _selected_project(self):
        pid = self.project_combo.currentData()
        return self.projects.get(pid) if pid else None

    def update_summary(self):
        project = self._selected_project()
        if not project:
            self.summary.setPlainText('No project selected. Create a project and pages first.'); return
        chapters = project.get('chapters', [])
        pages = [p for c in chapters for p in c.get('pages', [])]
        laid_out = [p for p in pages if p.get('layout', {}).get('layout_panels')]
        text = [
            f"Title: {project.get('title','Untitled')}",
            f"Chapters: {len(chapters)}",
            f"Pages: {len(pages)}",
            f"Pages with saved layouts: {len(laid_out)}",
            '',
            'Export order:',
        ]
        n = 1
        for ci, chapter in enumerate(chapters, start=1):
            text.append(f"Chapter {ci}: {chapter.get('title','Chapter')}")
            for pi, page in enumerate(chapter.get('pages', []), start=1):
                mark = 'ready' if page.get('layout', {}).get('layout_panels') else 'no saved layout'
                text.append(f"  {n:03d}. Page {pi}: {page.get('title','Page')} — {mark}")
                n += 1
        self.summary.setPlainText('\n'.join(text))

    def export_clicked(self):
        project = self._selected_project()
        if not project:
            QMessageBox.warning(self, 'No project', 'Choose a project first.'); return
        dest = Path(self.destination_line.text() or self.destination)
        try:
            result = export_project(
                project=project,
                destination=dest,
                preset_name=self.preset_combo.currentText(),
                include_pdf=self.pdf_check.isChecked(),
                include_cbz=self.cbz_check.isChecked(),
                include_pngs=self.png_check.isChecked(),
                cover_image=self.cover_image,
            )
        except Exception as exc:
            QMessageBox.critical(self, 'Export failed', str(exc)); return
        msg = f"Export complete.\n\nFolder:\n{result['export_dir']}\n\nPages: {result['page_count']}"
        if result.get('pdf'): msg += f"\nPDF:\n{result['pdf']}"
        if result.get('cbz'): msg += f"\nCBZ:\n{result['cbz']}"
        QMessageBox.information(self, 'Export complete', msg)
        self.update_summary()
