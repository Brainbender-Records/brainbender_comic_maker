from __future__ import annotations
from pathlib import Path
from PySide6.QtCore import Qt, QRectF, Signal
from PySide6.QtGui import QPainter, QPen, QBrush, QPixmap, QColor, QImage, QFont
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QComboBox, QFileDialog,
    QListWidget, QListWidgetItem, QMessageBox, QGraphicsView, QGraphicsScene,
    QGraphicsRectItem, QGraphicsEllipseItem, QGraphicsPixmapItem, QGraphicsSimpleTextItem,
    QGraphicsTextItem, QInputDialog, QColorDialog
)

PAGE_W = 850
PAGE_H = 1100

TEMPLATES = {
    '1 Panel Splash': [(40, 40, 770, 1020)],
    '2 Panels Vertical': [(40, 40, 770, 500), (40, 560, 770, 500)],
    '3 Panels Stack': [(40, 40, 770, 320), (40, 390, 770, 320), (40, 740, 770, 320)],
    '4 Panel Grid': [(40, 40, 370, 500), (440, 40, 370, 500), (40, 570, 370, 490), (440, 570, 370, 490)],
    '6 Panel Grid': [(40, 40, 240, 320), (305, 40, 240, 320), (570, 40, 240, 320), (40, 390, 240, 320), (305, 390, 240, 320), (570, 390, 240, 320)],
    'Manga Strip': [(40, 40, 770, 230), (40, 300, 770, 230), (40, 560, 770, 230), (40, 820, 770, 240)],
}

class PanelRectItem(QGraphicsRectItem):
    def __init__(self, panel: dict):
        super().__init__(0, 0, panel.get('w', 300), panel.get('h', 220))
        self.panel = panel
        self.setPos(panel.get('x', 40), panel.get('y', 40))
        self.setFlags(QGraphicsRectItem.ItemIsMovable | QGraphicsRectItem.ItemIsSelectable | QGraphicsRectItem.ItemSendsGeometryChanges)
        self.setPen(QPen(QColor('#111111'), 4))
        self.setBrush(QBrush(QColor(255, 255, 255, 20)))
        self.image_item = None
        self.label_item = QGraphicsSimpleTextItem(panel.get('title', 'Panel'), self)
        self.label_item.setBrush(QBrush(QColor('#111111')))
        self.label_item.setPos(8, 8)
        self._load_image()

    def _load_image(self):
        image_path = self.panel.get('image', '')
        if not image_path or not Path(image_path).exists():
            return
        pix = QPixmap(image_path)
        if pix.isNull():
            return
        scaled = pix.scaled(int(self.rect().width()), int(self.rect().height()), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        self.image_item = QGraphicsPixmapItem(scaled, self)
        self.image_item.setOffset((self.rect().width() - scaled.width()) / 2, (self.rect().height() - scaled.height()) / 2)
        self.image_item.setZValue(-1)

    def sync(self):
        pos = self.pos()
        self.panel['x'] = round(pos.x(), 2)
        self.panel['y'] = round(pos.y(), 2)
        self.panel['w'] = round(self.rect().width(), 2)
        self.panel['h'] = round(self.rect().height(), 2)

    def set_size(self, w: float, h: float):
        self.prepareGeometryChange(); self.setRect(0, 0, w, h)
        if self.image_item:
            self.image_item.setParentItem(None); self.image_item = None; self._load_image()

class LetteringItem:
    """Mixin-like helpers shared by bubble/caption/SFX graphics items."""
    def _init_lettering(self, lettering: dict):
        self.lettering = lettering
        self.setPos(lettering.get('x', 90), lettering.get('y', 90))
        self.setFlags(self.ItemIsMovable | self.ItemIsSelectable | self.ItemSendsGeometryChanges)
        self.setPen(QPen(QColor(lettering.get('border', '#111111')), int(lettering.get('border_width', 3))))
        self.setBrush(QBrush(QColor(lettering.get('fill', '#ffffff'))))
        self.text_item = QGraphicsTextItem(lettering.get('text', ''), self)
        font = QFont(lettering.get('font_family', 'DejaVu Sans'), int(lettering.get('font_size', 20)))
        font.setBold(bool(lettering.get('bold', False)))
        self.text_item.setFont(font)
        self.text_item.setDefaultTextColor(QColor(lettering.get('text_color', '#111111')))
        self.text_item.setTextWidth(max(20, lettering.get('w', 220) - 24))
        self.text_item.setPos(12, 10)
        self.setZValue(10)

    def sync_lettering(self):
        pos = self.pos()
        self.lettering['x'] = round(pos.x(), 2)
        self.lettering['y'] = round(pos.y(), 2)
        self.lettering['text'] = self.text_item.toPlainText()
        if hasattr(self, 'rect'):
            self.lettering['w'] = round(self.rect().width(), 2)
            self.lettering['h'] = round(self.rect().height(), 2)

    def set_text(self, text: str):
        self.lettering['text'] = text; self.text_item.setPlainText(text)

    def set_size(self, w: float, h: float):
        self.prepareGeometryChange(); self.setRect(0, 0, w, h); self.text_item.setTextWidth(max(20, w - 24))
        self.lettering['w'] = w; self.lettering['h'] = h

    def set_font_size(self, size: int):
        self.lettering['font_size'] = size
        font = self.text_item.font(); font.setPointSize(size); self.text_item.setFont(font)

    def set_fill(self, color: str):
        self.lettering['fill'] = color; self.setBrush(QBrush(QColor(color)))

class SpeechBubbleItem(LetteringItem, QGraphicsEllipseItem):
    def __init__(self, lettering: dict):
        QGraphicsEllipseItem.__init__(self, 0, 0, lettering.get('w', 260), lettering.get('h', 120))
        self._init_lettering(lettering)

class CaptionItem(LetteringItem, QGraphicsRectItem):
    def __init__(self, lettering: dict):
        QGraphicsRectItem.__init__(self, 0, 0, lettering.get('w', 320), lettering.get('h', 90))
        self._init_lettering(lettering)

class SfxItem(LetteringItem, QGraphicsRectItem):
    def __init__(self, lettering: dict):
        QGraphicsRectItem.__init__(self, 0, 0, lettering.get('w', 240), lettering.get('h', 90))
        self._init_lettering(lettering)
        self.setBrush(QBrush(QColor(lettering.get('fill', '#fff799'))))
        font = self.text_item.font(); font.setBold(True); font.setPointSize(int(lettering.get('font_size', 34))); self.text_item.setFont(font)
        self.text_item.setDefaultTextColor(QColor(lettering.get('text_color', '#111111')))

class ComicPageCanvas(QGraphicsView):
    changed = Signal()
    selection_changed = Signal(object)

    def __init__(self):
        super().__init__()
        self.scene = QGraphicsScene(self)
        self.setScene(self.scene)
        self.setRenderHint(QPainter.Antialiasing)
        self.setDragMode(QGraphicsView.RubberBandDrag)
        self.setMinimumSize(700, 700)
        self.page_rect = self.scene.addRect(0, 0, PAGE_W, PAGE_H, QPen(QColor('#444444'), 2), QBrush(QColor('#f8f8f8')))
        self.page_rect.setZValue(-10)
        self.items_by_id = {}
        self.lettering_by_id = {}
        self.scene.selectionChanged.connect(self._selection_changed)

    def _selection_changed(self):
        selected = self.scene.selectedItems()
        panels = [i for i in selected if isinstance(i, PanelRectItem)]
        letters = [i for i in selected if hasattr(i, 'lettering')]
        if panels:
            self.selection_changed.emit({'kind': 'panel', 'data': panels[0].panel})
        elif letters:
            self.selection_changed.emit({'kind': 'lettering', 'data': letters[0].lettering})
        else:
            self.selection_changed.emit(None)

    def load_layout(self, layout: dict):
        for item in list(self.items_by_id.values()) + list(self.lettering_by_id.values()):
            self.scene.removeItem(item)
        self.items_by_id = {}; self.lettering_by_id = {}
        for panel in layout.get('layout_panels', []): self.add_panel_item(panel)
        for lettering in layout.get('lettering', []): self.add_lettering_item(lettering)
        self.fitInView(self.scene.sceneRect(), Qt.KeepAspectRatio)

    def current_layout(self):
        panels = []
        for item in self.items_by_id.values(): item.sync(); panels.append(dict(item.panel))
        lettering = []
        for item in self.lettering_by_id.values(): item.sync_lettering(); lettering.append(dict(item.lettering))
        return {'page_width': PAGE_W, 'page_height': PAGE_H, 'layout_panels': panels, 'lettering': lettering}

    def add_panel_item(self, panel: dict):
        item = PanelRectItem(panel); self.scene.addItem(item); self.items_by_id[panel['id']] = item; return item

    def add_lettering_item(self, lettering: dict):
        typ = lettering.get('type', 'speech')
        if typ == 'caption': item = CaptionItem(lettering)
        elif typ == 'sfx': item = SfxItem(lettering)
        else: item = SpeechBubbleItem(lettering)
        self.scene.addItem(item); self.lettering_by_id[lettering['id']] = item; return item

    def apply_template(self, name: str):
        rects = TEMPLATES.get(name, TEMPLATES['4 Panel Grid'])
        self.load_layout({'layout_panels': [
            {'id': f'layout_{idx+1}', 'title': f'Panel {idx+1}', 'x': x, 'y': y, 'w': w, 'h': h, 'image': ''}
            for idx, (x, y, w, h) in enumerate(rects)
        ], 'lettering': []})
        self.changed.emit()

    def selected_panel_item(self):
        selected = [i for i in self.scene.selectedItems() if isinstance(i, PanelRectItem)]
        return selected[0] if selected else None

    def selected_lettering_item(self):
        selected = [i for i in self.scene.selectedItems() if hasattr(i, 'lettering')]
        return selected[0] if selected else None

    def export_png(self, path: str):
        image = QImage(PAGE_W, PAGE_H, QImage.Format_ARGB32)
        image.fill(QColor('#ffffff'))
        painter = QPainter(image)
        self.scene.render(painter, QRectF(0, 0, PAGE_W, PAGE_H), QRectF(0, 0, PAGE_W, PAGE_H))
        painter.end(); image.save(path)

class PageLayoutEditor(QWidget):
    def __init__(self, project_store):
        super().__init__(); self.projects = project_store; self.current_project = None; self.current_chapter_id = ''; self.current_page_id = ''
        self._build_ui(); self.refresh_projects()

    def _build_ui(self):
        root = QHBoxLayout(self); left = QVBoxLayout(); center = QVBoxLayout(); right = QVBoxLayout(); root.addLayout(left,1); root.addLayout(center,4); root.addLayout(right,1)
        self.project_combo = QComboBox(); self.project_combo.currentIndexChanged.connect(self.project_changed)
        self.chapter_combo = QComboBox(); self.chapter_combo.currentIndexChanged.connect(self.chapter_changed)
        self.page_combo = QComboBox(); self.page_combo.currentIndexChanged.connect(self.page_changed)
        left.addWidget(QLabel('Project')); left.addWidget(self.project_combo); left.addWidget(QLabel('Chapter')); left.addWidget(self.chapter_combo); left.addWidget(QLabel('Page')); left.addWidget(self.page_combo)
        refresh = QPushButton('Refresh Projects'); refresh.clicked.connect(self.refresh_projects); left.addWidget(refresh)
        self.template_combo = QComboBox(); self.template_combo.addItems(list(TEMPLATES.keys()))
        apply_tpl = QPushButton('Apply Layout Template'); apply_tpl.clicked.connect(self.apply_template)
        left.addWidget(QLabel('Layout Template')); left.addWidget(self.template_combo); left.addWidget(apply_tpl)
        add_panel = QPushButton('Add Empty Panel'); add_panel.clicked.connect(self.add_empty_panel); left.addWidget(add_panel)
        save = QPushButton('Save Layout + Lettering'); save.clicked.connect(self.save_layout)
        export = QPushButton('Export Lettered Page PNG'); export.clicked.connect(self.export_page)
        left.addWidget(save); left.addWidget(export); left.addStretch(1)
        self.canvas = ComicPageCanvas(); center.addWidget(self.canvas)
        self.panel_list = QListWidget(); self.panel_list.currentItemChanged.connect(self.panel_list_changed)
        right.addWidget(QLabel('Layout Panels')); right.addWidget(self.panel_list)
        self.lettering_list = QListWidget(); self.lettering_list.currentItemChanged.connect(self.lettering_list_changed)
        right.addWidget(QLabel('Speech / Captions / SFX')); right.addWidget(self.lettering_list)
        self.selected_label = QLabel('No item selected'); self.selected_label.setWordWrap(True); right.addWidget(self.selected_label)
        choose_image = QPushButton('Assign Image to Panel'); choose_image.clicked.connect(self.assign_image)
        title_btn = QPushButton('Rename Panel'); title_btn.clicked.connect(self.rename_panel)
        size_btn = QPushButton('Set Selected Size'); size_btn.clicked.connect(self.set_selected_size)
        add_speech = QPushButton('Add Speech Bubble'); add_speech.clicked.connect(lambda: self.add_lettering('speech'))
        add_caption = QPushButton('Add Caption Box'); add_caption.clicked.connect(lambda: self.add_lettering('caption'))
        add_sfx = QPushButton('Add SFX Text'); add_sfx.clicked.connect(lambda: self.add_lettering('sfx'))
        edit_text = QPushButton('Edit Selected Text'); edit_text.clicked.connect(self.edit_lettering_text)
        font_btn = QPushButton('Set Selected Font Size'); font_btn.clicked.connect(self.set_lettering_font_size)
        color_btn = QPushButton('Set Bubble Fill Color'); color_btn.clicked.connect(self.set_lettering_fill)
        delete_btn = QPushButton('Delete Selected Item'); delete_btn.clicked.connect(self.delete_selected)
        for b in [choose_image,title_btn,size_btn,add_speech,add_caption,add_sfx,edit_text,font_btn,color_btn,delete_btn]: right.addWidget(b)
        right.addStretch(1); self.canvas.selection_changed.connect(self.canvas_selection_changed)

    def refresh_projects(self):
        current = self.project_combo.currentData(); self.project_combo.blockSignals(True); self.project_combo.clear()
        for p in self.projects.list(): self.project_combo.addItem(p.get('title','Untitled Project'), p.get('id',''))
        self.project_combo.blockSignals(False)
        if current:
            idx = self.project_combo.findData(current)
            if idx >= 0: self.project_combo.setCurrentIndex(idx)
        self.project_changed()

    def project_changed(self):
        pid = self.project_combo.currentData(); self.current_project = self.projects.get(pid) if pid else None
        self.chapter_combo.blockSignals(True); self.chapter_combo.clear()
        if self.current_project:
            for c in self.current_project.get('chapters', []): self.chapter_combo.addItem(c.get('title','Chapter'), c.get('id',''))
        self.chapter_combo.blockSignals(False); self.chapter_changed()

    def chapter_changed(self):
        self.current_chapter_id = self.chapter_combo.currentData() or ''; self.page_combo.blockSignals(True); self.page_combo.clear()
        chapter = self._current_chapter()
        if chapter:
            for p in chapter.get('pages', []): self.page_combo.addItem(p.get('title','Page'), p.get('id',''))
        self.page_combo.blockSignals(False); self.page_changed()

    def page_changed(self):
        self.current_page_id = self.page_combo.currentData() or ''; page = self._current_page(); layout = page.get('layout', {}) if page else {}
        if not layout:
            layout = {'layout_panels': [], 'lettering': []}
            for idx, panel in enumerate((page or {}).get('panels', [])):
                x = 40 + (idx % 2) * 400; y = 40 + (idx // 2) * 360
                layout['layout_panels'].append({'id': panel.get('id', f'p{idx}'), 'title': panel.get('title', f'Panel {idx+1}'), 'x': x, 'y': y, 'w': 370, 'h': 320, 'image': panel.get('image','')})
        layout.setdefault('lettering', [])
        self.canvas.load_layout(layout); self.refresh_panel_list(); self.refresh_lettering_list()

    def _current_chapter(self):
        if not self.current_project: return None
        return next((c for c in self.current_project.get('chapters', []) if c.get('id') == self.current_chapter_id), None)

    def _current_page(self):
        ch = self._current_chapter();
        if not ch: return None
        return next((p for p in ch.get('pages', []) if p.get('id') == self.current_page_id), None)

    def apply_template(self):
        if not self._current_page(): QMessageBox.warning(self, 'Select page', 'Select a project, chapter, and page first.'); return
        self.canvas.apply_template(self.template_combo.currentText()); self.refresh_panel_list(); self.refresh_lettering_list()

    def add_empty_panel(self):
        n = len(self.canvas.items_by_id) + 1; panel = {'id': f'custom_{n}', 'title': f'Panel {n}', 'x': 60, 'y': 60, 'w': 320, 'h': 240, 'image': ''}
        self.canvas.add_panel_item(panel); self.refresh_panel_list()

    def refresh_panel_list(self):
        self.panel_list.blockSignals(True); self.panel_list.clear()
        for panel in self.canvas.current_layout().get('layout_panels', []):
            item = QListWidgetItem(f"{panel.get('title','Panel')}  {int(panel.get('w',0))}x{int(panel.get('h',0))}"); item.setData(Qt.UserRole, panel.get('id')); self.panel_list.addItem(item)
        self.panel_list.blockSignals(False)

    def refresh_lettering_list(self):
        self.lettering_list.blockSignals(True); self.lettering_list.clear()
        for lettering in self.canvas.current_layout().get('lettering', []):
            txt = lettering.get('text','').replace('\n',' ')[:28]
            item = QListWidgetItem(f"{lettering.get('type','speech').title()}: {txt}"); item.setData(Qt.UserRole, lettering.get('id')); self.lettering_list.addItem(item)
        self.lettering_list.blockSignals(False)

    def panel_list_changed(self, current, previous):
        if not current: return
        item = self.canvas.items_by_id.get(current.data(Qt.UserRole))
        if item: self.canvas.scene.clearSelection(); item.setSelected(True); self.canvas.centerOn(item)

    def lettering_list_changed(self, current, previous):
        if not current: return
        item = self.canvas.lettering_by_id.get(current.data(Qt.UserRole))
        if item: self.canvas.scene.clearSelection(); item.setSelected(True); self.canvas.centerOn(item)

    def canvas_selection_changed(self, payload):
        if not payload: self.selected_label.setText('No item selected'); return
        if payload.get('kind') == 'panel':
            panel = payload.get('data', {}); self.selected_label.setText(f"Selected panel: {panel.get('title')}\nImage: {Path(panel.get('image','')).name if panel.get('image') else 'None'}")
        else:
            lettering = payload.get('data', {}); self.selected_label.setText(f"Selected {lettering.get('type','speech')} text:\n{lettering.get('text','')}")

    def assign_image(self):
        item = self.canvas.selected_panel_item()
        if not item: QMessageBox.warning(self, 'Select panel', 'Select a panel first.'); return
        fp, _ = QFileDialog.getOpenFileName(self, 'Choose panel image', str(Path.home()), 'Images (*.png *.jpg *.jpeg *.webp)')
        if fp:
            item.panel['image'] = fp; panel = dict(item.panel); self.canvas.scene.removeItem(item); self.canvas.items_by_id.pop(panel.get('id'), None)
            new_item = self.canvas.add_panel_item(panel); new_item.setSelected(True); self.refresh_panel_list()

    def rename_panel(self):
        item = self.canvas.selected_panel_item()
        if not item: return
        text, ok = QInputDialog.getText(self, 'Rename Panel', 'Panel title:', text=item.panel.get('title','Panel'))
        if ok and text.strip(): item.panel['title'] = text.strip(); item.label_item.setText(text.strip()); self.refresh_panel_list()

    def set_selected_size(self):
        item = self.canvas.selected_panel_item() or self.canvas.selected_lettering_item()
        if not item: return
        if hasattr(item, 'rect'): w0, h0 = int(item.rect().width()), int(item.rect().height())
        else: w0, h0 = 220, 100
        w, ok = QInputDialog.getInt(self, 'Width', 'Width:', w0, 40, PAGE_W, 10)
        if not ok: return
        h, ok = QInputDialog.getInt(self, 'Height', 'Height:', h0, 30, PAGE_H, 10)
        if ok: item.set_size(w, h); self.refresh_panel_list(); self.refresh_lettering_list()

    def add_lettering(self, typ: str):
        default = 'Hello!' if typ == 'speech' else ('Meanwhile...' if typ == 'caption' else 'BOOM!')
        text, ok = QInputDialog.getMultiLineText(self, 'Add comic lettering', 'Text:', default)
        if not ok or not text.strip(): return
        n = len(self.canvas.lettering_by_id) + 1
        w, h, fs = (260,120,20) if typ == 'speech' else ((360,90,18) if typ == 'caption' else (240,90,34))
        lettering = {'id': f'letter_{n}', 'type': typ, 'text': text.strip(), 'x': 100 + n*12, 'y': 100 + n*12, 'w': w, 'h': h, 'font_size': fs, 'font_family': 'DejaVu Sans', 'text_color': '#111111', 'fill': '#ffffff' if typ != 'sfx' else '#fff799', 'border': '#111111', 'border_width': 3}
        item = self.canvas.add_lettering_item(lettering); self.canvas.scene.clearSelection(); item.setSelected(True); self.refresh_lettering_list()

    def edit_lettering_text(self):
        item = self.canvas.selected_lettering_item()
        if not item: QMessageBox.warning(self, 'Select lettering', 'Select a speech bubble, caption, or SFX item first.'); return
        text, ok = QInputDialog.getMultiLineText(self, 'Edit text', 'Text:', item.lettering.get('text',''))
        if ok: item.set_text(text); self.refresh_lettering_list()

    def set_lettering_font_size(self):
        item = self.canvas.selected_lettering_item()
        if not item: return
        size, ok = QInputDialog.getInt(self, 'Font Size', 'Font size:', int(item.lettering.get('font_size', 20)), 6, 120, 1)
        if ok: item.set_font_size(size); self.refresh_lettering_list()

    def set_lettering_fill(self):
        item = self.canvas.selected_lettering_item()
        if not item: return
        color = QColorDialog.getColor(QColor(item.lettering.get('fill','#ffffff')), self, 'Choose fill color')
        if color.isValid(): item.set_fill(color.name())

    def delete_selected(self):
        pitem = self.canvas.selected_panel_item(); litem = self.canvas.selected_lettering_item()
        if pitem: self.canvas.scene.removeItem(pitem); self.canvas.items_by_id.pop(pitem.panel.get('id'), None); self.refresh_panel_list(); return
        if litem: self.canvas.scene.removeItem(litem); self.canvas.lettering_by_id.pop(litem.lettering.get('id'), None); self.refresh_lettering_list(); return

    def save_layout(self):
        pid = self.project_combo.currentData()
        if not pid or not self.current_chapter_id or not self.current_page_id: QMessageBox.warning(self, 'Select page', 'Select a project, chapter, and page first.'); return
        layout = self.canvas.current_layout(); page = self.projects.update_page(pid, self.current_chapter_id, self.current_page_id, layout=layout)
        self.current_project = self.projects.get(pid); QMessageBox.information(self, 'Saved', f"Saved layout and lettering for {page.get('title','page')}.")

    def export_page(self):
        if not self._current_page(): QMessageBox.warning(self, 'Select page', 'Select a page first.'); return
        fp, _ = QFileDialog.getSaveFileName(self, 'Export lettered page PNG', str(Path.home() / 'lettered_comic_page.png'), 'PNG Image (*.png)')
        if fp:
            if not fp.lower().endswith('.png'): fp += '.png'
            self.canvas.export_png(fp); QMessageBox.information(self, 'Exported', f'Lettered page exported to:\n{fp}')
