from __future__ import annotations
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QLineEdit, QTextEdit,
    QPushButton, QListWidget, QMessageBox, QTabWidget, QComboBox, QFileDialog,
    QGroupBox, QApplication
)
from PySide6.QtCore import Qt
from ..core.continuity import ContinuityStore

SHOT_TYPES = ['Wide establishing shot','Medium shot','Close-up','Extreme close-up','Over-the-shoulder','Low angle','High angle','Action shot','Reaction shot','Silent mood panel']

class ContinuityTab(QWidget):
    def __init__(self):
        super().__init__()
        self.store = ContinuityStore()
        self.current = {'character': None, 'location': None, 'prop': None, 'pose': None, 'scene': None}
        self._build()
        self.refresh_all()

    def _build(self):
        root = QVBoxLayout(self)
        tabs = QTabWidget(); root.addWidget(tabs)
        tabs.addTab(self._character_tab(), 'Characters')
        tabs.addTab(self._location_tab(), 'Locations')
        tabs.addTab(self._pose_tab(), 'Pose / Camera')
        tabs.addTab(self._props_tab(), 'Props')
        tabs.addTab(self._scene_tab(), 'Scene Memory')
        tabs.addTab(self._prompt_builder_tab(), 'Prompt Builder')

    def _list_editor(self, kind, fields, store_attr):
        page = QWidget(); layout = QHBoxLayout(page)
        left = QVBoxLayout(); right = QVBoxLayout(); layout.addLayout(left,1); layout.addLayout(right,2)
        lw = QListWidget(); setattr(self, f'{kind}_list', lw); lw.currentRowChanged.connect(lambda _=None,k=kind: self.load_item(k))
        left.addWidget(lw)
        btns = QHBoxLayout(); new = QPushButton('New'); save = QPushButton('Save'); delete = QPushButton('Delete')
        new.clicked.connect(lambda: self.new_item(kind)); save.clicked.connect(lambda: self.save_item(kind, store_attr)); delete.clicked.connect(lambda: self.delete_item(kind, store_attr))
        btns.addWidget(new); btns.addWidget(save); btns.addWidget(delete); left.addLayout(btns)
        form = QGridLayout(); setattr(self, f'{kind}_fields', {})
        for row, (key, label, multi) in enumerate(fields):
            w = QTextEdit() if multi else QLineEdit()
            if multi: w.setMinimumHeight(70)
            getattr(self, f'{kind}_fields')[key] = w
            form.addWidget(QLabel(label), row, 0); form.addWidget(w, row, 1)
        right.addLayout(form)
        ref_btn = QPushButton('Add Reference Image')
        ref_btn.clicked.connect(lambda: self.add_reference(kind, store_attr))
        right.addWidget(ref_btn)
        refs = QTextEdit(); refs.setReadOnly(True); refs.setPlaceholderText('Reference image paths will appear here.')
        setattr(self, f'{kind}_refs', refs); right.addWidget(refs)
        return page

    def _character_tab(self):
        return self._list_editor('character', [
            ('name','Name',False), ('visual_description','Visual description',True), ('face_notes','Face notes',True),
            ('hair_notes','Hair notes',False), ('outfit_notes','Outfit / costume notes',True), ('personality','Personality',True),
            ('must_keep','Must keep consistent',True), ('avoid','Avoid / never change',True)
        ], 'characters')
    def _location_tab(self):
        return self._list_editor('location', [('name','Name',False),('description','Description',True),('lighting','Lighting',False),('mood','Mood',False),('must_keep','Must keep consistent',True)], 'locations')
    def _pose_tab(self):
        return self._list_editor('pose', [('name','Name',False),('body_pose','Body pose',True),('camera_angle','Camera angle',False),('expression','Expression',False),('notes','Notes',True)], 'poses')
    def _props_tab(self):
        return self._list_editor('prop', [('name','Name',False),('description','Description',True),('must_keep','Must keep consistent',True),('notes','Notes',True)], 'props')
    def _scene_tab(self):
        return self._list_editor('scene', [('name','Scene name',False),('summary','Scene summary',True),('time_of_day','Time of day',False),('mood','Mood',False),('continuity_notes','Continuity notes',True)], 'scenes')

    def _prompt_builder_tab(self):
        page = QWidget(); layout = QVBoxLayout(page)
        grid = QGridLayout(); layout.addLayout(grid)
        self.pb_character = QComboBox(); self.pb_location = QComboBox(); self.pb_pose = QComboBox(); self.pb_prop = QComboBox(); self.pb_scene = QComboBox(); self.pb_shot = QComboBox(); self.pb_shot.addItems(SHOT_TYPES)
        widgets = [('Character', self.pb_character),('Location', self.pb_location),('Pose', self.pb_pose),('Prop', self.pb_prop),('Scene', self.pb_scene),('Shot type', self.pb_shot)]
        for i,(label,w) in enumerate(widgets): grid.addWidget(QLabel(label), i,0); grid.addWidget(w, i,1)
        self.pb_action = QTextEdit(); self.pb_action.setPlaceholderText('What happens in this panel?')
        self.pb_rules = QTextEdit(); self.pb_rules.setPlaceholderText('Extra continuity rules for this panel/book.')
        layout.addWidget(QLabel('Panel Action')); layout.addWidget(self.pb_action)
        layout.addWidget(QLabel('Extra Continuity Rules')); layout.addWidget(self.pb_rules)
        buttons = QHBoxLayout(); build = QPushButton('Build Continuity Prompt'); copy = QPushButton('Copy Prompt')
        build.clicked.connect(self.build_prompt); copy.clicked.connect(lambda: QApplication.clipboard().setText(self.pb_output.toPlainText()))
        buttons.addWidget(build); buttons.addWidget(copy); layout.addLayout(buttons)
        self.pb_output = QTextEdit(); self.pb_output.setPlaceholderText('Built prompt will appear here. Paste it into the Generate tab prompt/context.')
        layout.addWidget(self.pb_output, 1)
        return page

    def store_for(self, attr): return getattr(self.store, attr)
    def fields_for(self, kind): return getattr(self, f'{kind}_fields')

    def refresh_kind(self, kind, store_attr):
        lw = getattr(self, f'{kind}_list'); lw.clear()
        for item in self.store_for(store_attr).list(): lw.addItem(item.get('name') or item.get('title') or 'Untitled')

    def refresh_all(self):
        for kind, attr in [('character','characters'),('location','locations'),('pose','poses'),('prop','props'),('scene','scenes')]: self.refresh_kind(kind, attr)
        self.refresh_builder_combos()

    def refresh_builder_combos(self):
        for combo, attr in [(self.pb_character,'characters'),(self.pb_location,'locations'),(self.pb_pose,'poses'),(self.pb_prop,'props'),(self.pb_scene,'scenes')]:
            combo.clear(); combo.addItem('None','')
            for item in self.store_for(attr).list(): combo.addItem(item.get('name','Untitled'), item.get('id'))

    def new_item(self, kind):
        self.current[kind] = None
        for w in self.fields_for(kind).values(): w.clear()
        getattr(self, f'{kind}_refs').clear()

    def load_item(self, kind):
        attr = {'character':'characters','location':'locations','pose':'poses','prop':'props','scene':'scenes'}[kind]
        items = self.store_for(attr).list(); row = getattr(self, f'{kind}_list').currentRow()
        if row < 0 or row >= len(items): return
        item = items[row]; self.current[kind] = item
        for key,w in self.fields_for(kind).items(): w.setPlainText(item.get(key,'')) if hasattr(w,'setPlainText') else w.setText(item.get(key,''))
        getattr(self, f'{kind}_refs').setPlainText('\n'.join(item.get('reference_images', [])))

    def save_item(self, kind, store_attr):
        item = dict(self.current.get(kind) or {})
        for key,w in self.fields_for(kind).items(): item[key] = w.toPlainText().strip() if hasattr(w,'toPlainText') else w.text().strip()
        if not item.get('name'):
            QMessageBox.warning(self, 'Missing name', 'Please enter a name first.'); return
        saved = self.store_for(store_attr).upsert(item); self.current[kind] = saved
        self.refresh_kind(kind, store_attr); self.refresh_builder_combos()

    def delete_item(self, kind, store_attr):
        item = self.current.get(kind)
        if not item: return
        self.store_for(store_attr).delete(item['id']); self.new_item(kind); self.refresh_kind(kind, store_attr); self.refresh_builder_combos()

    def add_reference(self, kind, store_attr):
        item = self.current.get(kind)
        if not item or not item.get('id'):
            QMessageBox.information(self, 'Save first', 'Save this item before adding reference images.'); return
        path, _ = QFileDialog.getOpenFileName(self, 'Choose Reference Image', '', 'Images (*.png *.jpg *.jpeg *.webp)')
        if not path: return
        dest = self.store.import_reference(kind, item['id'], path)
        item.setdefault('reference_images', []).append(dest)
        saved = self.store_for(store_attr).upsert(item); self.current[kind] = saved
        getattr(self, f'{kind}_refs').setPlainText('\n'.join(saved.get('reference_images', [])))

    def _selected(self, combo, attr):
        item_id = combo.currentData()
        return self.store_for(attr).get(item_id) if item_id else None

    def build_prompt(self):
        text = self.store.build_prompt(
            character=self._selected(self.pb_character,'characters'), location=self._selected(self.pb_location,'locations'),
            pose=self._selected(self.pb_pose,'poses'), prop=self._selected(self.pb_prop,'props'), scene=self._selected(self.pb_scene,'scenes'),
            shot_type=self.pb_shot.currentText(), continuity_notes=self.pb_rules.toPlainText().strip(), panel_action=self.pb_action.toPlainText().strip())
        self.pb_output.setPlainText(text)
