from __future__ import annotations

import traceback
from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import *

from ..comfy.client import ComfyClient, ComfyError
from ..comfy.launcher import ComfyLauncher
from ..core.library import JsonLibrary, ProjectStore
from ..core.settings import Settings
from ..exporter.exporter import Exporter


class GenerationWorker(QThread):
    finished_ok = Signal(str)
    failed = Signal(str)

    def __init__(self, client: ComfyClient, params: dict):
        super().__init__()
        self.client = client
        self.params = params

    def run(self):
        try:
            mode = self.params.pop("mode")
            if mode == "img2img":
                path = self.client.generate_image_to_image(**self.params)
            else:
                path = self.client.generate_text_to_image(**self.params)
            self.finished_ok.emit(str(path))
        except Exception as exc:
            self.failed.emit(f"{exc}\n\n{traceback.format_exc(limit=2)}")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Brainbender Comic Maker — AppImage Edition")
        self.resize(1180, 780)
        self.settings = Settings()
        self.client = ComfyClient(self.settings.get("comfy_url"))
        self.characters = JsonLibrary("characters")
        self.locations = JsonLibrary("locations")
        self.projects = ProjectStore()
        self.generated = []
        self.worker = None
        self._build_ui()
        self.refresh_models()
        self.log("Ready. Configure ComfyUI in Settings, then generate a panel.")

    def _build_ui(self):
        tabs = QTabWidget()
        self.setCentralWidget(tabs)
        tabs.addTab(self._studio_tab(), "Studio")
        tabs.addTab(self._library_tab(), "Characters & Continuity")
        tabs.addTab(self._projects_tab(), "Comic Projects")
        tabs.addTab(self._export_tab(), "Export")
        tabs.addTab(self._settings_tab(), "Settings")

    def _studio_tab(self):
        w = QWidget()
        box = QHBoxLayout(w)
        left = QVBoxLayout()
        right = QVBoxLayout()
        box.addLayout(left, 2)
        box.addLayout(right, 1)

        self.prompt = QPlainTextEdit()
        self.prompt.setPlaceholderText("Describe the comic panel...")
        self.negative = QLineEdit("blurry, low quality, bad hands, watermark")
        self.mode = QComboBox()
        self.mode.addItems(["Text to Image", "Image + Text Reference"])
        self.ref_path = QLineEdit()
        choose = QPushButton("Choose Reference Image")
        choose.clicked.connect(self.choose_reference)
        self.model_combo = QComboBox()

        grid = QGridLayout()
        self.width_spin = QSpinBox(); self.width_spin.setRange(256, 2048); self.width_spin.setSingleStep(64); self.width_spin.setValue(768)
        self.height_spin = QSpinBox(); self.height_spin.setRange(256, 2048); self.height_spin.setSingleStep(64); self.height_spin.setValue(768)
        self.steps_spin = QSpinBox(); self.steps_spin.setRange(1, 150); self.steps_spin.setValue(25)
        self.cfg_spin = QDoubleSpinBox(); self.cfg_spin.setRange(1.0, 30.0); self.cfg_spin.setSingleStep(0.5); self.cfg_spin.setValue(7.0)
        self.denoise_spin = QDoubleSpinBox(); self.denoise_spin.setRange(0.05, 1.0); self.denoise_spin.setSingleStep(0.05); self.denoise_spin.setValue(0.55)
        self.seed_edit = QLineEdit(); self.seed_edit.setPlaceholderText("blank = random")
        grid.addWidget(QLabel("Width"), 0, 0); grid.addWidget(self.width_spin, 0, 1)
        grid.addWidget(QLabel("Height"), 0, 2); grid.addWidget(self.height_spin, 0, 3)
        grid.addWidget(QLabel("Steps"), 1, 0); grid.addWidget(self.steps_spin, 1, 1)
        grid.addWidget(QLabel("CFG"), 1, 2); grid.addWidget(self.cfg_spin, 1, 3)
        grid.addWidget(QLabel("Img2Img strength"), 2, 0); grid.addWidget(self.denoise_spin, 2, 1)
        grid.addWidget(QLabel("Seed"), 2, 2); grid.addWidget(self.seed_edit, 2, 3)

        gen = QPushButton("Generate Panel with ComfyUI")
        gen.clicked.connect(self.generate_panel)
        test = QPushButton("Create Placeholder Panel")
        test.clicked.connect(self.generate_placeholder_panel)
        refresh = QPushButton("Refresh Models")
        refresh.clicked.connect(self.refresh_models)

        left.addWidget(QLabel("Prompt")); left.addWidget(self.prompt)
        left.addWidget(QLabel("Negative Prompt")); left.addWidget(self.negative)
        left.addWidget(QLabel("Mode")); left.addWidget(self.mode)
        left.addWidget(QLabel("Reference Image")); left.addWidget(self.ref_path); left.addWidget(choose)
        left.addWidget(QLabel("Checkpoint")); left.addWidget(self.model_combo)
        left.addLayout(grid)
        row = QHBoxLayout(); row.addWidget(gen); row.addWidget(test); row.addWidget(refresh); left.addLayout(row)

        self.preview = QLabel("Generated panel preview")
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setMinimumSize(420, 420)
        self.preview.setStyleSheet("border:1px solid #888")
        self.status = QTextEdit(); self.status.setReadOnly(True)
        right.addWidget(self.preview); right.addWidget(QLabel("Log")); right.addWidget(self.status)
        return w

    def _library_tab(self):
        w = QWidget(); layout = QVBoxLayout(w)
        form = QFormLayout()
        self.char_name = QLineEdit(); self.char_desc = QPlainTextEdit()
        self.loc_name = QLineEdit(); self.loc_desc = QPlainTextEdit()
        form.addRow("Character name", self.char_name)
        form.addRow("Character notes/look/outfit", self.char_desc)
        form.addRow("Location name", self.loc_name)
        form.addRow("Location notes", self.loc_desc)
        buttons = QHBoxLayout()
        a = QPushButton("Save Character"); b = QPushButton("Save Location"); c = QPushButton("Build Continuity Prompt")
        a.clicked.connect(self.save_character); b.clicked.connect(self.save_location); c.clicked.connect(self.build_continuity_prompt)
        buttons.addWidget(a); buttons.addWidget(b); buttons.addWidget(c)
        self.library_view = QTextEdit(); self.library_view.setReadOnly(True)
        layout.addLayout(form); layout.addLayout(buttons); layout.addWidget(self.library_view)
        self.refresh_library_view()
        return w

    def _projects_tab(self):
        w = QWidget(); layout = QVBoxLayout(w)
        self.project_name = QLineEdit("My Comic Book")
        create = QPushButton("Create Comic Project"); create.clicked.connect(self.create_project)
        self.page_notes = QPlainTextEdit(); self.page_notes.setPlaceholderText("Page script, panel notes, dialogue notes...")
        layout.addWidget(QLabel("Project name")); layout.addWidget(self.project_name); layout.addWidget(create)
        layout.addWidget(QLabel("Page / chapter notes")); layout.addWidget(self.page_notes)
        layout.addWidget(QLabel("Project storage is ready; the next UI upgrade can add drag/drop pages and panel thumbnails."))
        return w

    def _export_tab(self):
        w = QWidget(); layout = QVBoxLayout(w)
        pdf = QPushButton("Export Generated Panels as PDF Contact Sheet")
        cbz = QPushButton("Export Generated Panels as CBZ")
        pdf.clicked.connect(self.export_pdf); cbz.clicked.connect(self.export_cbz)
        self.export_log = QTextEdit(); self.export_log.setReadOnly(True)
        layout.addWidget(pdf); layout.addWidget(cbz); layout.addWidget(self.export_log)
        return w

    def _settings_tab(self):
        w = QWidget(); layout = QFormLayout(w)
        self.comfy_url = QLineEdit(self.settings.get("comfy_url"))
        self.comfy_path = QLineEdit(self.settings.get("comfy_path"))
        self.output_dir = QLineEdit(self.settings.get("output_dir"))
        choose = QPushButton("Choose ComfyUI Folder"); choose.clicked.connect(self.choose_comfy)
        save = QPushButton("Save Settings"); save.clicked.connect(self.save_settings)
        start = QPushButton("Start / Check ComfyUI"); start.clicked.connect(self.start_comfy)
        import_model = QPushButton("Import Checkpoint Model File"); import_model.clicked.connect(self.import_model)
        layout.addRow("ComfyUI URL", self.comfy_url)
        layout.addRow("ComfyUI folder", self.comfy_path)
        layout.addRow("", choose)
        layout.addRow("Output folder", self.output_dir)
        layout.addRow("", save)
        layout.addRow("", start)
        layout.addRow("", import_model)
        return w

    def log(self, msg):
        self.status.append(str(msg))

    def choose_reference(self):
        f, _ = QFileDialog.getOpenFileName(self, "Reference image", "", "Images (*.png *.jpg *.jpeg *.webp)")
        if f: self.ref_path.setText(f)

    def choose_comfy(self):
        d = QFileDialog.getExistingDirectory(self, "Choose ComfyUI folder")
        if d: self.comfy_path.setText(d)

    def save_settings(self):
        for k, widget in [("comfy_url", self.comfy_url), ("comfy_path", self.comfy_path), ("output_dir", self.output_dir)]:
            self.settings.set(k, widget.text())
        self.client = ComfyClient(self.settings.get("comfy_url"))
        self.refresh_models()
        self.log("Settings saved.")

    def start_comfy(self):
        self.save_settings()
        ok, msg = ComfyLauncher(self.settings.get("comfy_url"), self.settings.get("comfy_path")).start()
        self.log(msg)
        self.refresh_models()

    def refresh_models(self):
        self.model_combo.clear()
        models = self.client.list_checkpoints(self.settings.get("comfy_path")) if self.settings.get("comfy_path") else []
        self.model_combo.addItems(models or ["No checkpoint detected yet"])

    def import_model(self):
        if not self.settings.get("comfy_path"):
            QMessageBox.warning(self, "ComfyUI folder needed", "Choose your ComfyUI folder in Settings first.")
            return
        f, _ = QFileDialog.getOpenFileName(self, "Choose checkpoint", "", "Models (*.safetensors *.ckpt *.pt)")
        if not f: return
        try:
            dest = self.client.import_model_file(self.settings.get("comfy_path"), f)
            self.log(f"Imported model: {dest}")
            self.refresh_models()
        except Exception as exc:
            QMessageBox.critical(self, "Model import failed", str(exc))

    def _selected_checkpoint(self) -> str:
        ckpt = self.model_combo.currentText().strip()
        if not ckpt or ckpt.startswith("No checkpoint"):
            raise ComfyError("No checkpoint selected. Add a .safetensors/.ckpt model to ComfyUI/models/checkpoints first.")
        return ckpt

    def _seed(self):
        text = self.seed_edit.text().strip()
        return int(text) if text.isdigit() else None

    def generate_panel(self):
        self.save_settings()
        prompt = self.prompt.toPlainText().strip() or "comic panel"
        mode = "img2img" if self.mode.currentText().startswith("Image") else "txt2img"
        params = {
            "mode": mode,
            "checkpoint": self._selected_checkpoint(),
            "prompt": prompt,
            "negative_prompt": self.negative.text(),
            "out_dir": self.settings.get("output_dir"),
            "steps": self.steps_spin.value(),
            "cfg": self.cfg_spin.value(),
            "seed": self._seed(),
        }
        if mode == "txt2img":
            params["width"] = self.width_spin.value(); params["height"] = self.height_spin.value()
        else:
            ref = self.ref_path.text().strip()
            if not ref:
                QMessageBox.warning(self, "Reference needed", "Choose a reference image for Image + Text Reference mode.")
                return
            params["reference_image"] = ref; params["denoise"] = self.denoise_spin.value()
        self.log("Queued ComfyUI generation. This may take a while...")
        self.worker = GenerationWorker(self.client, params)
        self.worker.finished_ok.connect(self._generation_done)
        self.worker.failed.connect(self._generation_failed)
        self.worker.start()

    def _generation_done(self, path: str):
        self.generated.append(path)
        self.preview.setPixmap(QPixmap(path).scaled(self.preview.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        self.log(f"Generated: {path}")

    def _generation_failed(self, error: str):
        self.log("Generation failed:\n" + error)
        QMessageBox.critical(self, "Generation failed", error.split("\n\n")[0])

    def generate_placeholder_panel(self):
        out = self.settings.get("output_dir")
        prompt = self.prompt.toPlainText().strip() or "comic panel"
        path = self.client.generate_placeholder(prompt, out)
        self.generated.append(path)
        self.preview.setPixmap(QPixmap(path).scaled(self.preview.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        self.log(f"Created placeholder: {path}")

    def save_character(self):
        self.characters.add({"name": self.char_name.text(), "notes": self.char_desc.toPlainText()})
        self.refresh_library_view()

    def save_location(self):
        self.locations.add({"name": self.loc_name.text(), "notes": self.loc_desc.toPlainText()})
        self.refresh_library_view()

    def refresh_library_view(self):
        txt = "Characters:\n" + "\n".join(f"- {c.get('name')}: {c.get('notes','')[:160]}" for c in self.characters.all())
        txt += "\n\nLocations:\n" + "\n".join(f"- {c.get('name')}: {c.get('notes','')[:160]}" for c in self.locations.all())
        if hasattr(self, "library_view"):
            self.library_view.setPlainText(txt)

    def build_continuity_prompt(self):
        parts = [c.get("name", "") + ": " + c.get("notes", "") for c in self.characters.all()[-3:]]
        parts += [l.get("name", "") + ": " + l.get("notes", "") for l in self.locations.all()[-2:]]
        self.prompt.setPlainText((self.prompt.toPlainText() + "\n\nContinuity references:\n" + "\n".join(parts)).strip())

    def create_project(self):
        p = self.projects.create_project(self.project_name.text())
        QMessageBox.information(self, "Project created", str(p))

    def export_pdf(self):
        if not self.generated: return
        dest = str(Path(self.settings.get("output_dir")) / "brainbender_contact_sheet.pdf")
        self.export_log.append(Exporter().export_contact_pdf(self.generated, dest))

    def export_cbz(self):
        if not self.generated: return
        dest = str(Path(self.settings.get("output_dir")) / "brainbender_comic.cbz")
        self.export_log.append(Exporter().export_cbz(self.generated, dest))
