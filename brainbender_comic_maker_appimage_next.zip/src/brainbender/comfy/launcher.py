import subprocess, sys, time, requests
class ComfyLauncher:
    def __init__(self, url='http://127.0.0.1:8188', path=''):
        self.url=url.rstrip('/'); self.path=path; self.proc=None
    def is_running(self):
        try: return requests.get(self.url+'/system_stats', timeout=1.5).ok
        except Exception: return False
    def start(self):
        if self.is_running(): return True, 'ComfyUI already running.'
        if not self.path: return False, 'Set your ComfyUI folder in Settings first.'
        self.proc = subprocess.Popen([sys.executable, 'main.py'], cwd=self.path)
        for _ in range(40):
            if self.is_running(): return True, 'ComfyUI started.'
            time.sleep(.5)
        return False, 'ComfyUI did not answer in time.'
