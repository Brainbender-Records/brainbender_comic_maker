import json
from pathlib import Path
from .paths import SETTINGS_FILE
DEFAULTS = {
    'comfy_url':'http://127.0.0.1:8188',
    'comfy_path':'',
    'checkpoint':'',
    'output_dir': str(Path.home()/'BrainbenderComicOutput')
}
class Settings:
    def __init__(self):
        self.data = DEFAULTS.copy(); self.load()
    def load(self):
        if SETTINGS_FILE.exists():
            try: self.data.update(json.loads(SETTINGS_FILE.read_text()))
            except Exception: pass
    def save(self):
        SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
        SETTINGS_FILE.write_text(json.dumps(self.data, indent=2))
    def get(self,k): return self.data.get(k, DEFAULTS.get(k,''))
    def set(self,k,v): self.data[k]=v; self.save()
